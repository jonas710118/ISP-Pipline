# -*- coding: utf-8 -*-
"""K3 偏色生成器（Display P3 色域）：整图 ab 平移 + 逐色相残差（dH 旋转、乘法饱和度增益），数据驱动采样。

与 k2 的唯一区别：所有 RGB 按 Display P3 解释（k3_color_ops），偏色模型参数来自 P3 口径的真实配对统计
（cast_model_p3.json，k3_stats/export_cast_model.py 导出），色域收缩边界为 P3，4_code le2 为 P3 口径。

偏色是逐像素颜色函数 f(rgb)（不依赖空间位置），步骤（OKLab，C/t 为 ×100 口径）:
  1. 残差: H' = H + dH(H)，C' = C·(1 + g(H))；dH/g 为 24 档（中心 k·15°）周期线性插值
  2. 平移: (a', b') = C'·(cos H', sin H') + t          —— 作用于全部像素（含灰区）
  3. 色域: 超出 P3 的颜色固定 L、色相，沿 ab 向中性轴收缩到边界
  L 全程不变（色域收缩也不改 L）。
参数向量 x(50) = [dH(24), g(24), t_a, t_b]，按 低秩高斯 × t 分布尺度混合 采样；
protect() 保证色相单调（不折叠）与数值安全。

对外接口:
  CastModel(path).sample(rng, dev_scale, mean_scale) -> x
  protect(x, min_slope) -> (x, info)          shrink(x, f) -> x
  apply_cast(rgb, x) -> (rgb_out, info)       cast_lut(x, size) / apply_lut(rgb, lut)
  proxy_metrics(content, gt, x) -> dict       le2_4code(src, tgt)（P3 口径，需 lutgen_4code + skimage）
"""
from __future__ import annotations

import json
import os.path as osp

import numpy as np

try:
    from . import k3_color_ops as co
except ImportError:  # 直接脚本运行
    import k3_color_ops as co

NB = 24
BIN_DEG = 360.0 / NB
DIM = 2 * NB + 2
DEFAULT_MODEL = osp.join(osp.dirname(osp.abspath(__file__)), 'cast_model_p3.json')


def split(x):
    x = np.asarray(x, dtype=np.float64)
    return x[:NB], x[NB:2 * NB], x[2 * NB:2 * NB + 2]


class CastModel:
    """x = mu + B @ (s·z)，z~N(0,I_k)，s = sqrt((nu-2)/chi2_nu)。"""

    def __init__(self, model=None):
        if model is None or isinstance(model, str):
            with open(model or DEFAULT_MODEL, 'r', encoding='utf-8') as f:
                model = json.load(f)
        self.cfg = model
        self.mu = np.asarray(model['mu'], dtype=np.float64)
        self.B = np.asarray(model['basis'], dtype=np.float64)
        self.nu = float(model.get('nu', 0) or 0)
        assert self.mu.shape == (DIM,) and self.B.shape[0] == DIM, 'cast_model 维度不符'
        if model.get('color_space') != 'display-p3':
            raise ValueError('K3 需要 Display P3 口径的偏色模型（cast_model_p3.json），'
                             f"当前 color_space={model.get('color_space')}（k2 的 sRGB 模型不能混用）")

    def sample(self, rng, dev_scale=1.0, mean_scale=1.0, nu=None):
        nu = self.nu if nu is None else float(nu)
        z = rng.standard_normal(self.B.shape[1])
        s = np.sqrt((nu - 2.0) / rng.chisquare(nu)) if nu > 2 else 1.0
        return mean_scale * self.mu + dev_scale * (self.B @ (s * z))


def min_hue_slope(dH):
    """相邻档 1 + Δ/15 的最小值（<0 即色相折叠）。"""
    return float((1.0 + (dH - np.roll(dH, 1)) / BIN_DEG).min())


def protect(x, min_slope=0.3, dh_clip=45.0, g_lo=-0.8, g_hi=1.0, t_max=8.0):
    """数值与单调保护。折叠时把 dH 的去均值部分等比缩小到 min_slope（只影响少数样本）。"""
    x = np.array(x, dtype=np.float64)
    dH, g, t = x[:NB], x[NB:2 * NB], x[2 * NB:]
    info = dict(min_slope_raw=min_hue_slope(dH), projected=False)
    dH[:] = np.clip(dH, -dh_clip, dh_clip)
    worst = -(dH - np.roll(dH, 1)).min()        # 最大下降量（度）
    lim = BIN_DEG * (1.0 - min_slope)
    if worst > lim:
        m = dH.mean()
        dH[:] = m + (dH - m) * (lim / worst)
        info['projected'] = True
    g[:] = np.clip(g, g_lo, g_hi)
    tn = np.hypot(*t)
    if tn > t_max:
        t *= t_max / tn
    info['min_slope'] = min_hue_slope(dH)
    return x, info


def shrink(x, f):
    """整体向恒等映射收缩（重试用）。"""
    return np.asarray(x, dtype=np.float64) * float(f)


def _interp(v, H):
    z = H / BIN_DEG
    k = np.floor(z).astype(np.int64)
    u = z - k
    return (1.0 - u) * v[k % NB] + u * v[(k + 1) % NB]


def apply_cast(rgb, x, dh_c_ramp=0.0, gamut=True):
    """对 Display P3 RGB [0,1] (...,3) 施加偏色。返回 (float32 rgb, info)。

    dh_c_ramp>0 时 dH 乘 clip(C/dh_c_ramp,0,1)（低 C 端减弱色相旋转；默认 0=不用）。
    """
    rgb = np.asarray(rgb)
    shape = rgb.shape
    lab = co.rgb_to_oklab(rgb.reshape(-1, 3))
    L, a, b = lab[:, 0], lab[:, 1], lab[:, 2]
    C = np.hypot(a, b) * 100.0
    H = np.mod(np.degrees(np.arctan2(b, a)), 360.0)
    dH, g, t = split(x)
    dHp = _interp(dH, H)
    if dh_c_ramp > 0:
        dHp = dHp * np.clip(C / dh_c_ramp, 0.0, 1.0)
    Cn = np.maximum(C * (1.0 + _interp(g, H)), 0.0) / 100.0
    rad = np.radians(H + dHp)
    a2 = Cn * np.cos(rad) + t[0] / 100.0
    b2 = Cn * np.sin(rad) + t[1] / 100.0
    out_frac = 0.0
    if gamut:
        a2, b2, out = co.gamut_shrink_oklab(L, a2, b2)
        out_frac = float(out.mean())
    out_rgb = np.clip(co.oklab_to_rgb(np.stack([L, a2, b2], -1)), 0.0, 1.0)
    return out_rgb.reshape(shape).astype(np.float32), dict(gamut_frac=out_frac)


def cast_lut(x, size=33, **kw):
    """把同一偏色函数作用到 size³ RGB 格点，得到 LUT[r,g,b,3]（r 为第 0 轴）。"""
    lin = np.linspace(0.0, 1.0, size)
    grid = np.stack(np.meshgrid(lin, lin, lin, indexing='ij'), -1)
    out, _ = apply_cast(grid.reshape(size, size * size, 3), x, **kw)
    return out.reshape(size, size, size, 3)


def apply_lut(rgb, lut):
    """三线性查表（与 lutgen_4code.apply_lut 同轴序：lut[r, g, b]）。"""
    rgb = np.clip(np.asarray(rgb, dtype=np.float64), 0.0, 1.0)
    shape = rgb.shape
    n = lut.shape[0]
    p = rgb.reshape(-1, 3) * (n - 1)
    i0 = np.clip(np.floor(p).astype(np.int64), 0, n - 2)
    f = p - i0
    out = np.zeros_like(p)
    for dr in (0, 1):
        wr = f[:, 0] if dr else 1.0 - f[:, 0]
        for dg in (0, 1):
            wg = f[:, 1] if dg else 1.0 - f[:, 1]
            for db in (0, 1):
                wb = f[:, 2] if db else 1.0 - f[:, 2]
                out += (wr * wg * wb)[:, None] * lut[i0[:, 0] + dr, i0[:, 1] + dg, i0[:, 2] + db]
    return np.clip(out, 0.0, 1.0).reshape(shape).astype(np.float32)


def param_summary(x):
    dH, g, t = split(x)
    return dict(mean_abs_dH=float(np.abs(dH).mean()), max_abs_dH=float(np.abs(dH).max()),
                mean_abs_g=float(np.abs(g).mean()), t_norm=float(np.hypot(*t)))


def proxy_metrics(content, gt, x, lut_size=33, **kw):
    """廉价代理（~几十 ms）：格点 LUT 回放与逐像素偏色的一致性 + 单调性 + 出色域比例。"""
    rep = apply_lut(content, cast_lut(x, lut_size, **kw))
    return dict(grid_le2=co.le2_between(gt, rep), min_slope=min_hue_slope(split(x)[0]))


_LUTGEN = None
USE_FAST = True  # lutgen_fast 逐位等价补丁（只跳过结果必为 identity 的空格点近邻查询）


def p3_to_lab_skimage(rgb):
    """P3 RGB → CIELab：线性 P3 → XYZ（P3 矩阵）后交给 skimage.color.xyz2lab（D65/2°，与 rgb2lab 同白点）。"""
    from skimage import color as skc
    return skc.xyz2lab(co.rgb_to_xyz(np.asarray(rgb, dtype=np.float64)))


def le2_4code(src, tgt, lutgen_module=None):
    """4_code 权威口径 le2，P3 版：build_lut_hres 拟合（lutgen_p3 补丁：RGB↔XYZ 用 P3 矩阵）
    + apply_lut 回放 + skimage xyz2lab/deltaE_ciede2000（P3→XYZ）dE00<=2 占比。"""
    global _LUTGEN
    if lutgen_module is not None:
        _LUTGEN = lutgen_module
    if _LUTGEN is None:
        try:
            from . import lutgen_4code as lg
        except ImportError:
            import lutgen_4code as lg
        lg.set_intra_threads(1)
        _LUTGEN = lg
    try:
        from . import lutgen_fast, lutgen_p3
    except ImportError:
        import lutgen_fast
        import lutgen_p3
    lutgen_p3.patch_p3(_LUTGEN)
    (lutgen_fast.patch if USE_FAST else lutgen_fast.unpatch)(_LUTGEN)
    from skimage import color as skc
    src = np.asarray(src, dtype=np.float32)
    tgt = np.asarray(tgt, dtype=np.float32)
    lut = _LUTGEN.build_lut_hres(src, tgt)
    app = _LUTGEN.apply_lut(src, lut)
    de = skc.deltaE_ciede2000(p3_to_lab_skimage(tgt), p3_to_lab_skimage(app))
    return float((de <= 2.0).mean())
