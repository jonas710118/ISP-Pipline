# -*- coding: utf-8 -*-
"""K3 色彩工具：所有 RGB 均按 Display P3 解释（D65 白点，原色为 P3，传输曲线同 sRGB）。只依赖 numpy。

与 k2_color_ops 接口同名，区别只在 RGB↔XYZ/LMS 用 P3 原色矩阵：
  - P3 RGB → OKLab：先去伽马得线性 P3，再线性 P3 → 线性 sRGB 的 3x3 变换后接 Ottosson OKLab（等价于 P3→LMS 矩阵）
  - P3 RGB → CIELab(D65)：线性 P3 → XYZ（P3 矩阵）→ Lab（白点与 skimage 默认相同 0.95047/1/1.08883）
  - 色域收缩：固定 L 与色相，把超出 P3 色域（线性 P3 ∉ [0,1]）的颜色沿 ab 向中性轴收缩到边界
  - srgb_to_p3 / p3_to_srgb：同一物理颜色在两种编码之间的转换（供输入图像转换）
"""
from __future__ import annotations

import numpy as np

COLOR_SPACE = 'display-p3'

P3_TO_XYZ = np.array([[0.4865709486482162, 0.26566769316909306, 0.1982172852343625],
                      [0.2289745640697488, 0.6917385218365064, 0.079286914093745],
                      [0.0, 0.04511338185890264, 1.043944368900976]])
SRGB_TO_XYZ = np.array([[0.4124564, 0.3575761, 0.1804375],
                        [0.2126729, 0.7151522, 0.0721750],
                        [0.0193339, 0.1191920, 0.9503041]])
XYZ_TO_P3 = np.linalg.inv(P3_TO_XYZ)
P3_TO_SRGB_LIN = np.linalg.inv(SRGB_TO_XYZ) @ P3_TO_XYZ
SRGB_TO_P3_LIN = np.linalg.inv(P3_TO_SRGB_LIN)

_M1_SRGB = np.array([[0.4122214708, 0.5363325363, 0.0514459929],
                     [0.2119034982, 0.6806995451, 0.1073969566],
                     [0.0883024619, 0.2817188376, 0.6299787005]])
_M1 = _M1_SRGB @ P3_TO_SRGB_LIN          # 线性 P3 → LMS
_M2 = np.array([[0.2104542553, 0.7936177850, -0.0040720468],
                [1.9779984951, -2.4285922050, 0.4505937099],
                [0.0259040371, 0.7827717662, -0.8086757660]])
_M1_INV = np.linalg.inv(_M1)
_M2_INV = np.linalg.inv(_M2)
_D65 = np.array([0.95047, 1.0, 1.08883])


def srgb_to_linear(rgb):
    """传输曲线解码（Display P3 与 sRGB 同曲线）。"""
    rgb = np.clip(np.asarray(rgb, dtype=np.float64), 0.0, 1.0)
    return np.where(rgb <= 0.04045, rgb / 12.92, ((rgb + 0.055) / 1.055) ** 2.4)


def linear_to_srgb(lin):
    lin = np.clip(np.asarray(lin, dtype=np.float64), 0.0, 1.0)
    return np.where(lin <= 0.0031308, lin * 12.92, 1.055 * np.power(lin, 1.0 / 2.4) - 0.055)


def rgb_to_oklab(rgb):
    """P3 RGB [0,1] (...,3) → OKLab，L∈[0,1]。"""
    return np.cbrt(srgb_to_linear(rgb) @ _M1.T) @ _M2.T


def oklab_to_linear_unclipped(lab):
    """OKLab → 线性 P3（不截断，用于色域判断）。"""
    return ((np.asarray(lab, dtype=np.float64) @ _M2_INV.T) ** 3) @ _M1_INV.T


def oklab_to_rgb(lab):
    return linear_to_srgb(oklab_to_linear_unclipped(lab))


def gamut_shrink_oklab(L, a, b, iters=14, eps=1e-6):
    """超出 P3 色域的 (L,a,b) 沿 ab 向中性轴收缩到边界（L、色相不变）。返回 (a', b', out_mask)。"""
    L = np.asarray(L, dtype=np.float64)
    a = np.asarray(a, dtype=np.float64).copy()
    b = np.asarray(b, dtype=np.float64).copy()

    def inside(Lv, av, bv):
        lin = oklab_to_linear_unclipped(np.stack([Lv, av, bv], -1))
        return np.all((lin >= -eps) & (lin <= 1.0 + eps), -1)

    out = ~inside(L, a, b)
    if out.any():
        Lo, ao, bo = L[out], a[out], b[out]
        lo = np.zeros(Lo.shape)
        hi = np.ones(Lo.shape)
        for _ in range(iters):
            mid = 0.5 * (lo + hi)
            ok = inside(Lo, ao * mid, bo * mid)
            lo = np.where(ok, mid, lo)
            hi = np.where(ok, hi, mid)
        a[out] = ao * lo
        b[out] = bo * lo
    return a, b, out


def rgb_to_xyz(rgb):
    return srgb_to_linear(rgb) @ P3_TO_XYZ.T


def xyz_to_cielab(xyz):
    xyz = xyz / _D65
    eps, kappa = 216.0 / 24389.0, 24389.0 / 27.0
    f = np.where(xyz > eps, np.cbrt(xyz), (kappa * xyz + 16.0) / 116.0)
    return np.stack([116.0 * f[..., 1] - 16.0, 500.0 * (f[..., 0] - f[..., 1]),
                     200.0 * (f[..., 1] - f[..., 2])], -1)


def rgb_to_cielab(rgb):
    """P3 RGB → CIELab(D65)。"""
    return xyz_to_cielab(rgb_to_xyz(rgb))


def srgb_to_p3(rgb_srgb):
    """sRGB 编码 → Display P3 编码（同一物理颜色；sRGB 色域完全包含在 P3 内，不会越界）。"""
    return np.clip(linear_to_srgb(srgb_to_linear(rgb_srgb) @ SRGB_TO_P3_LIN.T), 0.0, 1.0)


def p3_to_srgb(rgb_p3):
    """Display P3 编码 → sRGB 编码（P3 独有的高饱和色会被逐通道截断）。"""
    return np.clip(linear_to_srgb(srgb_to_linear(rgb_p3) @ P3_TO_SRGB_LIN.T), 0.0, 1.0)


def ciede2000(lab1, lab2):
    L1, a1, b1 = lab1[..., 0], lab1[..., 1], lab1[..., 2]
    L2, a2, b2 = lab2[..., 0], lab2[..., 1], lab2[..., 2]
    C1, C2 = np.hypot(a1, b1), np.hypot(a2, b2)
    Cb7 = ((C1 + C2) / 2) ** 7
    G = 0.5 * (1 - np.sqrt(Cb7 / (Cb7 + 25.0 ** 7)))
    a1p, a2p = (1 + G) * a1, (1 + G) * a2
    C1p, C2p = np.hypot(a1p, b1), np.hypot(a2p, b2)
    h1p = np.degrees(np.arctan2(b1, a1p)) % 360
    h2p = np.degrees(np.arctan2(b2, a2p)) % 360
    dLp, dCp = L2 - L1, C2p - C1p
    dhp = h2p - h1p
    dhp = np.where(dhp > 180, dhp - 360, dhp)
    dhp = np.where(dhp < -180, dhp + 360, dhp)
    dhp = np.where(C1p * C2p == 0, 0, dhp)
    dHp = 2 * np.sqrt(C1p * C2p) * np.sin(np.radians(dhp) / 2)
    Lbp, Cbp = (L1 + L2) / 2, (C1p + C2p) / 2
    hs, hd = h1p + h2p, np.abs(h1p - h2p)
    hbp = np.where(C1p * C2p == 0, hs,
                   np.where(hd <= 180, hs / 2, np.where(hs < 360, (hs + 360) / 2, (hs - 360) / 2)))
    T = (1 - 0.17 * np.cos(np.radians(hbp - 30)) + 0.24 * np.cos(np.radians(2 * hbp))
         + 0.32 * np.cos(np.radians(3 * hbp + 6)) - 0.20 * np.cos(np.radians(4 * hbp - 63)))
    dth = 30 * np.exp(-(((hbp - 275) / 25) ** 2))
    Cbp7 = Cbp ** 7
    RC = 2 * np.sqrt(Cbp7 / (Cbp7 + 25.0 ** 7))
    SL = 1 + 0.015 * (Lbp - 50) ** 2 / np.sqrt(20 + (Lbp - 50) ** 2)
    SC, SH = 1 + 0.045 * Cbp, 1 + 0.015 * Cbp * T
    RT = -np.sin(np.radians(2 * dth)) * RC
    tL, tC, tH = dLp / SL, dCp / SC, dHp / SH
    return np.sqrt(tL ** 2 + tC ** 2 + tH ** 2 + RT * tC * tH)


def le2_between(rgb_ref, rgb_test):
    """dE00(ref,test)<=2 像素占比（P3 解释，numpy 版，代理指标用）。"""
    return float((ciede2000(rgb_to_cielab(rgb_ref), rgb_to_cielab(rgb_test)) <= 2.0).mean())
