#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
已对齐 style/ori -> 高分辨率拟合 -> 输出 33^3 LUT。

支持两种配对方向（必须指定 --pair-mode）:
  - style2ori: 扫 1_style 变体，匹配 0_ori 同 image_id；拟合 style -> ori
  - ori2style: 同上配对，拟合 ori -> style

release 目录命名:
  - 0_ori:  image_000008.png
  - 1_style: image_000008_hueH0.png

LUT / 对比结果写入 --work-dir；LUT apply 预览图写入 --applied-dir（与变体同名）。

用法:
  # style -> ori
  python 2_lutGenHres.py \\
      --pair-mode style2ori \\
      --style-dir E:/trainset/dataset0821/5_data_release/1_style \\
      --ori-dir E:/trainset/dataset0821/5_data_release/0_ori \\
      --work-dir ./lut_style2ori --applied-dir ./applied_style2ori --workers 8

  # ori -> style
  python 2_lutGenHres.py \\
      --pair-mode ori2style \\
      --style-dir E:/trainset/dataset0821/5_data_release/1_style \\
      --ori-dir E:/trainset/dataset0821/5_data_release/0_ori \\
      --work-dir ./lut_ori2style --applied-dir ./applied_ori2style --workers 8
"""

from __future__ import annotations

import argparse
import csv
import functools
import json
import os
import re
import time
from concurrent.futures import ProcessPoolExecutor, ThreadPoolExecutor, as_completed
from contextlib import redirect_stdout
from pathlib import Path

import cv2
import numpy as np
from PIL import Image

IMAGE_EXTS = (".png", ".jpg", ".jpeg", ".bmp", ".webp", ".tif", ".tiff")
HUE_STYLE_RE = re.compile(
    r"^image_(\d+)(?:_ori)?_((?:hue|sat)[LMH]\d*)\.(png|jpg|jpeg|bmp|webp|tif|tiff)$",
    re.I,
)
ORI_PLAIN_RE = re.compile(
    r"^image_(\d+)\.(png|jpg|jpeg|bmp|webp|tif|tiff)$",
    re.I,
)
TRANS_STYLE_RE = re.compile(
    r"^image_(\d+)_trans_(\d+)(?:_c(\d+))?\.(png|jpg|jpeg|bmp|webp|tif|tiff)$",
    re.I,
)
VARIANT_RE = re.compile(r"(hue|sat)[LMH]", re.I)
PAIR_MODES = ("style2ori", "ori2style")

OUT_GRID_SIZE = 33

# ======================== 自包含工具（源自 brightnessAlignedLutGen_fast + lut_apply）========================
# [EQ-OPT] 等价层改造：_INTRA_THREADS 支持环境变量覆盖（多进程/多 worker 场景调低），
# set_intra_threads() 可在运行时调整；数值结果与逐位原始实现完全一致。
_INTRA_THREADS = int(os.environ.get("LUTGEN_INTRA_THREADS", os.cpu_count() or 1))


def set_intra_threads(n: int) -> None:
    """运行时调整库内并行线程数（bgr_u8_to_lab_image / cKDTree.query 共用）。"""
    global _INTRA_THREADS
    _INTRA_THREADS = max(1, int(n))

D65 = np.array([0.95047, 1.0, 1.08883], dtype=np.float32)
RGB_TO_XYZ = np.array(
    [
        [0.4124564, 0.3575761, 0.1804375],
        [0.2126729, 0.7151522, 0.0721750],
        [0.0193339, 0.1191920, 0.9503041],
    ],
    dtype=np.float32,
)

GAMMA_CURVE_1023 = np.array(
    [
        0, 19, 39, 58, 76, 94, 113, 129, 146, 161, 175, 188, 200, 212, 223, 233,
        244, 254, 263, 273, 283, 292, 302, 312, 320, 329, 338, 347, 356, 364, 372, 380,
        388, 395, 403, 411, 418, 425, 432, 440, 447, 453, 460, 467, 474, 480, 486, 492,
        499, 505, 510, 516, 521, 527, 533, 538, 544, 549, 554, 560, 565, 569, 574, 579,
        584, 589, 594, 598, 603, 607, 611, 616, 621, 625, 629, 633, 637, 641, 645, 650,
        654, 658, 661, 665, 669, 672, 676, 679, 684, 687, 691, 694, 697, 701, 704, 707,
        710, 714, 718, 721, 724, 727, 730, 733, 736, 739, 742, 745, 747, 750, 753, 756,
        758, 761, 764, 768, 770, 773, 775, 778, 781, 783, 786, 788, 791, 793, 796, 798,
        801, 803, 805, 808, 810, 813, 815, 817, 820, 822, 824, 826, 829, 831, 833, 836,
        838, 840, 842, 844, 847, 849, 851, 853, 855, 857, 860, 862, 864, 866, 868, 870,
        872, 874, 876, 878, 880, 882, 884, 886, 888, 889, 891, 893, 895, 897, 899, 901,
        903, 904, 906, 908, 910, 912, 914, 916, 917, 919, 921, 923, 924, 925, 927, 929,
        931, 932, 934, 936, 937, 939, 941, 942, 944, 946, 946, 948, 950, 951, 953, 955,
        956, 958, 959, 961, 962, 964, 965, 966, 968, 969, 971, 972, 974, 975, 977, 978,
        980, 981, 982, 984, 985, 987, 988, 989, 991, 992, 994, 994, 996, 997, 999, 1000,
        1002, 1003, 1005, 1006, 1007, 1008, 1009, 1011, 1012, 1014, 1015, 1017, 1018, 1019, 1020, 1021,
        1023,
    ],
    dtype=np.float32,
)
_GAMMA_LIN_AXIS = np.linspace(0.0, 1.0, len(GAMMA_CURVE_1023))
_GAMMA_ENC_AXIS = GAMMA_CURVE_1023 / float(GAMMA_CURVE_1023[-1])
_GAMMA_ENC_AXIS_STRICT = _GAMMA_ENC_AXIS + np.arange(len(_GAMMA_ENC_AXIS)) * 1e-9
_GAMMA_CONFIG = None
_USE_CONFIG = object()
_GDEC256_CACHE = {"key": "__init__", "table": None}

HUE_H_BIN_WIDTH = 2.0
HUE_MIN_CHROMA = 8.0
HUE_MIN_L = 5.0
HUE_MAX_L = 98.0
HUE_L_REFINE_TOL = 5.0
HUE_MIN_REFINE_PX = 32

_PNG_LEVEL = 1
_PNG_PARAMS = [cv2.IMWRITE_PNG_COMPRESSION, _PNG_LEVEL]


def srgb_to_linear(rgb):
    rgb = np.clip(np.asarray(rgb, dtype=np.float32), 0.0, 1.0)
    return np.where(rgb <= 0.04045, rgb / 12.92, ((rgb + 0.055) / 1.055) ** 2.4)


def linear_to_srgb(lin):
    lin = np.clip(np.asarray(lin, dtype=np.float32), 0.0, 1.0)
    return np.where(lin <= 0.0031308, lin * 12.92, 1.055 * np.power(lin, 1.0 / 2.4) - 0.055)


def _normalize_gamma(gamma):
    if gamma is None:
        return None
    if isinstance(gamma, str):
        s = gamma.strip().lower()
        if s in ("", "srgb", "none", "default"):
            return None
        if s in ("curve", "lut", "table", "gamma_curve"):
            return "curve"
        return float(s)
    return float(gamma)


def set_gamma(gamma=None):
    global _GAMMA_CONFIG
    _GAMMA_CONFIG = _normalize_gamma(gamma)
    return _GAMMA_CONFIG


def gamma_decode(enc: np.ndarray, gamma=_USE_CONFIG) -> np.ndarray:
    g = _GAMMA_CONFIG if gamma is _USE_CONFIG else _normalize_gamma(gamma)
    enc = np.clip(np.asarray(enc, dtype=np.float32), 0.0, 1.0)
    if g is None:
        return srgb_to_linear(enc)
    if g == "curve":
        return np.interp(enc, _GAMMA_ENC_AXIS_STRICT, _GAMMA_LIN_AXIS).astype(np.float32, copy=False)
    return np.power(enc, g)


def gamma_encode(lin: np.ndarray, gamma=_USE_CONFIG) -> np.ndarray:
    g = _GAMMA_CONFIG if gamma is _USE_CONFIG else _normalize_gamma(gamma)
    lin = np.clip(np.asarray(lin, dtype=np.float32), 0.0, 1.0)
    if g is None:
        return linear_to_srgb(lin)
    if g == "curve":
        return np.interp(lin, _GAMMA_LIN_AXIS, _GAMMA_ENC_AXIS).astype(np.float32, copy=False)
    return np.power(lin, 1.0 / g)


def _gamma_decode_u8_table() -> np.ndarray:
    key = _GAMMA_CONFIG
    if _GDEC256_CACHE["table"] is None or _GDEC256_CACHE["key"] != key:
        _GDEC256_CACHE["table"] = gamma_decode(np.arange(256, dtype=np.float32) / 255.0)
        _GDEC256_CACHE["key"] = key
    return _GDEC256_CACHE["table"]


def rgb_to_lab(rgb):
    rgb = np.clip(np.asarray(rgb, dtype=np.float32), 0.0, 1.0)
    xyz = gamma_decode(rgb) @ RGB_TO_XYZ.T
    xyz_n = xyz / D65
    eps, kappa = 216.0 / 24389.0, 24389.0 / 27.0
    f = np.where(xyz_n > eps, np.cbrt(xyz_n), (kappa * xyz_n + 16.0) / 116.0)
    L = 116.0 * f[..., 1] - 16.0
    a = 500.0 * (f[..., 0] - f[..., 1])
    b = 200.0 * (f[..., 1] - f[..., 2])
    return np.stack([L, a, b], axis=-1)


def lab_to_rgb(lab):
    lab = np.asarray(lab, dtype=np.float32)
    L, a, b = lab[..., 0], lab[..., 1], lab[..., 2]
    fy = (L + 16.0) / 116.0
    fx = fy + a / 500.0
    fz = fy - b / 200.0
    eps, kappa = 216.0 / 24389.0, 24389.0 / 27.0

    def f_inv(t):
        t3 = t ** 3
        return np.where(t3 > eps, t3, (116.0 * t - 16.0) / kappa)

    xyz_n = np.stack([f_inv(fx), f_inv(fy), f_inv(fz)], axis=-1)
    xyz = xyz_n * D65
    lin = xyz @ np.linalg.inv(RGB_TO_XYZ).T
    lin = np.clip(lin, 0.0, 1.0)
    return np.clip(gamma_encode(lin), 0.0, 1.0)


def load_rgb(path: Path) -> np.ndarray:
    return np.asarray(Image.open(path).convert("RGB"), dtype=np.float32) / 255.0


def save_rgb(path, rgb) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    u8 = np.clip(np.round(np.asarray(rgb, dtype=np.float32) * 255.0), 0, 255).astype(np.uint8)
    cv2.imwrite(str(path), cv2.cvtColor(u8, cv2.COLOR_RGB2BGR), _PNG_PARAMS)


def save_diff_heatmap(path, de00) -> None:
    x = np.clip(de00 / max(np.percentile(de00, 95), 1e-6), 0.0, 1.0)
    cv2.imwrite(str(Path(path)), (x * 255).astype(np.uint8), _PNG_PARAMS)


def save_de00_mask_only(path, de00, threshold: float = 2.0) -> None:
    bad = (de00 > threshold).astype(np.uint8) * 255
    cv2.imwrite(str(Path(path)), bad, _PNG_PARAMS)


def save_cube(path: Path, lut: np.ndarray, cube_order: str = "red_fastest") -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    lut = np.clip(lut.astype(np.float32), 0.0, 1.0)
    g = lut.shape[0]
    o = cube_order.lower()
    if o in ("red_fastest", "r_fastest", "standard"):
        data = np.transpose(lut, (2, 1, 0, 3))
    else:
        data = lut
    lines = [
        "# generated by 2_lutGenHres.save_cube",
        f"LUT_3D_SIZE {g}",
        "DOMAIN_MIN 0.0 0.0 0.0",
        "DOMAIN_MAX 1.0 1.0 1.0",
        "",
    ]
    for row in data.reshape(-1, 3):
        lines.append(f"{row[0]:.6f} {row[1]:.6f} {row[2]:.6f}")
    path.write_text("\n".join(lines), encoding="utf-8")


def apply_lut(rgb: np.ndarray, lut: np.ndarray) -> np.ndarray:
    from scipy.ndimage import map_coordinates

    g = lut.shape[0]
    sc = float(g - 1)
    rgb = np.clip(np.asarray(rgb, dtype=np.float32), 0.0, 1.0)
    n_pix = rgb.shape[0] * rgb.shape[1]
    coords = np.empty((3, n_pix), dtype=np.float32)
    flat = rgb.reshape(n_pix, 3)
    coords[0] = flat[:, 0] * sc
    coords[1] = flat[:, 1] * sc
    coords[2] = flat[:, 2] * sc
    out_flat = np.empty((n_pix, 3), dtype=np.float32)
    for ch in range(3):
        out_flat[:, ch] = map_coordinates(lut[..., ch], coords, order=1, mode="nearest")
    return np.clip(out_flat.reshape(rgb.shape), 0.0, 1.0)


def _lab_from_linear(lin: np.ndarray) -> np.ndarray:
    xyz = lin @ RGB_TO_XYZ.T
    xyz_n = xyz / D65
    eps, kappa = 216.0 / 24389.0, 24389.0 / 27.0
    f = np.where(xyz_n > eps, np.cbrt(xyz_n), (kappa * xyz_n + 16.0) / 116.0)
    L = 116.0 * f[..., 1] - 16.0
    a = 500.0 * (f[..., 0] - f[..., 1])
    b = 200.0 * (f[..., 1] - f[..., 2])
    return np.stack([L, a, b], axis=-1)


def bgr_u8_to_lab_image(bgr_u8: np.ndarray) -> np.ndarray:
    rgb_u8 = cv2.cvtColor(bgr_u8, cv2.COLOR_BGR2RGB)
    lin = _gamma_decode_u8_table()[rgb_u8]
    h = lin.shape[0]
    workers = max(1, min(_INTRA_THREADS, h))
    if workers == 1:
        return _lab_from_linear(lin)
    out = np.empty(lin.shape, dtype=np.float32)
    step = (h + workers - 1) // workers
    starts = list(range(0, h, step))

    def job(s):
        e = min(h, s + step)
        out[s:e] = _lab_from_linear(lin[s:e])

    with ThreadPoolExecutor(max_workers=workers) as ex:
        list(ex.map(job, starts))
    return out


def extract_hue_top_color_pairs_from_lab(
    src_rgb01: np.ndarray,
    tgt_rgb01: np.ndarray,
    src_lab: np.ndarray,
    top_k: int = 10,
    dup_head: int = 20,
    dup_tail: int = 10,
    head_n: int = 5,
    min_px: int = HUE_MIN_REFINE_PX,
) -> tuple[np.ndarray, np.ndarray, int]:
    src = np.asarray(src_rgb01, dtype=np.float32)
    tgt = np.asarray(tgt_rgb01, dtype=np.float32)
    lab = np.asarray(src_lab, dtype=np.float32)

    L = lab[..., 0]
    a = lab[..., 1]
    b = lab[..., 2]
    C = np.hypot(a, b)
    H = np.degrees(np.arctan2(b, a)) % 360.0
    valid = (C >= HUE_MIN_CHROMA) & (L >= HUE_MIN_L) & (L <= HUE_MAX_L)

    n_bins = int(360.0 / HUE_H_BIN_WIDTH)
    bins = (np.floor(H / HUE_H_BIN_WIDTH).astype(np.int32) % n_bins)
    bins_flat = bins.reshape(-1)
    valid_flat = valid.reshape(-1)

    if np.any(valid_flat):
        use_map = valid
        counts = np.bincount(bins_flat[valid_flat], minlength=n_bins)
    else:
        use_map = np.ones_like(valid, dtype=bool)
        counts = np.bincount(bins_flat, minlength=n_bins)

    src_flat = src.reshape(-1, 3)
    tgt_flat = tgt.reshape(-1, 3)
    top_k = max(int(top_k), 0)
    dup_head = max(int(dup_head), 0)
    dup_tail = max(int(dup_tail), 0)
    head_n = max(int(head_n), 0)
    min_px = max(int(min_px), 1)

    src_means: list[np.ndarray] = []
    tgt_means: list[np.ndarray] = []
    reps: list[int] = []
    for rank_idx, bid in enumerate(np.argsort(-counts)[:top_k]):
        if counts[bid] == 0:
            break

        in_bin = bins == bid
        mask = use_map & in_bin
        if not np.any(mask):
            mask = in_bin

        l_med = float(np.median(L[mask]))
        refined = mask & (L >= l_med - HUE_L_REFINE_TOL) & (L <= l_med + HUE_L_REFINE_TOL)
        if int(refined.sum()) < min_px:
            continue

        keep = refined.reshape(-1)
        src_means.append(src_flat[keep].mean(axis=0))
        tgt_means.append(tgt_flat[keep].mean(axis=0))
        reps.append(dup_head if rank_idx < head_n else dup_tail)

    n_kept = len(src_means)
    if n_kept == 0:
        empty = np.zeros((0, 3), dtype=np.float32)
        return empty, empty, 0

    reps_arr = np.asarray(reps, dtype=np.int64)
    if int(reps_arr.sum()) == 0:
        empty = np.zeros((0, 3), dtype=np.float32)
        return empty, empty, n_kept
    src_pairs = np.repeat(np.asarray(src_means, dtype=np.float32), reps_arr, axis=0)
    tgt_pairs = np.repeat(np.asarray(tgt_means, dtype=np.float32), reps_arr, axis=0)
    return np.clip(src_pairs, 0.0, 1.0), np.clip(tgt_pairs, 0.0, 1.0), n_kept


def _ciede2000_np(lab1: np.ndarray, lab2: np.ndarray) -> np.ndarray:
    L1, a1, b1 = lab1[..., 0], lab1[..., 1], lab1[..., 2]
    L2, a2, b2 = lab2[..., 0], lab2[..., 1], lab2[..., 2]

    C1 = np.hypot(a1, b1)
    C2 = np.hypot(a2, b2)
    Cbar = (C1 + C2) / 2.0
    Cbar7 = Cbar ** 7
    G = 0.5 * (1.0 - np.sqrt(Cbar7 / (Cbar7 + 25.0 ** 7)))

    a1p = (1.0 + G) * a1
    a2p = (1.0 + G) * a2
    C1p = np.hypot(a1p, b1)
    C2p = np.hypot(a2p, b2)

    h1p = np.degrees(np.arctan2(b1, a1p)) % 360.0
    h2p = np.degrees(np.arctan2(b2, a2p)) % 360.0

    dLp = L2 - L1
    dCp = C2p - C1p
    dhp = h2p - h1p
    dhp = np.where(dhp > 180.0, dhp - 360.0, dhp)
    dhp = np.where(dhp < -180.0, dhp + 360.0, dhp)
    dhp = np.where(C1p * C2p == 0.0, 0.0, dhp)
    dHp = 2.0 * np.sqrt(C1p * C2p) * np.sin(np.radians(dhp) / 2.0)

    Lbarp = (L1 + L2) / 2.0
    Cbarp = (C1p + C2p) / 2.0
    hsum = h1p + h2p
    hdiff = np.abs(h1p - h2p)
    hbarp = np.where(
        C1p * C2p == 0.0,
        hsum,
        np.where(
            hdiff <= 180.0,
            hsum / 2.0,
            np.where(hsum < 360.0, (hsum + 360.0) / 2.0, (hsum - 360.0) / 2.0),
        ),
    )

    T = (
        1.0
        - 0.17 * np.cos(np.radians(hbarp - 30.0))
        + 0.24 * np.cos(np.radians(2.0 * hbarp))
        + 0.32 * np.cos(np.radians(3.0 * hbarp + 6.0))
        - 0.20 * np.cos(np.radians(4.0 * hbarp - 63.0))
    )
    dtheta = 30.0 * np.exp(-(((hbarp - 275.0) / 25.0) ** 2))
    Cbarp7 = Cbarp ** 7
    RC = 2.0 * np.sqrt(Cbarp7 / (Cbarp7 + 25.0 ** 7))
    SL = 1.0 + (0.015 * (Lbarp - 50.0) ** 2) / np.sqrt(20.0 + (Lbarp - 50.0) ** 2)
    SC = 1.0 + 0.045 * Cbarp
    SH = 1.0 + 0.015 * Cbarp * T
    RT = -np.sin(np.radians(2.0 * dtheta)) * RC

    tL = dLp / SL
    tC = dCp / SC
    tH = dHp / SH
    return np.sqrt(tL * tL + tC * tC + tH * tH + RT * tC * tH)


def _ciede2000_mt(lab_a: np.ndarray, lab_b: np.ndarray, workers: int = 0) -> np.ndarray:
    shape = lab_a.shape[:-1]
    A = lab_a.reshape(-1, 3)
    B = lab_b.reshape(-1, 3)
    n = A.shape[0]
    if workers <= 0:
        workers = max(1, _INTRA_THREADS)
    workers = max(1, min(workers, n))
    out = np.empty(n, dtype=np.float32)
    step = (n + workers - 1) // workers
    starts = list(range(0, n, step))

    def job(s):
        e = min(n, s + step)
        out[s:e] = _ciede2000_np(A[s:e], B[s:e])

    if len(starts) == 1:
        job(0)
    else:
        with ThreadPoolExecutor(max_workers=workers) as ex:
            list(ex.map(job, starts))
    return out.reshape(shape)


def _rgb_to_lab_mt(rgb: np.ndarray, workers: int = 0) -> np.ndarray:
    rgb = np.asarray(rgb, dtype=np.float32)
    h = rgb.shape[0]
    if workers <= 0:
        workers = max(1, _INTRA_THREADS)
    workers = max(1, min(workers, h))
    if workers == 1:
        return rgb_to_lab(rgb)
    out = np.empty(rgb.shape, dtype=np.float32)
    step = (h + workers - 1) // workers
    starts = list(range(0, h, step))

    def job(s):
        e = min(h, s + step)
        out[s:e] = rgb_to_lab(rgb[s:e])

    with ThreadPoolExecutor(max_workers=workers) as ex:
        list(ex.map(job, starts))
    return out


def compare_images(img_ref, img_test, de00_threshold=2.0):
    lab0 = _rgb_to_lab_mt(img_ref)
    lab1 = _rgb_to_lab_mt(img_test)
    de00 = _ciede2000_mt(lab0, lab1)
    lab1_nl = lab1.copy()
    lab1_nl[..., 0] = lab0[..., 0]
    de00_nl = _ciede2000_mt(lab0, lab1_nl)

    def stat(v):
        return {"mean": float(v.mean())}

    return {
        "de00": stat(de00),
        "de00_nl": stat(de00_nl),
        "de00_le2_ratio": float((de00 <= de00_threshold).sum()) / float(de00.size),
        "de00_map": de00,
        "de00_threshold": de00_threshold,
    }


def format_base(
    image_id: int,
    trans_id: int,
    variant_index: int | None = None,
    image_digits: int = 6,
    trans_digits: int = 3,
) -> str:
    stem = f"image_{image_id:0{image_digits}d}_trans_{trans_id:0{trans_digits}d}"
    if variant_index is not None:
        stem += f"_c{variant_index}"
    return stem


def flatten_stats(row: dict, prefix: str = "") -> dict:
    out = {}
    for k, v in row.items():
        key = f"{prefix}{k}" if not prefix else f"{prefix}_{k}"
        if isinstance(v, dict):
            out.update(flatten_stats(v, key))
        else:
            out[key] = v
    return out


def discover_style_items(style_dir: Path) -> list[tuple[Path, int, str]]:
    items: list[tuple[Path, int, str]] = []
    for p in sorted(style_dir.iterdir()):
        if not p.is_file() or p.suffix.lower() not in IMAGE_EXTS:
            continue
        stem_l = p.stem.lower()
        if stem_l.endswith("_mask") or stem_l.endswith("_original"):
            continue
        m = HUE_STYLE_RE.match(p.name)
        if m:
            items.append((p, int(m.group(1)), p.stem))
            continue
        m = TRANS_STYLE_RE.match(p.name)
        if m:
            image_id = int(m.group(1))
            trans_id = int(m.group(2))
            variant = int(m.group(3)) if m.group(3) else None
            items.append((p, image_id, format_base(image_id, trans_id, variant)))
    return items


def find_ori_for_image_id(image_id: int, ori_dir: Path, image_digits: int = 6) -> Path:
    """匹配 release 格式 image_XXXXXX.ext，兼容 image_XXXXXX_ori.ext。"""
    d = Path(ori_dir)
    digits_list: list[int] = []
    for n in (image_digits, 6, 4, 3):
        if n not in digits_list:
            digits_list.append(n)
    stems: list[str] = []
    for digits in digits_list:
        stems.append(f"image_{image_id:0{digits}d}")
    stems.append(f"image_{image_id}")
    for stem in stems:
        for ext in IMAGE_EXTS:
            cand = d / f"{stem}{ext}"
            if cand.is_file():
                return cand
            cand_ori = d / f"{stem}_ori{ext}"
            if cand_ori.is_file():
                return cand_ori
    raise FileNotFoundError(f"ori not found in {d} for image_id={image_id}")


def discover_pairs(
    pair_mode: str,
    style_dir: Path,
    ori_dir: Path,
    image_digits: int = 6,
) -> list[dict]:
    """返回配对列表：style_path, ori_path, image_id, name_base。"""
    mode = str(pair_mode).strip().lower()
    if mode not in PAIR_MODES:
        raise ValueError(f"pair_mode 必须是 {PAIR_MODES}，收到 {pair_mode!r}")
    items = discover_style_items(style_dir)
    pairs: list[dict] = []
    for style_path, image_id, name_base in items:
        ori_path = find_ori_for_image_id(image_id, ori_dir, image_digits)
        if mode == "style2ori":
            src_path, tgt_path = style_path, ori_path
        else:
            src_path, tgt_path = ori_path, style_path
        pairs.append(
            {
                "pair_mode": mode,
                "style_path": style_path,
                "ori_path": ori_path,
                "src_path": src_path,
                "tgt_path": tgt_path,
                "image_id": image_id,
                "name_base": name_base,
            }
        )
    return pairs


def find_ori_for_style(image_id: int, ori_dir: Path, image_digits: int = 6) -> Path:
    return find_ori_for_image_id(image_id, ori_dir, image_digits)


def infer_variant_mode(name: str) -> str:
    m = VARIANT_RE.search(name or "")
    if not m:
        return "auto"
    return "sat" if m.group(1).lower() == "sat" else "hue"


def _box_mean(image: np.ndarray, ksize: int) -> np.ndarray:
    import cv2

    return cv2.boxFilter(image, -1, (ksize, ksize), borderType=cv2.BORDER_REFLECT)


def _local_std(image: np.ndarray, ksize: int) -> np.ndarray:
    mean = _box_mean(image, ksize)
    mean2 = _box_mean(image * image, ksize)
    return np.sqrt(np.maximum(mean2 - mean * mean, 0.0))


def _grad_mag(rgb: np.ndarray) -> np.ndarray:
    import cv2

    gray = (0.2126 * rgb[..., 0] + 0.7152 * rgb[..., 1] + 0.0722 * rgb[..., 2]).astype(
        np.float32
    )
    gx = cv2.Sobel(gray, cv2.CV_32F, 1, 0, ksize=3)
    gy = cv2.Sobel(gray, cv2.CV_32F, 0, 1, ksize=3)
    return cv2.GaussianBlur(np.hypot(gx, gy), (0, 0), 1.2)


def _images_to_lab(src_rgb: np.ndarray, tgt_rgb: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    import cv2

    src_u8 = np.clip(np.asarray(src_rgb) * 255.0, 0, 255).astype(np.uint8)
    tgt_u8 = np.clip(np.asarray(tgt_rgb) * 255.0, 0, 255).astype(np.uint8)
    src_lab = bgr_u8_to_lab_image(cv2.cvtColor(src_u8, cv2.COLOR_RGB2BGR))
    tgt_lab = bgr_u8_to_lab_image(cv2.cvtColor(tgt_u8, cv2.COLOR_RGB2BGR))
    return src_lab, tgt_lab


def _preserve_grid_hue(lab_lut: np.ndarray, grid_lab: np.ndarray) -> np.ndarray:
    """sat 变体：格点输出保持输入色相，只采用拟合得到的 L/C*。"""
    out = np.asarray(lab_lut, dtype=np.float32).copy()
    grid = np.asarray(grid_lab, dtype=np.float32)
    c_fit = np.hypot(out[..., 1], out[..., 2])
    c_grid = np.hypot(grid[..., 1], grid[..., 2])
    scale = c_fit / np.maximum(c_grid, 1e-3)
    use = c_grid >= np.float32(2.0)
    out[..., 1] = np.where(use, grid[..., 1] * scale, out[..., 1])
    out[..., 2] = np.where(use, grid[..., 2] * scale, out[..., 2])
    return out


def _pixel_weights(
    src: np.ndarray,
    edge_boost: float,
    drop_mixed: bool,
    mix_cut: float,
) -> np.ndarray:
    """干净近缘加权；混色像素默认直接丢掉。"""
    std3 = _local_std(src, 3).mean(axis=-1)
    std9 = _local_std(src, 9).mean(axis=-1)
    grad = _grad_mag(src)
    g_ref = float(np.percentile(grad, 85)) + 1e-6
    s_ref = float(np.percentile(std3, 60)) + 1e-6
    near_edge = np.clip(grad / g_ref, 0.0, 2.0)
    clean = np.clip(1.0 - std3 / s_ref, 0.0, 1.0)
    mixed = std3 > (s_ref * float(mix_cut))
    w = 1.0 + float(edge_boost) * near_edge * clean
    structure = np.clip(std9 / (s_ref * 2.0), 0.0, 2.0) * clean
    w = w * (1.0 + 0.5 * structure)
    w = w.astype(np.float32)
    if drop_mixed:
        w[mixed] = 0.0
        if int(np.count_nonzero(w)) < 1000:
            w = np.maximum(w, np.float32(0.05) * (~mixed).astype(np.float32))
            w[mixed] = np.float32(0.02)
    return w


def _splat_pairs(
    src_rgb: np.ndarray,
    tgt_val: np.ndarray,
    weights: np.ndarray,
    grid_size: int,
    acc: np.ndarray,
    wsum: np.ndarray,
    pre: tuple | None = None,
):
    """色对三线性溅射到格点。tgt_val 可以是 RGB 或 Lab。

    [EQ-OPT] 等价层改造：pre 为上次调用返回的几何缓存（keep mask、
    筛选后 src/tgt、8 角点索引与权重）。调用方须保证同一 (src, tgt)
    且 weights 的零值集（keep mask）不变时才能复用——Huber 轮权重
    恒 >0、与首轮 mask 逐位一致，bincount 累加顺序不变 → 数值逐位一致。
    首次调用构建并返回 pre；复用轮直接跳过几何计算。
    """
    g = int(grid_size)
    if pre is None:
        src = np.clip(np.asarray(src_rgb, dtype=np.float32).reshape(-1, 3), 0.0, 1.0)
        tgt = np.asarray(tgt_val, dtype=np.float32).reshape(-1, tgt_val.shape[-1])
        w = np.asarray(weights, dtype=np.float32).reshape(-1)
        if src.size == 0 or tgt.size == 0:
            return None
        keep = w > 0.0
        if not np.any(keep):
            return None
        if not np.all(keep):
            src = src[keep]
            tgt = tgt[keep]
            w = w[keep]
        p = src * np.float32(g - 1)
        i0 = np.floor(p).astype(np.int32)
        np.clip(i0, 0, g - 1, out=i0)
        i1 = np.minimum(i0 + 1, g - 1)
        f = np.clip(p - i0.astype(np.float32), 0.0, 1.0)
        om = 1.0 - f
        ir0, ig0, ib0 = i0[:, 0], i0[:, 1], i0[:, 2]
        ir1, ig1, ib1 = i1[:, 0], i1[:, 1], i1[:, 2]
        fr, fg, fb = f[:, 0], f[:, 1], f[:, 2]
        or_, og, ob = om[:, 0], om[:, 1], om[:, 2]
        sel_r = (ir0, ir1)
        sel_g = (ig0, ig1)
        sel_b = (ib0, ib1)
        wt_r = (or_, fr)
        wt_g = (og, fg)
        wt_b = (ob, fb)
        pre = (keep, src, tgt, sel_r, sel_g, sel_b, wt_r, wt_g, wt_b, g)
    else:
        keep, src, tgt, sel_r, sel_g, sel_b, wt_r, wt_g, wt_b, g = pre
        w = np.asarray(weights, dtype=np.float32).reshape(-1)
        if not np.all(keep):
            w = w[keep]
    channels = tgt.shape[1]
    corners = (
        (0, 0, 0),
        (0, 0, 1),
        (0, 1, 0),
        (0, 1, 1),
        (1, 0, 0),
        (1, 0, 1),
        (1, 1, 0),
        (1, 1, 1),
    )
    n = g * g * g
    for br, bg, bb in corners:
        wt = w * wt_r[br] * wt_g[bg] * wt_b[bb]
        if wt.size == 0 or float(np.max(wt)) <= 0.0:
            continue
        ir, ig, ib = sel_r[br], sel_g[bg], sel_b[bb]
        idx = (ir.astype(np.int64) * g + ig.astype(np.int64)) * g + ib.astype(np.int64)
        wsum += np.bincount(idx, weights=wt, minlength=n)
        for c in range(channels):
            acc[:, c] += np.bincount(idx, weights=wt * tgt[:, c], minlength=n)
    return pre


def _sample_lut(lut: np.ndarray, rgb: np.ndarray, clip_out: bool = False) -> np.ndarray:
    from scipy.ndimage import map_coordinates

    g = lut.shape[0]
    sc = float(g - 1)
    rgb = np.clip(np.asarray(rgb, dtype=np.float32), 0.0, 1.0)
    coords = np.array(
        [rgb[..., 0] * sc, rgb[..., 1] * sc, rgb[..., 2] * sc], dtype=np.float64
    )
    chans = [
        map_coordinates(lut[..., c], coords, order=1, mode="nearest")
        for c in range(lut.shape[-1])
    ]
    out = np.stack(chans, axis=-1).astype(np.float32)
    if clip_out:
        out = np.clip(out, 0.0, 1.0)
    return out


@functools.lru_cache(maxsize=8)
def _grid_rgb(grid_size: int) -> np.ndarray:
    # [EQ-OPT] 等价层改造：lru_cache 复用同一尺寸的格点（调用方均为只读，
    # rgb_to_lab/_sample_lut 内部 np.clip 会新建数组，返回对象不会被修改）。
    g = int(grid_size)
    lin = np.linspace(0.0, 1.0, g, dtype=np.float32)
    rr, gg, bb = np.meshgrid(lin, lin, lin, indexing="ij")
    return np.stack([rr, gg, bb], axis=-1)


_IDENT_LAB_CACHE = {"key": "__init__", "g": -1, "table": None}


def _ident_lab(grid_size: int) -> np.ndarray:
    """g³ RGB 格的 identity Lab；按 (_GAMMA_CONFIG, g) 缓存。

    [EQ-OPT] 等价层改造：rgb_to_lab(_grid_rgb(g)) 在 fill/smooth 中重复计算，
    缓存后逐位不变（相同输入 → 相同输出，调用方只读）。
    """
    key = (repr(_GAMMA_CONFIG), int(grid_size))
    if _IDENT_LAB_CACHE["key"] != key or _IDENT_LAB_CACHE["table"] is None:
        _IDENT_LAB_CACHE["table"] = rgb_to_lab(_grid_rgb(int(grid_size)))
        _IDENT_LAB_CACHE["key"] = key
        _IDENT_LAB_CACHE["g"] = int(grid_size)
    return _IDENT_LAB_CACHE["table"]


def _circ_hue_dist_deg(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    d = np.abs(a - b) % 360.0
    return np.minimum(d, 360.0 - d)


def _fill_empty_cells_lch(
    lab_lut: np.ndarray,
    filled: np.ndarray,
    knn: int = 8,
    *,
    fill_mode: str = "identity_residual",
    identity_sigma: float = 0.08,
) -> np.ndarray:
    """填空格：用附近已占用格插值，并按距离衰减。

    identity_residual（默认）：插邻居 Lab 残差，加到本格 identity 上。
    残差随最近占用格的 RGB 距离做高斯衰减；超过 2.5σ 则完全不调整。
    neighbor：旧行为，直接抄邻居绝对 Lab（无衰减）。
    """
    g = lab_lut.shape[0]
    ident_lab = _ident_lab(g)
    if bool(np.all(filled)):
        return lab_lut
    if not bool(np.any(filled)):
        return ident_lab
    from scipy.spatial import cKDTree

    filled_ijk = np.argwhere(filled)
    empty_ijk = np.argwhere(~filled)
    scale = np.float32(g - 1)
    filled_rgb = filled_ijk.astype(np.float32) / scale
    empty_rgb = empty_ijk.astype(np.float32) / scale
    tree = cKDTree(filled_rgb)
    k_use = min(max(int(knn), 1), len(filled_ijk))
    dist, idx = tree.query(empty_rgb, k=k_use, workers=_INTRA_THREADS)
    if k_use == 1:
        dist = dist[:, None]
        idx = idx[:, None]

    q_lab = ident_lab[empty_ijk[:, 0], empty_ijk[:, 1], empty_ijk[:, 2]]
    d_lab = ident_lab[filled_ijk[:, 0], filled_ijk[:, 1], filled_ijk[:, 2]]
    q_c = np.hypot(q_lab[:, 1], q_lab[:, 2])
    d_c = np.hypot(d_lab[:, 1], d_lab[:, 2])
    q_h = np.degrees(np.arctan2(q_lab[:, 2], q_lab[:, 1])) % 360.0
    d_h = np.degrees(np.arctan2(d_lab[:, 2], d_lab[:, 1])) % 360.0
    hue_gap = _circ_hue_dist_deg(q_h[:, None], d_h[idx])
    chroma_keep = np.clip(q_c / 12.0, 0.0, 1.0)[:, None]
    hue_w = np.exp(-((hue_gap / 28.0) ** 2))
    hue_w = 1.0 - chroma_keep + chroma_keep * hue_w
    gray_w = 1.0 + (1.0 - chroma_keep) * np.clip(1.0 - d_c[idx] / 18.0, 0.0, 1.0)

    sig = np.maximum(dist[:, :1], 1e-4) * 1.25 + 1e-4
    ww = np.exp(-((dist / sig) ** 2)) * hue_w * gray_w
    ww /= np.maximum(ww.sum(axis=1, keepdims=True), 1e-8)

    mode = str(fill_mode).strip().lower()
    filled_lab = lab_lut[filled_ijk[:, 0], filled_ijk[:, 1], filled_ijk[:, 2]]
    if mode == "neighbor":
        lab_lut[empty_ijk[:, 0], empty_ijk[:, 1], empty_ijk[:, 2]] = np.einsum(
            "nk,nkc->nc", ww.astype(np.float32), filled_lab[idx]
        )
        return lab_lut

    filled_resid = filled_lab - d_lab
    mixed_resid = np.einsum("nk,nkc->nc", ww.astype(np.float32), filled_resid[idx])
    sigma = float(identity_sigma)
    if sigma > 0.0:
        nearest = dist[:, 0]
        fade = np.exp(-((nearest / sigma) ** 2)).astype(np.float32)
        fade[nearest >= (2.5 * sigma)] = 0.0
        mixed_resid = mixed_resid * fade[:, None]
    lab_lut[empty_ijk[:, 0], empty_ijk[:, 1], empty_ijk[:, 2]] = q_lab + mixed_resid
    return lab_lut


def _smooth_lab_residual(lab_lut: np.ndarray, sigma_cells: float) -> np.ndarray:
    """对 (拟合 Lab − identity Lab) 做高斯平滑，再加回 identity。

    糊的是偏色量，不会把未见过的格吸到照片色团的绝对颜色上。
    sigma 单位是网格格点（33³ 上 1 格 ≈ RGB 0.031）。
    """
    s = float(sigma_cells)
    if s <= 0.0:
        return lab_lut
    from scipy.ndimage import gaussian_filter

    ident = _ident_lab(lab_lut.shape[0])
    resid = np.asarray(lab_lut, dtype=np.float32) - ident
    resid = gaussian_filter(
        resid, sigma=[s, s, s, 0], mode="nearest"
    ).astype(np.float32)
    return ident + resid


def _huber_weights(residual: np.ndarray, k: float) -> np.ndarray:
    r = np.asarray(residual, dtype=np.float32)
    kk = max(float(k), 1e-3)
    w = np.ones_like(r, dtype=np.float32)
    big = r > kk
    w[big] = kk / np.maximum(r[big], 1e-6)
    return w


def build_lut_hres(
    img_src: np.ndarray,
    img_tgt: np.ndarray,
    *,
    fit_grid_size: int = 65,
    out_grid_size: int = OUT_GRID_SIZE,
    sample_stride: int = 1,
    edge_boost: float = 3.0,
    drop_mixed: bool = True,
    mix_cut: float = 1.5,
    variant_mode: str = "auto",
    huber_iters: int = 2,
    huber_k: float = 2.5,
    hue_enable: bool = True,
    hue_top_k: int = 10,
    hue_dup_head: int = 40,
    hue_dup_tail: int = 16,
    hue_head_n: int = 5,
    hue_min_px: int = 32,
    hue_weight: float = 8.0,
    fill_knn: int = 8,
    fill_mode: str = "identity_residual",
    fill_identity_sigma: float = 0.08,
    smooth_sigma: float = 1.0,
) -> np.ndarray:
    """高分辨率 Lab 拟合，再抽点成 out_grid_size^3 RGB LUT。"""
    src = np.ascontiguousarray(img_src, dtype=np.float32)
    tgt = np.ascontiguousarray(img_tgt, dtype=np.float32)
    if src.shape != tgt.shape:
        raise ValueError("src/tgt shape mismatch")

    g = int(fit_grid_size)
    if g < int(out_grid_size):
        raise ValueError(f"fit_grid_size={g} 必须 >= out_grid_size={out_grid_size}")

    src_s = src[::sample_stride, ::sample_stride]
    tgt_s = tgt[::sample_stride, ::sample_stride]
    _src_lab, tgt_lab = _images_to_lab(src_s, tgt_s)
    mode = str(variant_mode).lower()
    tgt_fit = tgt_lab
    # sat 保色相是可选正则：只在显式 --variant-space sat 时启用
    grid_lab = rgb_to_lab(_grid_rgb(g)) if mode == "sat" else None

    weights = _pixel_weights(src_s, edge_boost, drop_mixed, mix_cut)
    acc = np.zeros((g * g * g, 3), dtype=np.float64)
    wsum = np.zeros(g * g * g, dtype=np.float64)

    hue_src = np.zeros((0, 3), dtype=np.float32)
    hue_tgt_lab = np.zeros((0, 3), dtype=np.float32)
    hue_w = np.zeros((0,), dtype=np.float32)
    if hue_enable and int(hue_top_k) > 0:
        # [EQ-OPT] 等价层改造：sample_stride==1 时 src_s 即 src 本身，
        # 复用 _images_to_lab 已算好的 src Lab（数值逐位相同），
        # 省一次全图 bgr_u8_to_lab_image；stride>1 保持原始路径。
        if sample_stride == 1:
            src_lab_full = _src_lab
        else:
            src_u8 = np.clip(src * 255.0, 0, 255).astype(np.uint8)
            src_bgr = __import__("cv2").cvtColor(src_u8, __import__("cv2").COLOR_RGB2BGR)
            src_lab_full = bgr_u8_to_lab_image(src_bgr)
        hue_src, hue_tgt, _n = extract_hue_top_color_pairs_from_lab(
            src,
            tgt,
            src_lab_full,
            top_k=int(hue_top_k),
            dup_head=int(hue_dup_head),
            dup_tail=int(hue_dup_tail),
            head_n=int(hue_head_n),
            min_px=int(hue_min_px),
        )
        if len(hue_src):
            hue_tgt_lab = rgb_to_lab(hue_tgt)
            hue_w = np.full(len(hue_src), float(hue_weight), dtype=np.float32)

    # [EQ-OPT] 等价层改造：
    #  - pixel_pre：首轮 _splat_pairs 返回的几何缓存，Huber 轮复用
    #    （huber 权重恒 >0 → keep mask 与首轮逐位一致，bincount 顺序不变）。
    #  - hue_contrib：主色对 (src/tgt/权重) 各轮不变 → 其 bincount 贡献
    #    独立算一次后缓存，每轮直接累加（加法交换律下逐位一致）。
    def _splat_all(pix_w: np.ndarray, pixel_pre=None, hue_contrib=None):
        nonlocal acc, wsum  # [EQ-OPT] acc/wsum 在本函数内被 += 重新绑定
        acc.fill(0.0)
        wsum.fill(0.0)
        pixel_pre = _splat_pairs(src_s, tgt_fit, pix_w, g, acc, wsum,
                                 pre=pixel_pre)
        if len(hue_src):
            if hue_contrib is None:
                acc_h = np.zeros_like(acc)
                wsum_h = np.zeros_like(wsum)
                _splat_pairs(hue_src, hue_tgt_lab, hue_w, g, acc_h, wsum_h)
                hue_contrib = (acc_h, wsum_h)
            acc += hue_contrib[0]
            wsum += hue_contrib[1]
        return pixel_pre, hue_contrib

    def _finalize_lab(lab: np.ndarray) -> np.ndarray:
        if mode == "sat" and grid_lab is not None:
            return _preserve_grid_hue(lab, grid_lab)
        return lab

    pixel_pre, hue_contrib = _splat_all(weights)

    def _lut_from_acc() -> tuple[np.ndarray, np.ndarray]:
        filled = wsum > 1e-8
        lab = np.zeros((g * g * g, 3), dtype=np.float32)
        lab[filled] = (acc[filled] / wsum[filled, None]).astype(np.float32)
        lab = lab.reshape(g, g, g, 3)
        return _finalize_lab(lab), filled.reshape(g, g, g)

    lab_lut, filled = _lut_from_acc()
    tgt_flat = tgt_fit.reshape(-1, 3)
    w_flat = weights.reshape(-1)
    iters = max(1, int(huber_iters))
    for _ in range(1, iters):
        pred = _sample_lut(lab_lut, src_s, clip_out=False).reshape(-1, 3)
        resid = np.linalg.norm(pred - tgt_flat, axis=1)
        pixel_pre, hue_contrib = _splat_all(
            w_flat * _huber_weights(resid, huber_k),
            pixel_pre=pixel_pre, hue_contrib=hue_contrib)
        lab_lut, filled = _lut_from_acc()

    lab_lut = _fill_empty_cells_lch(
        lab_lut,
        filled,
        knn=fill_knn,
        fill_mode=fill_mode,
        identity_sigma=fill_identity_sigma,
    )
    lab_lut = _finalize_lab(lab_lut)

    out_g = int(out_grid_size)
    # 65³ 与 33³ 用同一 RGB 尺度的核：σ_cells * 1/(G-1)
    fit_smooth = (
        float(smooth_sigma) * float(g - 1) / float(out_g - 1)
        if smooth_sigma and smooth_sigma > 0
        else 0.0
    )
    lab_lut = _smooth_lab_residual(lab_lut, fit_smooth)
    lab_lut = _finalize_lab(lab_lut)

    query = _grid_rgb(out_g)
    lab33 = _sample_lut(lab_lut, query, clip_out=False)
    lab33 = _smooth_lab_residual(lab33, float(smooth_sigma) if smooth_sigma else 0.0)
    lut = np.clip(lab_to_rgb(lab33), 0.0, 1.0).astype(np.float32)
    return lut


def run_single(
    pair: dict,
    work: Path,
    applied_dir: Path,
    args,
) -> dict:
    t0 = time.perf_counter()
    pair_mode = str(pair["pair_mode"])
    src_path = Path(pair["src_path"])
    tgt_path = Path(pair["tgt_path"])
    style_path = Path(pair["style_path"])
    ori_path = Path(pair["ori_path"])
    name_base = str(pair["name_base"])
    src = load_rgb(src_path)
    tgt = load_rgb(tgt_path)
    if src.shape != tgt.shape:
        raise ValueError(f"shape mismatch: {src_path.name} vs {tgt_path.name}")
    mode = args.variant_space
    if mode == "auto":
        mode = infer_variant_mode(name_base)
    if mode == "auto":
        mode = "hue"
    if not args.quiet:
        print(f"  pair : {pair_mode}")
        print(f"  style: {style_path.name}")
        print(f"  ori  : {ori_path.name}")
        print(f"  src  : {src_path.name}  ->  tgt: {tgt_path.name}")
        print(f"  space: {mode}  fit={args.fit_grid_size}^3 -> {OUT_GRID_SIZE}^3")

    t1 = time.perf_counter()
    lut = build_lut_hres(
        src,
        tgt,
        fit_grid_size=args.fit_grid_size,
        out_grid_size=OUT_GRID_SIZE,
        sample_stride=args.sample_stride,
        edge_boost=args.edge_boost,
        drop_mixed=not args.keep_mixed,
        mix_cut=args.mix_cut,
        variant_mode=mode,
        huber_iters=args.huber_iters,
        huber_k=args.huber_k,
        hue_enable=not args.no_hue_pairs,
        hue_top_k=args.hue_top_k,
        hue_dup_head=args.hue_dup_head,
        hue_dup_tail=args.hue_dup_tail,
        hue_head_n=args.hue_head_n,
        hue_min_px=args.hue_min_px,
        hue_weight=args.hue_weight,
        fill_knn=args.fill_knn,
        fill_mode=args.fill_mode,
        fill_identity_sigma=args.fill_identity_sigma,
        smooth_sigma=args.smooth_sigma,
    )
    t_lut = time.perf_counter() - t1
    if lut.shape != (OUT_GRID_SIZE, OUT_GRID_SIZE, OUT_GRID_SIZE, 3):
        raise RuntimeError(f"输出 LUT 不是 {OUT_GRID_SIZE}^3: {lut.shape}")

    p_lut = work / f"{name_base}_gt_lut.cube"
    save_cube(p_lut, lut, args.cube_order)

    applied = apply_lut(src, lut)
    stats = compare_images(tgt, applied, de00_threshold=args.de00_threshold)
    de00_map = stats.pop("de00_map")
    thr = stats.pop("de00_threshold")
    p_applied = applied_dir / f"{name_base}.png"
    if args.save_apply:
        applied_dir.mkdir(parents=True, exist_ok=True)
        save_rgb(p_applied, applied)
    if args.save_diff:
        save_diff_heatmap(work / f"{name_base}_diff_de00.png", de00_map)
    save_de00_mask_only(
        work / f"{name_base}_de00_gt{thr:g}_mask.png", de00_map, threshold=thr
    )
    if not args.quiet:
        print(
            f"  timing: lut={t_lut:.2f}s  total={time.perf_counter() - t0:.2f}s  "
            f"de00={stats['de00']['mean']:.3f}"
        )
    row = flatten_stats(
        {
            "base": name_base,
            "pair_mode": pair_mode,
            "style_file": style_path.name,
            "ori_file": ori_path.name,
            "src_file": src_path.name,
            "tgt_file": tgt_path.name,
            "gt_lut": p_lut.name,
            "applied_file": p_applied.name if args.save_apply else "",
            "applied_path": str(p_applied) if args.save_apply else "",
            "fit_grid": int(args.fit_grid_size),
            "out_grid": OUT_GRID_SIZE,
            "variant_space": mode,
            "fill_mode": args.fill_mode,
            **stats,
        }
    )
    (work / f"{name_base}_compare.json").write_text(
        json.dumps(row, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    return row


def _load_existing_row(
    work: Path, applied_dir: Path, name_base: str, *, save_apply: bool
) -> dict | None:
    json_path = Path(work) / f"{name_base}_compare.json"
    if not json_path.is_file():
        return None
    try:
        row = json.loads(json_path.read_text(encoding="utf-8"))
    except Exception:
        return None
    if not isinstance(row, dict) or row.get("error"):
        return None
    lut_name = row.get("gt_lut")
    if lut_name:
        lut_path = Path(work) / str(lut_name)
        if not lut_path.is_file() or lut_path.stat().st_size <= 0:
            return None
    if save_apply:
        applied_name = row.get("applied_file") or f"{name_base}.png"
        applied_path = Path(applied_dir) / str(applied_name)
        if not applied_path.is_file() or applied_path.stat().st_size <= 0:
            return None
    row.setdefault("skipped_existing", True)
    return row


def _worker_init(intra_threads: int) -> None:
    global _INTRA_THREADS
    _INTRA_THREADS = max(1, int(intra_threads))
    try:
        import cv2

        cv2.setNumThreads(_INTRA_THREADS)
    except Exception:
        pass


def _process_one_task(task):
    idx, pair, work, applied_dir, args = task
    set_gamma(args.gamma)
    name_base = str(pair["name_base"])
    existing = (
        _load_existing_row(work, applied_dir, name_base, save_apply=args.save_apply)
        if args.skip_existing
        else None
    )
    if existing is not None:
        return idx, True, Path(pair["style_path"]).name, existing
    try:
        if args.quiet:
            with open(os.devnull, "w", encoding="utf-8") as sink, redirect_stdout(sink):
                row = run_single(pair, work, applied_dir, args)
        else:
            row = run_single(pair, work, applied_dir, args)
        return idx, True, Path(pair["style_path"]).name, row
    except Exception as e:
        return idx, False, Path(pair["style_path"]).name, {
            "base": name_base,
            "pair_mode": pair.get("pair_mode", ""),
            "style_file": Path(pair["style_path"]).name,
            "error": str(e),
        }


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        description="style/ori 配对 -> 高分辨率拟合 -> 33^3 LUT + apply 预览"
    )
    p.add_argument(
        "--pair-mode",
        required=True,
        choices=PAIR_MODES,
        help="style2ori: style->ori；ori2style: ori->style（必须指定）",
    )
    p.add_argument("--style-dir", type=Path, required=True)
    p.add_argument("--ori-dir", type=Path, required=True)
    p.add_argument("--work-dir", type=Path, required=True, help="LUT / compare.json / diff 等")
    p.add_argument(
        "--applied-dir",
        type=Path,
        required=True,
        help="LUT apply 预览图目录（与变体同名 .png）",
    )
    p.add_argument("--image-digits", type=int, default=6)
    p.add_argument("--cube-order", default="red_fastest")
    p.add_argument(
        "--fit-grid-size",
        type=int,
        default=65,
        choices=(65, 129),
        help="内部拟合网格，输出固定 33",
    )
    p.add_argument("--sample-stride", type=int, default=2, help="像素采样步长，1=全像素")
    p.add_argument("--edge-boost", type=float, default=3.0, help="干净边缘像素额外权重")
    p.add_argument("--keep-mixed", action="store_true", help="保留混色像素（默认丢掉）")
    p.add_argument("--mix-cut", type=float, default=1.5, help="混色丢弃阈值（相对局部 std）")
    p.add_argument(
        "--variant-space",
        default="auto",
        choices=("auto", "sat", "hue"),
        help="auto/hue=完整 Lab；sat=格点保色相（仅作实验，默认可关）",
    )
    p.add_argument("--huber-iters", type=int, default=2, help="IRLS 次数，1=只做加权均值")
    p.add_argument("--huber-k", type=float, default=2.5, help="Huber 阈值（Lab 欧氏）")
    p.add_argument(
        "--smooth-sigma",
        type=float,
        default=1.0,
        help="Lab 残差高斯平滑（33³ 格点数，默认 1≈RGB 0.03）；65³ 按同 RGB 尺度放大。0=关闭",
    )
    p.add_argument("--fill-knn", type=int, default=8)
    p.add_argument(
        "--fill-mode",
        default="identity_residual",
        choices=("identity_residual", "neighbor"),
        help="空格填充：identity_residual=插附近残差并按距离衰减；neighbor=直接抄邻居颜色",
    )
    p.add_argument(
        "--fill-identity-sigma",
        type=float,
        default=0.08,
        help="空格残差 RGB 距离高斯 σ（默认 0.08，衰减更软；约 2.5σ 处为 0）。0=关闭衰减",
    )
    p.add_argument("--hue-top-k", type=int, default=10)
    p.add_argument("--hue-dup-head", type=int, default=40)
    p.add_argument("--hue-dup-tail", type=int, default=16)
    p.add_argument("--hue-head-n", type=int, default=5)
    p.add_argument("--hue-min-px", type=int, default=HUE_MIN_REFINE_PX)
    p.add_argument("--hue-weight", type=float, default=8.0)
    p.add_argument("--no-hue-pairs", action="store_true")
    p.add_argument("--de00-threshold", type=float, default=2.0)
    p.add_argument("--save-diff", action="store_true")
    p.add_argument(
        "--save-apply",
        dest="save_apply",
        action="store_true",
        default=True,
        help="保存 LUT apply 预览到 --applied-dir/{stem}.png（默认开）",
    )
    p.add_argument(
        "--no-save-apply",
        dest="save_apply",
        action="store_false",
        help="不保存 LUT apply 预览图",
    )
    p.add_argument("--gamma", default=None)
    p.add_argument("--workers", type=int, default=8)
    p.add_argument("--skip-existing", action="store_true")
    p.add_argument("--quiet", action="store_true")
    p.add_argument("--limit", type=int, default=0, help="只处理前 N 张，0=全部")
    return p


def main() -> None:
    args = build_parser().parse_args()
    args.style_dir = args.style_dir.resolve()
    args.ori_dir = args.ori_dir.resolve()
    args.applied_dir = args.applied_dir.resolve()
    set_gamma(args.gamma)
    work = Path(args.work_dir)
    applied_dir = Path(args.applied_dir)
    work.mkdir(parents=True, exist_ok=True)
    if args.save_apply:
        applied_dir.mkdir(parents=True, exist_ok=True)

    pairs = discover_pairs(
        args.pair_mode,
        args.style_dir,
        args.ori_dir,
        args.image_digits,
    )
    if not pairs:
        raise SystemExit(f"未找到配对于 style={args.style_dir} ori={args.ori_dir}")
    if int(args.limit) > 0:
        pairs = pairs[: int(args.limit)]

    workers = max(1, int(args.workers))
    cpu_count = os.cpu_count() or 1
    intra_threads = max(1, cpu_count // workers)
    global _INTRA_THREADS
    _INTRA_THREADS = intra_threads
    print(
        f"found {len(pairs)} pair(s), pair_mode={args.pair_mode}, workers={workers}, "
        f"intra-threads={intra_threads}, fit={args.fit_grid_size}^3 -> {OUT_GRID_SIZE}^3, "
        f"stride={args.sample_stride}, huber_iters={args.huber_iters}, "
        f"save_apply={args.save_apply}"
    )
    print(f"style ={args.style_dir}")
    print(f"ori   ={args.ori_dir}")
    print(f"work  ={work}  (LUT / json / diff)")
    print(f"apply ={applied_dir}  (LUT apply preview .png, save_apply={args.save_apply})")

    rows: list[dict | None] = [None] * len(pairs)
    t0 = time.perf_counter()
    if workers == 1:
        for idx, pair in enumerate(pairs):
            if not args.quiet:
                print(f"\n--- [{idx + 1}/{len(pairs)}] {pair['style_path'].name} ---")
            name_base = str(pair["name_base"])
            existing = (
                _load_existing_row(work, applied_dir, name_base, save_apply=args.save_apply)
                if args.skip_existing
                else None
            )
            if existing is not None:
                rows[idx] = existing
                continue
            try:
                rows[idx] = run_single(pair, work, applied_dir, args)
            except Exception as e:
                print(f"  ERROR {pair['style_path'].name}: {e}")
                rows[idx] = {
                    "base": name_base,
                    "pair_mode": args.pair_mode,
                    "style_file": pair["style_path"].name,
                    "error": str(e),
                }
    else:
        tasks = [
            (idx, pair, work, applied_dir, args)
            for idx, pair in enumerate(pairs)
        ]
        done = 0
        with ProcessPoolExecutor(
            max_workers=workers,
            initializer=_worker_init,
            initargs=(intra_threads,),
        ) as ex:
            futures = [ex.submit(_process_one_task, task) for task in tasks]
            for fut in as_completed(futures):
                idx, success, name, row = fut.result()
                rows[idx] = row
                done += 1
                if (not args.quiet) or done % 50 == 0 or done == len(pairs):
                    print(f"[{done}/{len(pairs)}] {'ok' if success else 'ERROR'}: {name}")

    rows_ok = [r for r in rows if r is not None]
    csv_path = work / "results.csv"
    if rows_ok:
        fields = list(dict.fromkeys(k for r in rows_ok for k in r))
        with csv_path.open("w", newline="", encoding="utf-8-sig") as f:
            w = csv.DictWriter(f, fieldnames=fields)
            w.writeheader()
            w.writerows(rows_ok)
    print(f"\n=== done: {len(pairs)} in {time.perf_counter() - t0:.1f}s, csv -> {csv_path} ===")


if __name__ == "__main__":
    main()