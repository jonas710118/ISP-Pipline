# -*- coding: utf-8 -*-
"""4_code build_lut_hres 的逐位等价加速补丁（不改 lutgen_4code.py 源码，运行时替换一个内部函数）。

剖析结论（256x192，单线程约 2 s/张）：~85% 耗时在 _fill_empty_cells_lch，其中主要是对 65³ 网格里
~25 万个空格点做 cKDTree k=8 近邻查询。

本补丁的逐位等价依据：默认 fill_mode='identity_residual'、identity_sigma=0.08 时，原实现对
"最近已填格点距离 >= 2.5σ(=0.2)" 的空格点把残差乘 0，输出恰为 identity Lab（q_lab + 0）。
因此先用 3D 欧氏距离变换（~30 ms）找出这些格点直接写 identity，只对其余空格点做 KD 查询；
cKDTree 对每个查询点的结果与查询集合无关，其余计算逐行独立 → 输出与原实现逐位一致
（tests/selftest_lutgen_fast.py 用 np.array_equal 验证）。为防浮点边界误差，跳过条件留 1e-4 余量。
非默认参数（neighbor 模式 / sigma<=0）自动走原实现。

用法:
  import lutgen_4code as lg, lutgen_fast
  lutgen_fast.patch(lg)      # 之后 lg.build_lut_hres 即为加速版
"""
import numpy as np

_ORIG = {}


def make_fast_fill(lg):
    orig = lg._fill_empty_cells_lch

    def fill(lab_lut, filled, knn=8, *, fill_mode='identity_residual', identity_sigma=0.08):
        sigma = float(identity_sigma)
        if (str(fill_mode).strip().lower() != 'identity_residual' or sigma <= 0.0
                or bool(np.all(filled)) or not bool(np.any(filled))):
            return orig(lab_lut, filled, knn, fill_mode=fill_mode, identity_sigma=identity_sigma)
        from scipy import ndimage
        from scipy.spatial import cKDTree
        g = lab_lut.shape[0]
        ident_lab = lg._ident_lab(g)
        empty = ~filled
        far = empty & (ndimage.distance_transform_edt(empty) / (g - 1) >= 2.5 * sigma + 1e-4)
        lab_lut[far] = ident_lab[far]
        need = empty & ~far
        if not need.any():
            return lab_lut

        # ---- 以下与原实现相同，只是查询点限定为 need ----
        filled_ijk = np.argwhere(filled)
        empty_ijk = np.argwhere(need)
        scale = np.float32(g - 1)
        filled_rgb = filled_ijk.astype(np.float32) / scale
        empty_rgb = empty_ijk.astype(np.float32) / scale
        tree = cKDTree(filled_rgb)
        k_use = min(max(int(knn), 1), len(filled_ijk))
        dist, idx = tree.query(empty_rgb, k=k_use, workers=lg._INTRA_THREADS)
        if k_use == 1:
            dist = dist[:, None]
            idx = idx[:, None]
        q_lab = ident_lab[empty_ijk[:, 0], empty_ijk[:, 1], empty_ijk[:, 2]]
        d_lab = ident_lab[filled_ijk[:, 0], filled_ijk[:, 1], filled_ijk[:, 2]]
        q_c = np.hypot(q_lab[:, 1], q_lab[:, 2])
        d_c = np.hypot(d_lab[:, 1], d_lab[:, 2])
        q_h = np.degrees(np.arctan2(q_lab[:, 2], q_lab[:, 1])) % 360.0
        d_h = np.degrees(np.arctan2(d_lab[:, 2], d_lab[:, 1])) % 360.0
        hue_gap = lg._circ_hue_dist_deg(q_h[:, None], d_h[idx])
        chroma_keep = np.clip(q_c / 12.0, 0.0, 1.0)[:, None]
        hue_w = np.exp(-((hue_gap / 28.0) ** 2))
        hue_w = 1.0 - chroma_keep + chroma_keep * hue_w
        gray_w = 1.0 + (1.0 - chroma_keep) * np.clip(1.0 - d_c[idx] / 18.0, 0.0, 1.0)
        sig = np.maximum(dist[:, :1], 1e-4) * 1.25 + 1e-4
        ww = np.exp(-((dist / sig) ** 2)) * hue_w * gray_w
        ww /= np.maximum(ww.sum(axis=1, keepdims=True), 1e-8)
        filled_lab = lab_lut[filled_ijk[:, 0], filled_ijk[:, 1], filled_ijk[:, 2]]
        filled_resid = filled_lab - d_lab
        mixed_resid = np.einsum('nk,nkc->nc', ww.astype(np.float32), filled_resid[idx])
        nearest = dist[:, 0]
        fade = np.exp(-((nearest / sigma) ** 2)).astype(np.float32)
        fade[nearest >= (2.5 * sigma)] = 0.0
        mixed_resid = mixed_resid * fade[:, None]
        lab_lut[empty_ijk[:, 0], empty_ijk[:, 1], empty_ijk[:, 2]] = q_lab + mixed_resid
        return lab_lut

    return fill


def patch(lg):
    if not hasattr(lg, '_fill_empty_cells_lch'):  # 非 4_code 实现（如自测替身）则不处理
        return lg
    if id(lg) not in _ORIG:
        _ORIG[id(lg)] = lg._fill_empty_cells_lch
        lg._fill_empty_cells_lch = make_fast_fill(lg)
    return lg


def unpatch(lg):
    if id(lg) in _ORIG:
        lg._fill_empty_cells_lch = _ORIG.pop(id(lg))
    return lg
