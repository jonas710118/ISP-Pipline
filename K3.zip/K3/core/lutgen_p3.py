# -*- coding: utf-8 -*-
"""把 4_code（lutgen_4code.py）的色彩解释切换到 Display P3（运行时补丁，不改 lutgen_4code.py 源码）。

4_code 内部所有 RGB↔Lab 都经模块全局 RGB_TO_XYZ（sRGB 矩阵）与 gamma_decode（默认 sRGB 曲线）：
  rgb_to_lab / _lab_from_linear（含 bgr_u8_to_lab_image）/ lab_to_rgb（运行时求逆）/ _ident_lab 缓存。
Display P3 与 sRGB 传输曲线相同、白点同为 D65，只是原色不同，因此只需把 RGB_TO_XYZ 换成 P3 矩阵并清空
identity Lab 缓存，拟合算法本身（权重、溅射、Huber、填空格、平滑、主色对阈值）完全不变。

用法:
  import lutgen_4code as lg, lutgen_p3
  lutgen_p3.patch_p3(lg)        # 之后 build_lut_hres / apply_lut 即为 P3 口径
"""
import numpy as np

P3_TO_XYZ = np.array([[0.4865709486482162, 0.26566769316909306, 0.1982172852343625],
                      [0.2289745640697488, 0.6917385218365064, 0.079286914093745],
                      [0.0, 0.04511338185890264, 1.043944368900976]])


def patch_p3(lg):
    if getattr(lg, '_K3_P3', False):
        return lg
    if not hasattr(lg, 'RGB_TO_XYZ'):  # 非 4_code 实现（如自测替身）
        return lg
    if getattr(lg, '_GAMMA_CONFIG', None) is not None:
        raise RuntimeError(f'lutgen_4code 当前 gamma={lg._GAMMA_CONFIG}，Display P3 需要 sRGB 传输曲线（gamma=None）')
    lg._SRGB_RGB_TO_XYZ = lg.RGB_TO_XYZ
    lg.RGB_TO_XYZ = P3_TO_XYZ.astype(np.float32)
    if hasattr(lg, '_IDENT_LAB_CACHE'):
        lg._IDENT_LAB_CACHE.update(key='__init__', g=-1, table=None)
    lg._K3_P3 = True
    return lg
