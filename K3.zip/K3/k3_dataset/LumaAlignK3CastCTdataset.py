# -*- coding: utf-8 -*-
"""K3（Display P3）偏色训练 dataset：偏色 GT（= style）来自离线偏色图，或在线由 K3 偏色模型生成。

与 k2 版（LumaAlignK2CastCTdataset）逻辑完全相同，区别只在色彩解释：所有输入图须为 Display P3 编码，
偏色生成 / 色域收缩 / 可选 4_code 检查都按 P3 计算（k3_cast + k3_color_ops，模型 cast_model_p3.json）。

用于"是否需要 4_code 筛选"的 A/B 实验（方案三），三组只差训练数据来源:
  A  cast_source='online',  check_mode='none'       在线生成，不筛选（多样性不限）
  B1 cast_source='offline', offline_list=all_list.txt     离线 10 组/图，全部使用
  B2 cast_source='offline', offline_list=passed_list.txt  离线 10 组/图，只用 4_code le2>=0.95 的
离线偏色由 k3_offline/gen_offline_casts.py 生成（文件名 <content名>_c<k>.png）。

K3 偏色模型（cast_model_p3.json，来自 P3 口径的真实 content/多光谱 style 配对统计）:
  整图 OKLab ab 平移 t（灰区也偏）+ 24 档色相残差 dH(H) + 乘法饱和度增益 C·(1+g(H))；
  低秩高斯 × t 分布尺度混合采样；色相单调保护；色域外固定 L、色相只收缩 C。L 不变。

每个训练样本（与 LumaAlignGtDegHueBinK1CTdataset 的流程一致）:
  1. 基类读 content（style_dir=None 时 style/GT 读 gt_dir，仅占位）
  2. 以概率 cast_prob 得到偏色 GT:
       offline: 从该 content 的偏色图里随机取一张（尺寸与 content 不同时按 _resize_lr 缩放）
       online : 采样偏色参数 → 渲染（cast_render='pixel'|'lut'）→ 可选质量门 check_mode
                ('none' | 'proxy' | '4code'，不通过向恒等收缩重试，仍失败按 check_fail 处理)
  3. style = 偏色 GT（无 gt_degrade、无 FOV）；content / content_source 不变
验证集请用 LumaAlignCTdataset（真实配对），本类 test_mode 下默认不偏色（cast_in_test=False）。

依赖（与本文件同目录）: k3_cast.py、k3_color_ops.py、cast_model_p3.json；
check_mode='4code' 另需 lutgen_4code.py、lutgen_fast.py、lutgen_p3.py 与 scikit-image。
"""
import os.path as osp

import numpy as np

from mmedit.datasets.registry import DATASETS

from . import k3_cast as kc
from .lumaAlignCTdataset import LumaAlignCTdataset

_LOG = '[LumaAlignK3Cast]'


@DATASETS.register_module()
class LumaAlignK3CastCTdataset(LumaAlignCTdataset):

    def __init__(self, *args,
                 cast_source='online',
                 cast_prob=1.0,
                 cast_in_test=False,
                 cast_seed=None,
                 cast_debug=False,
                 # ---- offline ----
                 offline_cast_dir=None,
                 offline_list=None,
                 offline_drop_missing=True,
                 # ---- online ----
                 cast_model=None,
                 cast_from_content=True,
                 cast_dev_scale=1.0,
                 cast_mean_scale=1.0,
                 cast_nu=None,
                 cast_min_slope=0.3,
                 cast_dh_c_ramp=0.0,
                 cast_render='pixel',
                 cast_lut_size=33,
                 check_mode='none',
                 check_threshold=None,
                 check_max_retry=3,
                 check_shrink=0.7,
                 check_fail='identity',
                 **kwargs):
        if cast_source not in ('online', 'offline'):
            raise ValueError(f"{_LOG} cast_source 须为 'online' | 'offline'")
        if not 0.0 <= float(cast_prob) <= 1.0:
            raise ValueError(f'{_LOG} cast_prob 须在 [0,1]')
        if cast_render not in ('pixel', 'lut'):
            raise ValueError(f"{_LOG} cast_render 须为 'pixel' | 'lut'")
        if check_mode not in ('none', 'proxy', '4code'):
            raise ValueError(f"{_LOG} check_mode 须为 'none' | 'proxy' | '4code'")
        if check_fail not in ('identity', 'last'):
            raise ValueError(f"{_LOG} check_fail 须为 'identity' | 'last'")
        self.cast_source = cast_source
        self.cast_prob = float(cast_prob)
        self.cast_in_test = bool(cast_in_test)
        self.cast_seed = cast_seed
        self.cast_debug = bool(cast_debug)
        self.cast_from_content = bool(cast_from_content)
        self.offline_cast_dir = offline_cast_dir
        self._offline = None
        if cast_source == 'offline':
            self._offline = self._load_offline_list(offline_cast_dir, offline_list)
        else:
            self.cast = kc.CastModel(cast_model)
            self.cast_dev_scale = float(cast_dev_scale)
            self.cast_mean_scale = float(cast_mean_scale)
            self.cast_nu = cast_nu
            self.cast_min_slope = float(cast_min_slope)
            self.cast_dh_c_ramp = float(cast_dh_c_ramp)
            self.cast_render = cast_render
            self.cast_lut_size = int(cast_lut_size)
            self.check_mode = check_mode
            self.check_threshold = (float(check_threshold) if check_threshold is not None
                                    else {'proxy': 0.99, '4code': 0.95}.get(check_mode, 0.0))
            self.check_max_retry = max(0, int(check_max_retry))
            self.check_shrink = float(check_shrink)
            self.check_fail = check_fail
        self._cur_name = None
        self._rng_counter = 0
        self._stat = dict(n=0, cast=0, retry=0, fail=0, missing=0)
        super().__init__(*args, **kwargs)
        if self._offline is not None and offline_drop_missing and not self.test_mode:
            n0 = len(self.data_infos)
            self.data_infos = [d for d in self.data_infos if d['img_name'] in self._offline]
            print(f'{_LOG} 离线模式: 训练列表 {n0} 张 → 有偏色图的 {len(self.data_infos)} 张'
                  f'（丢弃 {n0 - len(self.data_infos)} 张无偏色图的 content）')
        if cast_source == 'offline':
            print(f'{_LOG} cast_source=offline dir={offline_cast_dir} list={offline_list} prob={self.cast_prob}')
        else:
            print(f"{_LOG} cast_source=online kh={self.cast.cfg.get('kh')} kg={self.cast.cfg.get('kg')} "
                  f"nu={self.cast_nu or self.cast.nu} prob={self.cast_prob} dev_scale={self.cast_dev_scale} "
                  f"mean_scale={self.cast_mean_scale} render={self.cast_render} check={self.check_mode}"
                  f"(thr={self.check_threshold}, retry={self.check_max_retry}, shrink={self.check_shrink}, "
                  f"fail={self.check_fail}) from_content={self.cast_from_content}")

    # ------------------------------------------------------------------ 工具
    @staticmethod
    def _load_offline_list(cast_dir, list_file):
        if not cast_dir or not list_file:
            raise ValueError(f"{_LOG} cast_source='offline' 需要 offline_cast_dir 与 offline_list")
        index = {}
        n = 0
        with open(list_file, 'r', encoding='utf-8') as f:
            for ln in f:
                fn = ln.strip()
                if not fn:
                    continue
                stem = osp.splitext(fn)[0]
                if '_c' not in stem:
                    raise ValueError(f'{_LOG} 偏色图文件名须为 <content名>_c<k>.<ext>，got {fn}')
                index.setdefault(stem.rsplit('_c', 1)[0], []).append(fn)
                n += 1
        print(f'{_LOG} 离线偏色列表 {list_file}: {n} 张偏色图 / {len(index)} 张 content')
        return index

    def _load_group_images(self, group, img_name):
        self._cur_name = img_name
        return super()._load_group_images(group, img_name)

    def _rng(self):
        if self.cast_seed is None:
            return np.random.default_rng()
        wid = 0
        try:
            import torch.utils.data as tud
            info = tud.get_worker_info()
            wid = info.id if info is not None else 0
        except Exception:  # noqa: BLE001
            pass
        self._rng_counter += 1
        return np.random.default_rng([int(self.cast_seed), wid, self._rng_counter])

    def _render(self, base, x):
        kw = dict(dh_c_ramp=self.cast_dh_c_ramp)
        if self.cast_render == 'lut':
            return kc.apply_lut(base, kc.cast_lut(x, self.cast_lut_size, **kw))
        return kc.apply_cast(base, x, **kw)[0]

    def _passes(self, content, base, gt, x):
        if self.check_mode == 'none':
            return True, 1.0
        if self.check_mode == 'proxy':
            score = (1.0 if self.cast_render == 'lut' else
                     kc.proxy_metrics(base, gt, x, self.cast_lut_size, dh_c_ramp=self.cast_dh_c_ramp)['grid_le2'])
        else:
            score = kc.le2_4code(content, gt)
        return score >= self.check_threshold, score

    def _online_cast(self, content, base, rng):
        x0, _ = kc.protect(self.cast.sample(rng, self.cast_dev_scale, self.cast_mean_scale, self.cast_nu),
                           min_slope=self.cast_min_slope)
        gt = score = x = None
        for attempt in range(self.check_max_retry + 1):
            x = kc.shrink(x0, self.check_shrink ** attempt)
            gt = self._render(base, x)
            ok, score = self._passes(content, base, gt, x)
            if ok:
                return gt, x, score
            self._stat['retry'] += 1
        self._stat['fail'] += 1
        if self.check_fail == 'identity':
            return np.array(base, dtype=np.float32, copy=True), None, score
        return gt, x, score

    def _offline_cast(self, content, rng):
        files = self._offline.get(self._cur_name)
        if not files:
            self._stat['missing'] += 1
            return None, None
        fn = files[int(rng.integers(len(files)))]
        gt = self._load_image(osp.join(self.offline_cast_dir, fn))
        if gt.shape[:2] != content.shape[:2]:
            gt = self._resize_lr(gt, content.shape[:2])
        return gt.astype(np.float32), fn

    # ------------------------------------------------------------------ hook
    def _color_aug_hook(self, content_img, content_source, style_img, content_gt, group=0):
        active = (not self.test_mode or self.cast_in_test) and self.cast_prob > 0
        if self.cast_source == 'offline' or (self.cast_from_content and not self.test_mode):
            content_gt = np.array(content_img, dtype=np.float32, copy=True)
        rng = self._rng()
        if active and rng.random() < self.cast_prob:
            self._stat['n'] += 1
            info = ''
            if self.cast_source == 'offline':
                gt, fn = self._offline_cast(content_img, rng)
                if gt is not None:
                    content_gt = gt
                    self._stat['cast'] += 1
                info = f'file={fn}'
            else:
                gt, x, score = self._online_cast(content_img, content_gt, rng)
                content_gt = gt
                if x is not None:
                    self._stat['cast'] += 1
                info = f'score={score:.3f} {kc.param_summary(x) if x is not None else "identity"}'
            if self.cast_debug and self._stat['n'] % 200 == 1:
                print(f"{_LOG} #{self._stat['n']} {self._cur_name} {info} 统计={self._stat}")
        style_img = np.array(content_gt, dtype=np.float32, copy=True)
        return content_img, content_source, style_img, content_gt
