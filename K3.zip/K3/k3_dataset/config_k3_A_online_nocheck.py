# -*- coding: utf-8 -*-
# 【K3 / Display P3】所有输入图（训练 content、val 的 content/style/GT/content_source）须先转换为 Display P3 编码，
#   下方 *_dir 变量请改成转换后的 P3 目录；偏色、色域收缩、可选 4_code 检查均按 P3 计算。
#   注意：模型自带的 val 指标（deltaE00 系列）与 pfl loss 由训练框架实现，若其内部按 sRGB 转 Lab/OKLab，
#   与 P3 数据不一致（loss 暂不处理；指标请用 k3_eval/eval_synth_real.py 的 P3 口径复核）。
# K3 偏色 A/B 实验（方案三）—— A 组：在线生成 K3 偏色，不做 4_code 筛选。
#
# 与 config.py（NAF_k1BEST_..._le2filter）的差异（白名单）：
#   1. exp_name / work_dir / debug_dir / save_path 改为 K3 A 组命名;
#   2. train_dataset_type='LumaAlignK3CastCTdataset'（K3 偏色：真实配对统计驱动的整图 ab 平移 +
#      24 档色相残差 + 乘法饱和度增益；cast_model_p3.json），cast_source='online'、check_mode='none';
#   3. 去掉 hc_aug / fov_aug / le2_filter（k1 参数，K3 不使用）。
# 其余（模型 / loss / 优化器 / 调度 / val / test / pipeline / 训练数据目录）与 config.py 完全一致。
# 三组（A / B1 / B2）只差训练数据来源，便于判断 4_code 筛选对 K3 偏色是否必要。
#
# 部署: 把 k3_dataset/ 下的 LumaAlignK3CastCTdataset.py、k3_cast.py、k3_color_ops.py、cast_model_p3.json（k3_stats 导出）、
#       lutgen_fast.py、lutgen_p3.py（lutgen_4code.py 该目录已有）拷到 adaint/datasets/，并在 adaint/datasets/__init__.py 中
#       from .LumaAlignK3CastCTdataset import LumaAlignK3CastCTdataset 完成注册。
# 建议训练启动前: export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1

exp_name = 'NAF_k3P3Cast_A_onlineNoCheck_synthFromContent_venus'

custom_imports=dict(
    imports=['adaint'],
    allow_failed_imports=False)

# 模型设置 — NAFCrossDiffAlignOptionalLorLUT: LoR-LUT 色彩迁移方案（与 config.py 一致）
# =============================================================================
model = dict(
    type='NAFCrossDiffAlignOptionalLorLUTModel',
    n_vertices=33,
    vgg_pretrained='NLUT-main/models/vgg_normalised.pth',

    # ----- Encoder + FiLM -----
    enc_width=16,
    enc_blocks=(1, 1, 1),
    color_dim=128,
    hist_bins=24,
    hist_sigma=0.05,
    hist_input_size=128,
    hist_stem_channels=32,
    use_color_film=False,
    block_type='split',

    # ----- LoR-LUT head -----
    lora_R=32,
    lut_levels=None,
    residual_scale=1.0,

    # ----- L+ab hist_diff 条件 -----
    use_hist_diff_lut=False,
    hist_cond_dim=64,
    l_hist_bins=32,
    ab_hist_na=32,
    ab_hist_nb=32,
    hist_diff_diff_mode='prob_diff',
    hist_diff_center_weighted=True,

    # ----- Cross-attn + diff_concat -----
    attn_dim=64,
    cross_attn_out_dim=128,
    cross_attn_pool_out=4,
    use_cross_attn=False,
    use_feat_diff_concat=True,
    diff_concat_mid=64,
    diff_concat_out_dim=128,
    diff_concat_pool_out=4,
    attn_fine_per_level=True,
    attn_spatial_size=8,
    attn_spatial_size_per_level=None,

    use_scale_align=False,
    use_input_geometry_align=False,
    use_feature_geometry_align=False,
    use_feature_flow=False,

    # ----- 损失权重 -----
    style_loss_type='gram',
    content_weight=0.0,
    style_weight=0.0,
    recons_weight=1.0,
    lambda_smooth=1.0,
    lambda_mn=10.0,
    pfl_weight=3.0,
    pfl_type='preserve_oklch',
    pfl_opt_kwargs=dict(
        lambda_L=1.5,
        hue_tol_deg=3.0,
        eta_h=3.0,
    ),
    region_aware_weight=0.0,
    residuallut_weight=0.0,
    reconlut_weight=0.0,
    histogram_weight=0.0,
    cosine_weight=0.0,
    deltaE_weight=0.0,
)

# =============================================================================
# 训练/测试设置
# =============================================================================

train_cfg = dict(
    n_fix_iters=4500 * 5,
    save_debug_images=False,
    debug_interval=1,
    debug_dir=f'./work_dirs/20261102/{exp_name}/debug_images',
)

test_cfg = dict(
    metrics=['PSNR', 'SSIM', 'deltaE00', 'deltaE00_nL', 'deltaE00_pct2', 'deltaE00_pct2_ge80', 'deltaE00_pct2_ge95',
             'deltaE76', 'deltaE00_mean_above2', 'deltaE00_pct2_neg_pct', 'deltaE00_pct2_neg_gap'],
    crop_border=0,
    save_image=True,
    save_path=f'./work_dirs/20261102/{exp_name}/test_results',
    skip_lut_save=True,
)

# =============================================================================
# 数据集设置
# =============================================================================

train_dataset_type = 'LumaAlignK3CastCTdataset'
val_dataset_type = 'LumaAlignCTdataset'

train_pipeline = [
    dict(type='ImageToTensor', keys=['content_img', 'style_img', 'content_gt', 'content_source']),
    dict(type='Collect',
         keys=['content_img', 'style_img', 'content_gt', 'content_source'],
         meta_keys=['lq_path', 'gt_path'])
]

test_pipeline = [
    dict(type='ImageToTensor', keys=['content_img', 'style_img', 'content_gt', 'content_source']),
    dict(type='Collect',
         keys=['content_img', 'style_img', 'content_gt', 'content_source'],
         meta_keys=['lq_path', 'gt_path'])
]

data_root_a = "/home/notebook/data/group/huanan/Sync/FP_RGB/GeneratorV10/datasets_noflat"
data_root_b = "/home/notebook/data/group/huanan/Sync/FP_RGB"
# ↓↓↓ 请改为 Display P3 版本的目录（默认值为原 sRGB 目录，仅作占位）
train_content_dir = f'{data_root_b}/Venus_Train_256x192'
train_img_ext = '.jpg'
val_content_dir = f'{data_root_a}/content_lr'
val_style_dir = f'{data_root_a}/style_lr/raw'
val_gt_dir = f'{data_root_a}/GT_LUT'
val_source_dir = f'{data_root_a}/content_LUT'
k3_dir = '/home/notebook/data/group/huanan/Sync/AI3DLUT_Training/adaint/datasets'  # cast_model_p3.json 所在目录

# K3 偏色（A 组：在线、不筛选）
cast_cfg = dict(
    cast_source='online',
    cast_model=f'{k3_dir}/cast_model_p3.json',
    cast_prob=1.0,
    cast_from_content=True,
    cast_dev_scale=1.0,       # 偏色多样性（相对真实统计）
    cast_mean_scale=1.0,      # 平均偏色（真实统计均值）缩放
    cast_min_slope=0.3,       # 色相单调保护（与离线生成一致）
    cast_render='pixel',      # 与离线生成一致
    check_mode='none',        # A 组：不做 4_code 筛选
    cast_seed=None,
    cast_debug=False,
)

data = dict(
    workers_per_gpu=16,
    train_dataloader=dict(samples_per_gpu=24),
    val_dataloader=dict(samples_per_gpu=1),
    test_dataloader=dict(samples_per_gpu=1, workers_per_gpu=1),

    train=[
        # style_dir=None 时基类构造校验要求 gt_deg_prob=1.0；K3 hook 内不做 gt_degrade，
        # style 直接取偏色 GT。gt_dir 只为满足读图接口，内容会被偏色 GT 覆盖。
        dict(
            type=train_dataset_type,
            content_dir=train_content_dir,
            style_dir=None,
            gt_dir=train_content_dir,
            content_source_dir=train_content_dir,
            img_ext=train_img_ext,
            gt_deg_prob=1.0,
            gt_deg_cfg=None,
            gt_deg_work_scale=1.0,
            gt_deg_debug=False,
            **cast_cfg,
            ann_file=f'{data_root_b}/train.txt',
            pipeline=train_pipeline,
            skip_lut=True,
            lut_size=33,
            test_mode=False,
            lr_size=None,
            p0_luma_enabled=False,
        ),
    ],
    val=dict(
        type=val_dataset_type,
        content_dir=[val_content_dir],
        style_dir=[val_style_dir],
        gt_dir=[val_gt_dir],
        content_source_dir=[val_source_dir],
        ann_file=f'{data_root_a}/test.txt',
        pipeline=test_pipeline,
        skip_lut=True,
        lut_size=33,
        test_mode=True,
        lr_size=None,
        p0_luma_enabled=False,
    ),
    test=dict(
        type=val_dataset_type,
        content_dir=[val_content_dir],
        style_dir=[val_style_dir],
        gt_dir=[val_gt_dir],
        content_source_dir=[val_source_dir],
        ann_file=f'{data_root_a}/test.txt',
        pipeline=test_pipeline,
        skip_lut=True,
        lut_size=33,
        test_mode=True,
        lr_size=None,
        p0_luma_enabled=False,
    ),
)

# =============================================================================
# 优化器 & 训练调度（与 config.py 一致）
# =============================================================================

optimizers = dict(
    type='Adam',
    lr=1e-4,
    weight_decay=0,
    betas=(0.9, 0.999),
    eps=1e-8,
)

lr_config = dict(policy='CosineAnnealing', min_lr=1e-6, by_epoch=False)

total_iters = 400000

checkpoint_config = dict(interval=800, save_optimizer=True, by_epoch=False)

evaluation = dict(interval=800, save_image=False)

log_config = dict(
    interval=10,
    hooks=[dict(type='TextLoggerHook', by_epoch=False)])

visual_config = None

# =============================================================================
# 运行时设置
# =============================================================================

dist_params = dict(backend='nccl')
log_level = 'INFO'
work_dir = f'./work_dirs/20261102/{exp_name}'
load_from = None
resume_from = None
workflow = [('train', 1)]
find_unused_parameters = True
