# -*- coding: utf-8 -*-
"""stat_style_residual 估计器自测：对合成参考图施加已知退化（几何/亮度/暗角/模糊/噪声），检查能否还原。

运行: cd G:/k1/K3/k3_degrade_stats && python tests/selftest_residual.py
"""
import os
import os.path as osp
import sys
import tempfile

import numpy as np
from PIL import Image
from scipy import ndimage

HERE = osp.dirname(osp.dirname(osp.abspath(__file__)))
sys.path.insert(0, HERE)
import k3_color_ops as co  # noqa: E402
import stat_style_residual as ssr  # noqa: E402

H, W = 192, 256


def make_ref(rng):
    img = np.zeros((H, W, 3))
    yy, xx = np.mgrid[0:H, 0:W]
    img[:] = rng.uniform(0.2, 0.8, 3)
    for _ in range(40):
        c = rng.uniform(0.05, 0.95, 3)
        if rng.random() < 0.5:
            cy, cx, r = rng.uniform(0, H), rng.uniform(0, W), rng.uniform(5, 30)
            m = (yy - cy) ** 2 + (xx - cx) ** 2 < r * r
        else:
            y0, x0 = rng.integers(0, H - 10), rng.integers(0, W - 10)
            m = (yy >= y0) & (yy < y0 + rng.integers(5, 50)) & (xx >= x0) & (xx < x0 + rng.integers(5, 60))
        img[m] = c
    return ndimage.gaussian_filter(img, (0.6, 0.6, 0))


def degrade(ref, p, rng):
    w = ssr.warp(ref, p['rot'], p['scale'], p['tx'], p['ty'])
    w = np.where(np.isfinite(w), w, ref)
    lab = co.rgb_to_oklab(w) * 100
    yy, xx = np.mgrid[0:H, 0:W]
    rho2 = (((yy - (H - 1) / 2) / ((H - 1) / 2)) ** 2 + ((xx - (W - 1) / 2) / ((W - 1) / 2)) ** 2) / 2
    lab[..., 0] = 50 + p['slope'] * (lab[..., 0] - 50) + p['offset'] + p['vig'] * rho2
    rgb = np.clip(co.oklab_to_rgb(lab / 100), 0, 1)
    rgb = ndimage.gaussian_filter(rgb, (p['blur'], p['blur'], 0))
    lab = co.rgb_to_oklab(rgb) * 100
    lab[..., 0] += rng.normal(0, p['nL'], (H, W))
    lab[..., 1:] += rng.normal(0, p['nc'], (H, W, 2))
    return np.clip(co.oklab_to_rgb(lab / 100), 0, 1)


def save(path, rgb):
    Image.fromarray(np.clip(np.round(rgb * 255), 0, 255).astype(np.uint8)).save(path)


def main():
    rng = np.random.default_rng(0)
    tmp = tempfile.mkdtemp()
    truth = dict(rot=0.8, scale=1.015, tx=3.2, ty=-2.1, slope=1.06, offset=1.5, vig=-4.0, blur=1.0, nL=0.8, nc=0.6)
    errs = {k: [] for k in ('rot_deg', 'scale', 'tx_px', 'ty_px', 'blur_sigma_px', 'tone_offset_L50',
                            'tone_slope_L50', 'vignette_L', 'noise_L_excess', 'noise_a_excess')}
    rows = []
    for i in range(6):
        ref = make_ref(rng)
        sty = degrade(ref, truth, rng)
        pr, ps = osp.join(tmp, f'r{i}.png'), osp.join(tmp, f's{i}.png')
        save(pr, ref)
        save(ps, sty)
        _, row, err = ssr.analyze_pair((f'p{i}', pr, ps, True))
        assert err is None, err
        rows.append(row)
    exp = dict(rot_deg=truth['rot'], scale=truth['scale'], tx_px=truth['tx'], ty_px=truth['ty'],
               blur_sigma_px=truth['blur'], tone_offset_L50=truth['offset'], tone_slope_L50=truth['slope'],
               vignette_L=truth['vig'], noise_L_excess=truth['nL'], noise_a_excess=truth['nc'])
    tol = dict(rot_deg=0.1, scale=0.004, tx_px=0.3, ty_px=0.3, blur_sigma_px=0.3, tone_offset_L50=0.8,
               tone_slope_L50=0.04, vignette_L=1.5, noise_L_excess=0.35, noise_a_excess=0.3)
    ok_all = True
    for k, e in exp.items():
        v = np.array([r[k] for r in rows])
        ok = abs(np.median(v) - e) <= tol[k]
        ok_all &= ok
        print(f"[{'PASS' if ok else 'FAIL'}] {k:16s} 真值 {e:+.3f}  估计中位 {np.median(v):+.3f}  范围 "
              f"[{v.min():+.3f}, {v.max():+.3f}]")
    print(f"对齐后 NCC 中位 {np.median([r['ncc_aligned'] for r in rows]):.3f}；"
          f"局部残差错位 p50 中位 {np.nanmedian([r['local_shift_p50'] for r in rows]):.2f}px（真值 0）")
    sys.exit(0 if ok_all else 1)


if __name__ == '__main__':
    main()
