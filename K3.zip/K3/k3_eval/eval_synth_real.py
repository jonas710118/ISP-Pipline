# -*- coding: utf-8 -*-
"""K3（Display P3）合成 val vs 真实 val 精度对比（诊断"训练/验证域差" vs "模型能力不足"）。

所有图须为 Display P3 编码。
合成 val: 用真实 val 的 content 图做 K3 偏色（固定 seed），style = GT = 偏色图（与训练同分布）。
真实 val: config 中 data.test 的真实配对（content / style_raw / GT）。
两者都用模型自带的评测（test_cfg.metrics，与训练日志 val 指标同一实现；注意框架内部可能按 sRGB 转 Lab）。
另给出 P3 口径（本目录 k3_color_ops：P3→XYZ→CIELab→dE00）的指标:
  - 恒等输出（output=content）基线，判断模型相对"不调色"提升了多少；
  - --p3-from-outputs：让模型把输出图存盘（single_gpu_test save_image），再按 P3 口径算 dE00 均值 / pct2，
    与框架指标对照（框架若按 sRGB 计算，两者会有差异）。

运行（在训练代码仓库根目录，保证能 import adaint 与 vgg 等相对路径）:
  python /path/to/k3_eval/eval_synth_real.py --config configs/xxx.py --checkpoint work_dirs/.../iter_xxx.pth \
      --content-dir /home/notebook/data/group/huanan/Sync/FP_RGB/GeneratorV10/datasets_noflat/content_lr
可选: --n-casts 2（每张 content 的合成偏色数）--out-dir ./k3_eval_out --skip-real --gpu 0 --p3-from-outputs
      --style-dir/--gt-dir/--source-dir/--ann-file 覆盖真实 val 的目录（默认取 config 的 data.test）
本机无 mmedit 时可用 --dry-run 只生成合成集并计算恒等基线。

输出（--out-dir）: synth/（合成集图像与 ann）、summary.txt、per_sample_synth.csv、per_sample_real.csv
"""
import argparse
import copy
import csv
import json
import os
import os.path as osp
import sys
import zlib

import numpy as np

HERE = osp.dirname(osp.abspath(__file__))
sys.path.insert(0, HERE)
import k3_cast as kc  # noqa: E402
import k3_color_ops as co  # noqa: E402

IMG_EXTS = ('.png', '.jpg', '.jpeg', '.bmp', '.tif', '.tiff')


def read_rgb(path):
    try:
        import cv2
        img = cv2.imread(path, cv2.IMREAD_UNCHANGED)
        if img is None:
            raise ValueError(path)
        img = cv2.cvtColor(img[..., :3], cv2.COLOR_BGR2RGB)
        return np.clip(img.astype(np.float32) / (65535.0 if img.dtype == np.uint16 else 255.0), 0, 1)
    except ImportError:
        from PIL import Image
        return np.asarray(Image.open(path).convert('RGB'), dtype=np.float32) / 255.0


def write_png(path, rgb):
    u8 = np.clip(np.round(rgb * 255.0), 0, 255).astype(np.uint8)
    try:
        import cv2
        cv2.imwrite(path, cv2.cvtColor(u8, cv2.COLOR_RGB2BGR))
    except ImportError:
        from PIL import Image
        Image.fromarray(u8).save(path)


def find_img(d, name):
    for ext in IMG_EXTS:
        p = osp.join(d, name + ext)
        if osp.exists(p):
            return p
    return None


def identity_pct2(content_dir, gt_dir, names):
    """P3 口径：output=content 时 dE00(content, GT)<=2 占比（逐图）与 dE00 均值。"""
    out = []
    for n in names:
        pc, pg = find_img(content_dir, n), find_img(gt_dir, n)
        if pc is None or pg is None:
            continue
        c, g = read_rgb(pc), read_rgb(pg)
        if c.shape != g.shape:
            continue
        de = co.ciede2000(co.rgb_to_cielab(g), co.rgb_to_cielab(c))
        out.append((n, float((de <= 2).mean() * 100), float(de.mean())))
    return out


def make_synth(content_dir, names, out_dir, n_casts, seed, model_path):
    model = kc.CastModel(model_path)
    d = {k: osp.join(out_dir, 'synth', k) for k in ('content', 'style', 'gt')}
    for p in d.values():
        os.makedirs(p, exist_ok=True)
    synth_names = []
    for n in names:
        p = find_img(content_dir, n)
        if p is None:
            continue
        c = read_rgb(p)
        for k in range(n_casts):
            rng = np.random.default_rng([seed, zlib.crc32(n.encode()), k])
            x, _ = kc.protect(model.sample(rng))
            g = kc.apply_cast(c, x)[0]
            sn = f'{n}_c{k}'
            write_png(osp.join(d['content'], sn + '.png'), c)
            write_png(osp.join(d['style'], sn + '.png'), g)
            write_png(osp.join(d['gt'], sn + '.png'), g)
            synth_names.append(sn)
    ann = osp.join(out_dir, 'synth', 'synth.txt')
    with open(ann, 'w', encoding='utf-8') as f:
        f.write('\n'.join(synth_names) + '\n')
    return d, ann, synth_names


def as_list(v):
    return list(v) if isinstance(v, (list, tuple)) else [v]


def find_output(save_dir, name):
    """在模型输出目录中找名为 name 的图（文件名等于 name，或以 name 开头且后接非字母数字字符）。"""
    hits = []
    for root, _, files in os.walk(save_dir):
        for f in files:
            st, ext = osp.splitext(f)
            if ext.lower() not in IMG_EXTS:
                continue
            if st == name or (st.startswith(name) and not st[len(name)].isalnum()):
                hits.append(osp.join(root, f))
    return sorted(hits, key=len)[0] if hits else None


def p3_metrics_from_outputs(save_dir, gt_dir, names):
    rows = []
    for n in names:
        po, pg = find_output(save_dir, n), find_img(gt_dir, n.replace('_swap', ''))
        if po is None or pg is None:
            continue
        o, g = read_rgb(po), read_rgb(pg)
        if o.shape != g.shape:
            continue
        de = co.ciede2000(co.rgb_to_cielab(g), co.rgb_to_cielab(o))
        rows.append(dict(name=n, p3_dE00=float(de.mean()), p3_pct2=float((de <= 2).mean() * 100)))
    return rows


def run_model_eval(cfg, model, ds_cfg, save_dir=None):
    from mmedit.apis import single_gpu_test
    from mmedit.datasets import build_dataloader, build_dataset
    dataset = build_dataset(ds_cfg)
    loader = build_dataloader(dataset, samples_per_gpu=1, workers_per_gpu=2, dist=False, shuffle=False)
    if save_dir:
        os.makedirs(save_dir, exist_ok=True)
        results = single_gpu_test(model, loader, save_image=True, save_path=save_dir)
    else:
        results = single_gpu_test(model, loader, save_image=False)
    names = [info['img_name'] + info.get('suffix', '') for info in dataset.data_infos]
    agg = dataset.evaluate(results)
    per = [dict(name=n, **{k: float(v) for k, v in r.get('eval_result', {}).items()
                           if isinstance(v, (int, float, np.floating))})
           for n, r in zip(names, results)]
    p3 = p3_metrics_from_outputs(save_dir, as_list(ds_cfg['gt_dir'])[0], names) if save_dir else []
    return agg, per, p3


def build_model(cfg, checkpoint, gpu):
    import torch
    from mmcv.parallel import MMDataParallel
    from mmcv.runner import load_checkpoint
    from mmedit.models import build_model as _build
    model = _build(cfg.model, train_cfg=None, test_cfg=cfg.test_cfg)
    load_checkpoint(model, checkpoint, map_location='cpu')
    torch.cuda.set_device(gpu)
    return MMDataParallel(model.cuda(gpu), device_ids=[gpu]).eval()


def write_csv(path, rows):
    if not rows:
        return
    keys = list(dict.fromkeys(k for r in rows for k in r))
    with open(path, 'w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        for r in rows:
            w.writerow({k: (f'{v:.6g}' if isinstance(v, float) else v) for k, v in r.items()})


def pct_str(v):
    v = np.asarray(v, dtype=float)
    return '/'.join(f'{np.percentile(v, q):.1f}' for q in (5, 25, 50, 75, 95)) if len(v) else 'nan'


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--config', default='')
    ap.add_argument('--checkpoint', default='')
    ap.add_argument('--content-dir', required=True, help='真实 val 的 content 目录（合成 val 用它做偏色）')
    ap.add_argument('--style-dir', default='')
    ap.add_argument('--gt-dir', default='')
    ap.add_argument('--source-dir', default='')
    ap.add_argument('--ann-file', default='')
    ap.add_argument('--n-casts', type=int, default=2)
    ap.add_argument('--seed', type=int, default=12345)
    ap.add_argument('--cast-model', default=osp.join(HERE, 'cast_model_p3.json'))
    ap.add_argument('--out-dir', default='./k3_eval_out')
    ap.add_argument('--gpu', type=int, default=0)
    ap.add_argument('--skip-real', action='store_true')
    ap.add_argument('--dry-run', action='store_true', help='不跑模型，只生成合成集与恒等基线')
    ap.add_argument('--p3-from-outputs', action='store_true',
                    help='保存模型输出图并按 P3 口径计算 dE00 / pct2（与框架指标对照）')
    args = ap.parse_args()
    os.makedirs(args.out_dir, exist_ok=True)

    cfg = None
    test = {}
    if args.config:
        from mmcv import Config
        cfg = Config.fromfile(args.config)
        if cfg.get('custom_imports'):
            from mmcv.utils import import_modules_from_strings
            import_modules_from_strings(**cfg['custom_imports'])
        test = copy.deepcopy(cfg.data.test)
    style_dir = args.style_dir or as_list(test.get('style_dir', ['']))[0]
    gt_dir = args.gt_dir or as_list(test.get('gt_dir', ['']))[0]
    src_dir = args.source_dir or as_list(test.get('content_source_dir', [args.content_dir]))[0] or args.content_dir
    ann = args.ann_file or test.get('ann_file', '')
    if ann:
        with open(ann, 'r', encoding='utf-8') as f:
            names = [ln.strip() for ln in f if ln.strip()]
    else:
        names = sorted(osp.splitext(f)[0] for f in os.listdir(args.content_dir) if f.lower().endswith(IMG_EXTS))
    print(f'val content {len(names)} 张；真实配对 style={style_dir} gt={gt_dir}')

    sd, synth_ann, synth_names = make_synth(args.content_dir, names, args.out_dir, args.n_casts, args.seed,
                                            args.cast_model)
    print(f'合成 val: {len(synth_names)} 对 -> {osp.join(args.out_dir, "synth")}')
    id_syn = identity_pct2(sd['content'], sd['gt'], synth_names)
    id_real = identity_pct2(src_dir, gt_dir, names) if gt_dir and osp.isdir(gt_dir) else []

    L = ['=' * 90, 'K3（Display P3）合成 val vs 真实 val', '=' * 90,
         f'config={args.config}', f'checkpoint={args.checkpoint}', f'content={args.content_dir}',
         f'合成: {len(synth_names)} 对（每图 {args.n_casts} 组，seed={args.seed}）；真实: style={style_dir} gt={gt_dir}', '',
         '[恒等基线 output=content，P3 口径 dE00]  pct2 均值 | 逐图 pct2 p5/p25/p50/p75/p95 | dE00 均值',
         f'  合成 val: {np.mean([r[1] for r in id_syn]):6.2f} | {pct_str([r[1] for r in id_syn])} | '
         f'{np.mean([r[2] for r in id_syn]):.2f}' if id_syn else '  合成 val: 无',
         f'  真实 val: {np.mean([r[1] for r in id_real]):6.2f} | {pct_str([r[1] for r in id_real])} | '
         f'{np.mean([r[2] for r in id_real]):.2f}' if id_real else '  真实 val: 无（gt 目录不可用）']

    if not args.dry_run:
        if cfg is None or not args.checkpoint:
            sys.exit('需要 --config 与 --checkpoint（或使用 --dry-run）')
        cfg.test_cfg.save_image = False
        model = build_model(cfg, args.checkpoint, args.gpu)
        syn_cfg = copy.deepcopy(test)
        syn_cfg.update(content_dir=[sd['content']], style_dir=[sd['style']], gt_dir=[sd['gt']],
                       content_source_dir=[sd['content']], ann_file=synth_ann, img_ext='.png', test_mode=True)
        sv = (lambda tag: osp.join(args.out_dir, f'outputs_{tag}')) if args.p3_from_outputs else (lambda tag: None)
        agg_s, per_s, p3_s = run_model_eval(cfg, model, syn_cfg, sv('synth'))
        write_csv(osp.join(args.out_dir, 'per_sample_synth.csv'), per_s)
        write_csv(osp.join(args.out_dir, 'p3_metrics_synth.csv'), p3_s)
        agg_r, per_r, p3_r = {}, [], []
        if not args.skip_real:
            real_cfg = copy.deepcopy(test)
            if args.style_dir or args.gt_dir or args.source_dir or args.ann_file:
                real_cfg.update(content_dir=[args.content_dir], style_dir=[style_dir], gt_dir=[gt_dir],
                                content_source_dir=[src_dir], ann_file=ann)
            agg_r, per_r, p3_r = run_model_eval(cfg, model, real_cfg, sv('real'))
            write_csv(osp.join(args.out_dir, 'per_sample_real.csv'), per_r)
            write_csv(osp.join(args.out_dir, 'p3_metrics_real.csv'), p3_r)
        L += ['', '[模型评测（test_cfg.metrics，与训练日志 val 同实现）]   合成 val   |   真实 val']
        for k in sorted(set(agg_s) | set(agg_r)):
            vs, vr = agg_s.get(k, float('nan')), agg_r.get(k, float('nan'))
            L.append(f'  {k:28s} {vs:10.4f}   | {vr:10.4f}')
        key = next((k for k in ('deltaE00_pct2', 'PSNR') if per_s and k in per_s[0]), None)
        if key:
            L.append(f'  逐图 {key} p5/p25/p50/p75/p95: 合成 {pct_str([r[key] for r in per_s])} | '
                     f'真实 {pct_str([r[key] for r in per_r]) if per_r else "nan"}')
        if args.p3_from_outputs:
            def p3line(tag, rows):
                if not rows:
                    return f'  {tag}: 未在输出目录中找到可匹配的输出图（请检查 outputs_* 的文件命名）'
                return (f"  {tag}: 匹配 {len(rows)} 张 | dE00 均值 {np.mean([r['p3_dE00'] for r in rows]):.3f} | "
                        f"pct2 均值 {np.mean([r['p3_pct2'] for r in rows]):.2f} | 逐图 pct2 "
                        f"{pct_str([r['p3_pct2'] for r in rows])}")
            L += ['', '[P3 口径（模型输出图 vs GT，k3_color_ops）]', p3line('合成 val', p3_s), p3line('真实 val', p3_r)]
        L += ['', '判读: 合成 val 高（如 pct2>=90）而真实 val 明显低 → 主要是训练/验证域差（style 退化、错位、亮度等），'
              '应加仿真降质；合成 val 也不高 → 先查模型能力/训练设置。']
        with open(osp.join(args.out_dir, 'metrics.json'), 'w', encoding='utf-8') as f:
            json.dump(dict(synth=agg_s, real=agg_r), f, ensure_ascii=False, indent=1, default=float)
    text = '\n'.join(L)
    with open(osp.join(args.out_dir, 'summary.txt'), 'w', encoding='utf-8') as f:
        f.write(text + '\n')
    print(text)


if __name__ == '__main__':
    main()
