# -*- coding: utf-8 -*-
"""K3（Display P3）版：统计真实配对中 style_raw 相对参考图（GT 或 content）的退化残差分布，用于设定 style
仿真降质 pipeline。输入图须为 Display P3 编码，L/ab/dE00 均按 P3 解释（k3_color_ops）。

参考图建议用 GT（与 content 同几何、颜色已接近 style）：此时颜色差异小，几何/模糊/噪声/亮度估计更稳；
没有 GT 时用 content（只做与颜色无关的几何、模糊、噪声、亮度统计，颜色残差项不可信）。
只依赖 numpy / scipy（读图优先 cv2，退回 PIL）。

逐对估计（单位: 像素按参考图分辨率；L 为 OKLab L×100；ab 为 OKLab ab×100）:
  几何  style ≈ warp(ref; θ, s, tx, ty)，q = s·R(θ)(p - c) + c + t（相似变换，梯度图 NCC 优化）
        局部残差错位（分块相位相关，去掉全局变换后的视差/形变）中位与 p90
  亮度  Ls ≈ a0 + a1·Lr + a2·Lr²（低通后拟合）：L=50 处偏移、斜率、曲率
        低频亮度场 = 低通(Ls - tone(Lr))：径向暗角系数（角点相对中心，L×100）与去暗角后的场 std
  模糊  高频匹配的等效高斯 σ（>0: style 更模糊；<0: style 更锐）
  噪声  平坦区高频残差 MAD 估计：style 与参考图各自的 L/ab 噪声 std 及 style 额外噪声
  颜色  （ref=GT 时）对齐后 Δab 全局均值、低频空间 std、dE00<=2 占比（LUT 无法解释的颜色残差）
  其他  对齐后 NCC（对齐质量）、style 过曝欠曝比例、尺寸比

用法:
  python stat_style_residual.py --content-dir .../content_lr --style-dir .../style_lr/raw \
      --gt-dir .../GT_LUT --ann-file .../test.txt --out-dir ./style_residual --workers 16
输出: per_pair.csv、summary.txt（各量 p5/p25/p50/p75/p95）、summary.json —— 均为文本，可直接回传
"""
import argparse
import csv
import json
import os
import os.path as osp
import sys
from multiprocessing import Pool

for _v in ('OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'OPENBLAS_NUM_THREADS'):
    os.environ.setdefault(_v, '1')

import numpy as np  # noqa: E402
from scipy import ndimage, optimize  # noqa: E402

HERE = osp.dirname(osp.abspath(__file__))
sys.path.insert(0, HERE)
import k3_color_ops as co  # noqa: E402

IMG_EXTS = ('.png', '.jpg', '.jpeg', '.bmp', '.tif', '.tiff')


def read_rgb(path):
    try:
        import cv2
        img = cv2.imread(path, cv2.IMREAD_UNCHANGED)
        if img is None:
            raise ValueError(f'读图失败: {path}')
        img = cv2.cvtColor(img[..., :3], cv2.COLOR_BGR2RGB)
        return np.clip(img.astype(np.float64) / (65535.0 if img.dtype == np.uint16 else 255.0), 0, 1)
    except ImportError:
        from PIL import Image
        return np.asarray(Image.open(path).convert('RGB'), dtype=np.float64) / 255.0


def resize_to(img, hw):
    if img.shape[:2] == tuple(hw):
        return img
    zh, zw = hw[0] / img.shape[0], hw[1] / img.shape[1]
    return np.clip(ndimage.zoom(img, (zh, zw, 1), order=1), 0, 1)


def find_img(d, name):
    for ext in IMG_EXTS:
        p = osp.join(d, name + ext)
        if osp.exists(p):
            return p
    return None


# ----------------------------------------------------------------------------- 几何
def warp(img, theta, s, tx, ty, order=1, cval=np.nan):
    """q = s·R(θ)(p - c) + c + t：输出（style 坐标）q 处取输入（ref）p = R(-θ)(q - c - t)/s + c。"""
    h, w = img.shape[:2]
    c = np.array([(h - 1) / 2.0, (w - 1) / 2.0])
    th = np.radians(theta)
    # 坐标顺序 (row, col)：图像 x=col、y=row，逆时针为正时 R 在 (row,col) 下取转置
    R_inv = np.array([[np.cos(th), -np.sin(th)], [np.sin(th), np.cos(th)]]) / s
    t = np.array([ty, tx])
    offset = c - R_inv @ (c + t)
    if img.ndim == 2:
        return ndimage.affine_transform(img, R_inv, offset=offset, order=order, mode='constant', cval=cval)
    return np.stack([ndimage.affine_transform(img[..., k], R_inv, offset=offset, order=order, mode='constant',
                                              cval=cval) for k in range(img.shape[2])], -1)


def grad_mag(L, sigma=1.0):
    Ls = ndimage.gaussian_filter(L, sigma)
    return np.hypot(ndimage.sobel(Ls, 0), ndimage.sobel(Ls, 1))


def ncc(a, b, m):
    a, b = a[m], b[m]
    a = a - a.mean()
    b = b - b.mean()
    return float((a * b).sum() / (np.sqrt((a * a).sum() * (b * b).sum()) + 1e-12))


def phase_shift(a, b):
    """b ≈ a 平移 (dy, dx)，相位相关 + 抛物线亚像素。"""
    win = np.outer(np.hanning(a.shape[0]), np.hanning(a.shape[1]))
    A = np.fft.fft2((a - a.mean()) * win)
    B = np.fft.fft2((b - b.mean()) * win)
    Rm = B * np.conj(A)
    r = np.real(np.fft.ifft2(Rm / (np.abs(Rm) + 1e-9)))
    iy, ix = np.unravel_index(np.argmax(r), r.shape)

    def sub(i, n, get):
        y0, y1, y2 = get((i - 1) % n), get(i), get((i + 1) % n)
        d = (y0 - 2 * y1 + y2)
        return i + (0.5 * (y0 - y2) / d if abs(d) > 1e-12 else 0.0)
    dy = sub(iy, r.shape[0], lambda k: r[k, ix])
    dx = sub(ix, r.shape[1], lambda k: r[iy, k])
    if dy > r.shape[0] / 2:
        dy -= r.shape[0]
    if dx > r.shape[1] / 2:
        dx -= r.shape[1]
    return dy, dx, float(r.max())


def estimate_geometry(Lr, Ls, border=6):
    gr, gs = grad_mag(Lr), grad_mag(Ls)
    dy, dx, _ = phase_shift(gr, gs)
    h, w = Lr.shape
    inner = np.zeros_like(Lr, bool)
    inner[border:h - border, border:w - border] = True

    def cost(p):
        th, ls, tx, ty = p
        wr = warp(gr, th, np.exp(ls), tx, ty)
        m = inner & np.isfinite(wr)
        if m.mean() < 0.5:
            return 1.0
        return -ncc(wr, gs, m)
    best = None
    for th0 in (0.0, -1.0, 1.0):
        res = optimize.minimize(cost, x0=[th0, 0.0, dx, dy], method='Powell',
                                options=dict(xtol=1e-3, ftol=1e-5, maxiter=3000))
        if best is None or res.fun < best.fun:
            best = res
    th, ls, tx, ty = best.x
    return dict(rot_deg=float(th), scale=float(np.exp(ls)), tx_px=float(tx), ty_px=float(ty),
                ncc_init=float(-cost([0, 0, 0, 0])), ncc_aligned=float(-best.fun))


def local_residual(Lr_w, Ls, valid, block=32, step=16):
    gr, gs = grad_mag(np.nan_to_num(Lr_w)), grad_mag(Ls)
    h, w = Ls.shape
    tex_thr = np.median(gr[valid]) if valid.any() else 0.0
    mags = []
    for y in range(0, h - block + 1, step):
        for x in range(0, w - block + 1, step):
            if valid[y:y + block, x:x + block].mean() < 0.95:
                continue
            a, b = gr[y:y + block, x:x + block], gs[y:y + block, x:x + block]
            if a.mean() < tex_thr or b.std() < 1e-3:  # 只用纹理足够的块，平坦块相位相关不可靠
                continue
            dy, dx, pk = phase_shift(a, b)
            if pk > 0.1 and abs(dy) < block / 4 and abs(dx) < block / 4:
                mags.append(np.hypot(dy, dx))
    m = np.asarray(mags)
    return dict(local_shift_p50=float(np.median(m)) if len(m) else np.nan,
                local_shift_p90=float(np.percentile(m, 90)) if len(m) else np.nan, local_blocks=int(len(m)))


# ----------------------------------------------------------------------------- 亮度 / 模糊 / 噪声
def rho2_map(h, w):
    yy, xx = np.mgrid[0:h, 0:w]
    return (((yy - (h - 1) / 2) / ((h - 1) / 2)) ** 2 + ((xx - (w - 1) / 2) / ((w - 1) / 2)) ** 2) / 2.0


def fit_tone(Lr, Ls, m):
    """Ls ≈ a0 + a1·Lr + a2·Lr² + v·ρ²（色调曲线与径向暗角联合拟合，避免暗角均值混入全局偏移）。"""
    a, b = ndimage.gaussian_filter(np.nan_to_num(Lr), 2)[m], ndimage.gaussian_filter(Ls, 2)[m]
    A = np.stack([np.ones_like(a), a, a * a, rho2_map(*Lr.shape)[m]], 1)
    coef = np.linalg.lstsq(A, b, rcond=None)[0]
    for _ in range(2):  # 去掉 5% 最大残差后重拟合
        r = np.abs(A @ coef - b)
        keep = r <= np.percentile(r, 95)
        coef = np.linalg.lstsq(A[keep], b[keep], rcond=None)[0]
    return coef


def hp(x, s=4.0):
    return x - ndimage.gaussian_filter(x, s)


def estimate_blur(Lt, Ls, m):
    sig = np.arange(0, 4.01, 0.25)
    hs = hp(Ls)
    e_ref = [np.mean((hp(ndimage.gaussian_filter(Lt, s) if s > 0 else Lt) - hs)[m] ** 2) for s in sig]
    k = int(np.argmin(e_ref))
    if k > 0:
        return float(sig[k]), e_ref
    ht = hp(Lt)
    e_sty = [np.mean((ht - hp(ndimage.gaussian_filter(Ls, s) if s > 0 else Ls))[m] ** 2) for s in sig]
    return -float(sig[int(np.argmin(e_sty))]), e_ref


def mad_std(x):
    x = x[np.isfinite(x)]
    return float(1.4826 * np.median(np.abs(x - np.median(x)))) if len(x) > 50 else np.nan


def noise_of(img_ch, flat):
    return mad_std((img_ch - ndimage.gaussian_filter(img_ch, 1.5))[flat])


def radial_field(res_low, m):
    rho2 = rho2_map(*res_low.shape)
    A = np.stack([np.ones(m.sum()), rho2[m]], 1)
    c0, v = np.linalg.lstsq(A, res_low[m], rcond=None)[0]
    resid = res_low[m] - (c0 + v * rho2[m])
    return float(v), float(resid.std())


# ----------------------------------------------------------------------------- 主流程
def analyze_pair(task):
    name, pref, psty, ref_is_gt = task
    try:
        ref = read_rgb(pref)
        sty = read_rgb(psty)
    except Exception as e:  # noqa: BLE001
        return name, None, str(e)
    row = dict(name=name, size_ratio=sty.shape[1] / ref.shape[1])
    sty = resize_to(sty, ref.shape[:2])
    lab_r, lab_s = co.rgb_to_oklab(ref) * 100, co.rgb_to_oklab(sty) * 100
    Lr, Ls = lab_r[..., 0], lab_s[..., 0]
    row['clip_frac_style'] = float((np.any(sty <= 1 / 255, -1) | np.any(sty >= 254 / 255, -1)).mean())

    geo = estimate_geometry(Lr, Ls)
    row.update(geo)
    lab_w = warp(lab_r, geo['rot_deg'], geo['scale'], geo['tx_px'], geo['ty_px'])
    valid = np.all(np.isfinite(lab_w), -1)
    valid = ndimage.binary_erosion(valid, iterations=4)
    Lw = np.where(valid, lab_w[..., 0], np.nan)
    row.update(local_residual(Lw, Ls, valid))

    coef = fit_tone(Lw, Ls, valid)
    h, w = Ls.shape
    vig_map = coef[3] * rho2_map(h, w)
    row.update(tone_offset_L50=float(coef[:3] @ [1, 50, 2500] - 50), tone_slope_L50=float(coef[1] + 2 * coef[2] * 50),
               tone_curv=float(coef[2]), dL_mean=float(np.nanmean((Ls - Lw)[valid])))
    Lt = np.where(valid, coef[0] + coef[1] * np.nan_to_num(Lw) + coef[2] * np.nan_to_num(Lw) ** 2 + vig_map, 0)
    Lt_fill = np.where(valid, Lt, ndimage.gaussian_filter(Ls, 2))
    sig, e_ref = estimate_blur(Lt_fill, Ls, valid)
    row['hf_energy_ref'] = float(np.std(hp(Lt_fill)[valid]))
    # 参考图高频太弱（平滑图）时模糊估计不可信，汇总时排除
    row['blur_sigma_px'] = sig if row['hf_energy_ref'] >= 1.0 else np.nan
    Lt_b = ndimage.gaussian_filter(Lt_fill, sig) if sig > 0 else Lt_fill
    res_low = ndimage.gaussian_filter(np.where(valid, Ls - Lt_b, 0), max(h, w) / 16) / np.maximum(
        ndimage.gaussian_filter(valid.astype(float), max(h, w) / 16), 1e-3)
    v2, row['field_std_L'] = radial_field(res_low, valid)
    row['vignette_L'] = float(coef[3] + v2)

    gref = grad_mag(np.nan_to_num(Lw))
    flat = valid & (gref < np.percentile(gref[valid], 40))
    for nm, ch in (('L', 0), ('a', 1), ('b', 2)):
        ns, nr = noise_of(lab_s[..., ch], flat), noise_of(np.nan_to_num(lab_w[..., ch]), flat)
        row[f'noise_{nm}_style'], row[f'noise_{nm}_ref'] = ns, nr
        row[f'noise_{nm}_excess'] = float(np.sqrt(max(ns ** 2 - nr ** 2, 0.0))) if np.isfinite(ns + nr) else np.nan
    if ref_is_gt:
        dab = lab_s[..., 1:] - np.nan_to_num(lab_w[..., 1:])
        row['dab_mean_a'], row['dab_mean_b'] = (float(np.mean(dab[..., k][valid])) for k in (0, 1))
        low = np.stack([ndimage.gaussian_filter(np.where(valid, dab[..., k], 0), max(h, w) / 16) for k in (0, 1)], -1)
        row['dab_lowfreq_std'] = float(np.sqrt(sum(np.var(low[..., k][valid]) for k in (0, 1))))
        ref_w = np.clip(co.oklab_to_rgb(np.nan_to_num(lab_w) / 100), 0, 1)
        de = co.ciede2000(co.rgb_to_cielab(ref_w), co.rgb_to_cielab(sty))
        row['de00_le2_aligned'] = float((de[valid] <= 2).mean() * 100)
    return name, row, None


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--content-dir', required=True)
    ap.add_argument('--style-dir', required=True, help='真实 style（raw）目录')
    ap.add_argument('--gt-dir', default='', help='GT 目录（推荐作为参考图）；不给则以 content 为参考')
    ap.add_argument('--ann-file', default='')
    ap.add_argument('--out-dir', default='./style_residual')
    ap.add_argument('--workers', type=int, default=max(1, (os.cpu_count() or 2) - 1))
    ap.add_argument('--max-images', type=int, default=0)
    args = ap.parse_args()
    os.makedirs(args.out_dir, exist_ok=True)
    ref_dir = args.gt_dir or args.content_dir
    if args.ann_file:
        with open(args.ann_file, 'r', encoding='utf-8') as f:
            names = [ln.strip() for ln in f if ln.strip()]
    else:
        names = sorted(osp.splitext(f)[0] for f in os.listdir(ref_dir) if f.lower().endswith(IMG_EXTS))
    if args.max_images:
        names = names[:args.max_images]
    tasks, miss = [], []
    for n in names:
        pr, ps = find_img(ref_dir, n), find_img(args.style_dir, n)
        (tasks.append((n, pr, ps, bool(args.gt_dir))) if pr and ps else miss.append(n))
    print(f'配对 {len(tasks)} 对（缺图 {len(miss)}），参考图={"GT" if args.gt_dir else "content"}，workers={args.workers}')
    rows, errs = [], []
    with Pool(args.workers) as pool:
        for i, (n, row, err) in enumerate(pool.imap_unordered(analyze_pair, tasks), 1):
            (errs.append(f'{n}: {err}') if err else rows.append(row))
            if i % 50 == 0 or i == len(tasks):
                print(f'  {i}/{len(tasks)}')
    rows.sort(key=lambda r: r['name'])
    keys = list(dict.fromkeys(k for r in rows for k in r))
    with open(osp.join(args.out_dir, 'per_pair.csv'), 'w', newline='', encoding='utf-8') as f:
        wtr = csv.DictWriter(f, fieldnames=keys)
        wtr.writeheader()
        for r in rows:
            wtr.writerow({k: (f'{v:.5g}' if isinstance(v, float) else v) for k, v in r.items()})
    good = [r for r in rows if r['ncc_aligned'] >= 0.3]
    desc = {
        'rot_deg': '旋转(度)', 'scale': '尺度', 'tx_px': '平移x(px)', 'ty_px': '平移y(px)',
        'local_shift_p50': '局部残差错位中位(px)', 'local_shift_p90': '局部残差错位p90(px)',
        'blur_sigma_px': '等效模糊σ(px,<0更锐)', 'tone_offset_L50': '亮度偏移@L50(L×100)',
        'tone_slope_L50': '亮度斜率@L50', 'tone_curv': '亮度曲率', 'dL_mean': '平均dL(L×100)',
        'vignette_L': '暗角(角点-中心,L×100)', 'field_std_L': '去暗角低频亮度场std',
        'noise_L_style': 'style L噪声', 'noise_L_ref': '参考 L噪声', 'noise_L_excess': 'style 额外L噪声',
        'noise_a_excess': 'style 额外a噪声', 'noise_b_excess': 'style 额外b噪声',
        'dab_mean_a': 'Δa 全局均值', 'dab_mean_b': 'Δb 全局均值', 'dab_lowfreq_std': 'Δab 低频空间std',
        'de00_le2_aligned': '对齐后 dE00<=2 占比(%)', 'clip_frac_style': 'style 过曝欠曝比例',
        'size_ratio': 'style/参考 宽度比', 'ncc_init': '对齐前NCC', 'ncc_aligned': '对齐后NCC',
        'hf_energy_ref': '参考图高频能量(L×100)',
    }
    L = ['=' * 90, f'style_raw 相对 {"GT" if args.gt_dir else "content"} 的退化残差统计',
         f'配对 {len(rows)}，对齐可信(NCC>=0.3) {len(good)}；以下统计只用对齐可信的配对', '=' * 90,
         f'{"量":30s} {"p5":>9s} {"p25":>9s} {"p50":>9s} {"p75":>9s} {"p95":>9s}']
    summ = {}
    for k, nm in desc.items():
        v = np.array([r.get(k, np.nan) for r in good], dtype=float)
        v = v[np.isfinite(v)]
        if not len(v):
            continue
        q = [float(np.percentile(v, p)) for p in (5, 25, 50, 75, 95)]
        summ[k] = dict(desc=nm, p=q, mean=float(v.mean()), std=float(v.std()))
        L.append(f'{nm:30s} ' + ' '.join(f'{x:9.4f}' for x in q))
    L.append(f'\n读图失败 {len(errs)}；缺图 {len(miss)}')
    with open(osp.join(args.out_dir, 'summary.txt'), 'w', encoding='utf-8') as f:
        f.write('\n'.join(L) + '\n')
    with open(osp.join(args.out_dir, 'summary.json'), 'w', encoding='utf-8') as f:
        json.dump(dict(args=vars(args), n_pairs=len(rows), n_good=len(good), stats=summ, errors=errs[:50],
                       missing=miss[:50]), f, ensure_ascii=False, indent=1)
    print('\n'.join(L))


if __name__ == '__main__':
    main()
