# -*- coding: utf-8 -*-
"""K3（Display P3）偏色 × 4_code le2 服务器工具（多进程，单进程内 4_code 单线程）。

子命令
  validate  标定：在真实 content 上随机生成偏色，统计 4_code le2 通过率、代理指标与 4_code 的一致性、
            实际施加的偏色力度、方案 B（33³ LUT 渲染）与逐像素渲染的差异、耗时。
  bank      建库：每张 content 生成多组偏色，4_code 验证通过（可向恒等收缩重试）的参数存入参数库，
            训练时 check_mode='bank' 按图名抽取重放（毫秒级、与离线验证逐位一致）。

用法
  python cast_4code_tool.py validate --content-dir /data/content --n-images 500 --casts-per-image 4 \
      --workers 32 --out-dir ./k3_validate --also-lut
  python cast_4code_tool.py bank --content-dir /data/content --ann-file train.txt --casts-per-image 16 \
      --retry 2 --workers 64 --out ./k3_bank.npz
  （--lutgen-dir 指定 lutgen_4code.py 所在目录，默认本目录；le2 为 P3 口径）

validate 输出（--out-dir，全部是文本，可直接复制回传）: results.csv、summary.txt
bank 输出: bank npz（names, params[float32, N×50], le2, attempt, meta）与同名 _log.txt
"""
import argparse
import csv
import json
import os
import os.path as osp
import sys
import time
import zlib
from multiprocessing import Pool

# 多进程下每个 worker 只用 1 个线程：必须在 import numpy/cv2 之前设置，否则 BLAS/OpenMP/cv2 线程池
# 按核数开线程，64 个 worker × 64 线程严重超订（实测单步慢 10~40 倍）
for _v in ('OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'NUMEXPR_NUM_THREADS',
           'VECLIB_MAXIMUM_THREADS', 'LUTGEN_INTRA_THREADS'):
    os.environ[_v] = '1'

import numpy as np  # noqa: E402

K2_DIR = osp.dirname(osp.abspath(__file__))  # 本目录（k3_offline）
IMG_EXTS = ('.png', '.jpg', '.jpeg', '.bmp', '.tif', '.tiff', '.webp')
_G = {}


def _init(cfg):
    os.environ['LUTGEN_INTRA_THREADS'] = '1'
    sys.path.insert(0, K2_DIR)
    sys.path.insert(0, cfg['lutgen_dir'])  # lutgen_dir 优先
    import k3_cast as kc
    import k3_color_ops as co
    import lutgen_4code as lg
    lg.set_intra_threads(1)
    try:
        import cv2
        cv2.setNumThreads(1)
    except ImportError:
        pass
    kc.USE_FAST = not cfg.get('no_fast', False)
    _G.update(kc=kc, co=co, lg=lg, model=kc.CastModel(cfg['model']), cfg=cfg)


def load_rgb(path, size):
    try:
        import cv2
        img = cv2.imread(path, cv2.IMREAD_UNCHANGED)
        if img is None or img.ndim != 3:
            raise ValueError(f'读图失败或非彩色: {path}')
        img = cv2.cvtColor(img[..., :3], cv2.COLOR_BGR2RGB)
        img = img.astype(np.float32) / (65535.0 if img.dtype == np.uint16 else 255.0)
        if size and (img.shape[1], img.shape[0]) != tuple(size):
            img = cv2.resize(img, tuple(size), interpolation=cv2.INTER_AREA)
        return np.clip(img, 0, 1)
    except ImportError:
        from PIL import Image
        im = Image.open(path).convert('RGB')
        if size and im.size != tuple(size):
            im = im.resize(tuple(size), Image.BOX)
        return np.asarray(im, dtype=np.float32) / 255.0


def _sample(rng):
    kc, cfg = _G['kc'], _G['cfg']
    x_raw = _G['model'].sample(rng, cfg['dev_scale'], cfg['mean_scale'], cfg['nu'])
    return kc.protect(x_raw, min_slope=cfg['min_slope'])


def _realized(img, gt):
    """实际施加的偏色力度（OKLab ×100）：有彩像素 |ΔH| 均值、ΔC/C 均值，灰区平均 ab 偏移幅度。"""
    co = _G['co']
    l0, l1 = co.rgb_to_oklab(img) * 100, co.rgb_to_oklab(gt) * 100
    C0, C1 = np.hypot(l0[..., 1], l0[..., 2]), np.hypot(l1[..., 1], l1[..., 2])
    col = C0 >= 5
    h0 = np.degrees(np.arctan2(l0[..., 2], l0[..., 1]))
    h1 = np.degrees(np.arctan2(l1[..., 2], l1[..., 1]))
    dh = np.abs((h1 - h0 + 180) % 360 - 180)
    gray = C0 < 2.5
    dab = (l1[..., 1:] - l0[..., 1:])[gray].mean(0) if gray.any() else np.array([np.nan, np.nan])
    return dict(real_abs_dH=float(dh[col].mean()) if col.any() else np.nan,
                real_dC_rel=float(((C1 - C0) / np.maximum(C0, 1e-6))[col].mean()) if col.any() else np.nan,
                real_gray_shift=float(np.hypot(*dab)), real_max_dL=float(np.abs(l1[..., 0] - l0[..., 0]).max()))


def job_validate(job):
    name, path, ci, seed = job
    kc, co, cfg = _G['kc'], _G['co'], _G['cfg']
    try:
        img = load_rgb(path, cfg['size'])
    except Exception as e:  # noqa: BLE001
        return None, f'{name}: {e}'
    rng = np.random.default_rng([seed, ci, zlib.crc32(name.encode())])
    x, pinfo = _sample(rng)
    row = dict(name=name, cast=ci, projected=int(pinfo['projected']), min_slope_raw=pinfo['min_slope_raw'],
               **kc.param_summary(x))
    t0 = time.time()
    gt, ginfo = kc.apply_cast(img, x)
    row['t_render'] = time.time() - t0
    row['gamut_frac'] = ginfo['gamut_frac']
    t0 = time.time()
    row['grid_le2'] = kc.proxy_metrics(img, gt, x)['grid_le2']
    row['t_proxy'] = time.time() - t0
    t0 = time.time()
    row['le2_pixel'] = kc.le2_4code(img, gt, _G['lg'])
    row['t_4code'] = time.time() - t0
    row.update(_realized(img, gt))
    if cfg['retry']:  # 不通过时向恒等收缩重试（估计"重试后"通过率）；-1=全部失败
        pa = 0 if row['le2_pixel'] >= cfg['thr'] else -1
        r = 1
        while pa < 0 and r <= cfg['retry']:
            g2, _ = kc.apply_cast(img, kc.shrink(x, cfg['shrink'] ** r))
            if kc.le2_4code(img, g2, _G['lg']) >= cfg['thr']:
                pa = r
            r += 1
        row['pass_attempt'] = pa
    if cfg['also_lut']:
        gl = kc.apply_lut(img, kc.cast_lut(x))
        row['le2_lut'] = kc.le2_4code(img, gl, _G['lg'])
        de = co.ciede2000(co.rgb_to_cielab(gt), co.rgb_to_cielab(gl))
        row['de_pix_lut_mean'], row['de_pix_lut_p99'] = float(de.mean()), float(np.percentile(de, 99))
        row.update({k + '_lut': v for k, v in _realized(img, gl).items() if k in ('real_abs_dH', 'real_dC_rel')})
    return row, None


def job_bank(job):
    name, path, M, seed = job
    kc, cfg = _G['kc'], _G['cfg']
    try:
        img = load_rgb(path, cfg['size'])
    except Exception as e:  # noqa: BLE001
        return name, [], f'{name}: {e}'
    rng = np.random.default_rng([seed, zlib.crc32(name.encode())])
    keep = []
    for _ in range(M):
        x0, _ = _sample(rng)
        for r in range(cfg['retry'] + 1):
            x = kc.shrink(x0, cfg['shrink'] ** r)
            gt = (kc.apply_lut(img, kc.cast_lut(x)) if cfg['render'] == 'lut' else kc.apply_cast(img, x)[0])
            le = kc.le2_4code(img, gt, _G['lg'])
            if cfg['keep_all']:  # 候选池：全部保留并记录 le2（A/B 实验两组共用同一批候选）
                keep.append((x.astype(np.float32), le, 0))
                break
            if le >= cfg['thr']:
                keep.append((x.astype(np.float32), le, r))
                break
    return name, keep, None


def list_images(cdir, ann, n, seed):
    files = {osp.splitext(f)[0]: osp.join(cdir, f) for f in os.listdir(cdir) if f.lower().endswith(IMG_EXTS)}
    if ann:
        with open(ann, 'r', encoding='utf-8') as f:
            want = [ln.strip() for ln in f if ln.strip()]
        names = [w for w in want if w in files]
        print(f'ann_file {len(want)} 条，找到图像 {len(names)} 张')
    else:
        names = sorted(files)
    if n and len(names) > n:
        names = list(np.random.default_rng(seed).choice(names, n, replace=False))
    return [(nm, files[nm]) for nm in names]


def summarize_validate(rows, cfg, out_dir, wall):
    L = []
    P = L.append
    a = {k: np.array([r.get(k, np.nan) for r in rows], dtype=float) for k in rows[0] if k != 'name'}
    thr = cfg['thr']
    lp = a['le2_pixel']
    P('=' * 90)
    P(f"K3（Display P3）偏色 × 4_code le2 标定  样本 {len(rows)}  分辨率 {cfg['size']}  阈值 {thr}  "
      f"dev_scale={cfg['dev_scale']} mean_scale={cfg['mean_scale']} nu={cfg['nu']} min_slope={cfg['min_slope']}")
    P('=' * 90)
    P(f'[1] 逐像素渲染 4_code le2: p1/p5/p25/p50 = ' + '/'.join(f'{np.nanpercentile(lp, q):.3f}' for q in (1, 5, 25, 50))
      + f'   通过率(>= {thr}) {np.nanmean(lp >= thr) * 100:.2f}%   >=0.85 {np.nanmean(lp >= 0.85) * 100:.2f}%')
    if 'pass_attempt' in a:
        pa = a['pass_attempt']
        P(f"    收缩重试(shrink={cfg['shrink']}, 最多 {cfg['retry']} 次)后通过率 {np.mean(pa >= 0) * 100:.2f}%  "
          f"(首次 {np.mean(pa == 0) * 100:.1f}%, " + ', '.join(f'第{r}次 {np.mean(pa == r) * 100:.1f}%'
                                                           for r in range(1, cfg['retry'] + 1)) + ')')
    if 'le2_lut' in a:
        ll = a['le2_lut']
        P(f"[2] 方案 B（33³ LUT 渲染）4_code le2: p1/p5/p50 = " + '/'.join(f'{np.nanpercentile(ll, q):.3f}' for q in (1, 5, 50))
          + f'   通过率 {np.nanmean(ll >= thr) * 100:.2f}%')
        P(f"    逐像素 vs LUT 渲染 dE00: 均值中位 {np.nanmedian(a['de_pix_lut_mean']):.3f}, p99 中位 "
          f"{np.nanmedian(a['de_pix_lut_p99']):.3f}, p99 最大 {np.nanmax(a['de_pix_lut_p99']):.3f}")
        P(f"    实际力度 逐像素/LUT: |dH| {np.nanmean(a['real_abs_dH']):.2f}/{np.nanmean(a['real_abs_dH_lut']):.2f}°, "
          f"ΔC/C {np.nanmean(a['real_dC_rel']):+.3f}/{np.nanmean(a['real_dC_rel_lut']):+.3f}")
    P('[3] 代理指标 grid_le2（逐像素 vs 33³ 格点回放，numpy dE00）与 4_code 的一致性')
    gl = a['grid_le2']
    fail = lp < thr
    P(f'    grid_le2 p1/p5/p50 = ' + '/'.join(f'{np.nanpercentile(gl, q):.4f}' for q in (1, 5, 50))
      + f'   Spearman(grid_le2, le2) = {_spearman(gl, lp):+.3f}')
    P('    代理阈值   保留比例   保留中4_code通过率   拦截4_code失败的比例(召回)')
    for t in (0.95, 0.97, 0.98, 0.99, 0.995, 0.999):
        kept = gl >= t
        P(f'    {t:7.3f}   {kept.mean() * 100:7.2f}%   {np.mean(lp[kept] >= thr) * 100 if kept.any() else np.nan:10.2f}%'
          f'        {np.mean(~kept[fail]) * 100 if fail.any() else np.nan:8.1f}%')
    P('[4] 4_code 失败样本的特征（失败组 vs 通过组 中位数）')
    for k in ('t_norm', 'max_abs_dH', 'mean_abs_g', 'gamut_frac', 'min_slope_raw', 'real_abs_dH', 'real_gray_shift'):
        if fail.any() and (~fail).any():
            P(f'    {k:16s} 失败 {np.nanmedian(a[k][fail]):8.3f}   通过 {np.nanmedian(a[k][~fail]):8.3f}   '
              f'Spearman(与le2) {_spearman(a[k], lp):+.3f}')
    P('[5] 实际施加力度（有彩像素 C>=5）: '
      f"|dH| 均值 {np.nanmean(a['real_abs_dH']):.2f}° (p90 {np.nanpercentile(a['real_abs_dH'], 90):.2f}), "
      f"ΔC/C 均值 {np.nanmean(a['real_dC_rel']):+.3f} (sd {np.nanstd(a['real_dC_rel']):.3f}), "
      f"灰区偏移 中位 {np.nanmedian(a['real_gray_shift']):.2f} p90 {np.nanpercentile(a['real_gray_shift'], 90):.2f}, "
      f"max|dL| 中位 {np.nanmedian(a['real_max_dL']):.3f}, 单调保护触发 {np.nanmean(a['projected']) * 100:.1f}%")
    P(f"[6] 耗时（单进程单线程）: 渲染 {np.nanmedian(a['t_render']) * 1000:.0f} ms, 代理 {np.nanmedian(a['t_proxy']) * 1000:.0f} ms, "
      f"4_code {np.nanmedian(a['t_4code']):.2f} s；总墙钟 {wall:.0f} s（workers={cfg['workers']}）")
    text = '\n'.join(L)
    with open(osp.join(out_dir, 'summary.txt'), 'w', encoding='utf-8') as f:
        f.write(text + '\n')
    print(text)


def _spearman(x, y):
    m = np.isfinite(x) & np.isfinite(y)
    if m.sum() < 10:
        return np.nan
    rx = np.argsort(np.argsort(x[m])).astype(float)
    ry = np.argsort(np.argsort(y[m])).astype(float)
    return float(np.corrcoef(rx, ry)[0, 1])


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest='cmd', required=True)
    for name in ('validate', 'bank'):
        p = sub.add_parser(name)
        p.add_argument('--content-dir', required=True)
        p.add_argument('--ann-file', default='')
        p.add_argument('--model', default=osp.join(K2_DIR, 'cast_model_p3.json'))
        p.add_argument('--lutgen-dir', default=K2_DIR)
        p.add_argument('--size', type=int, nargs=2, default=(256, 192), metavar=('W', 'H'))
        p.add_argument('--casts-per-image', type=int, default=4 if name == 'validate' else 16)
        p.add_argument('--n-images', type=int, default=500 if name == 'validate' else 0)
        p.add_argument('--workers', type=int, default=max(1, (os.cpu_count() or 2) - 1))
        p.add_argument('--threshold', type=float, default=0.95)
        p.add_argument('--retry', type=int, default=0 if name == 'validate' else 2)
        p.add_argument('--shrink', type=float, default=0.7)
        p.add_argument('--dev-scale', type=float, default=1.0)
        p.add_argument('--mean-scale', type=float, default=1.0)
        p.add_argument('--nu', type=float, default=None)
        p.add_argument('--min-slope', type=float, default=0.3)
        p.add_argument('--seed', type=int, default=0)
        p.add_argument('--no-fast', action='store_true', help='关闭 lutgen_fast 逐位等价加速补丁')
        if name == 'validate':
            p.add_argument('--out-dir', default='./k3_validate')
            p.add_argument('--also-lut', action='store_true')
        else:
            p.add_argument('--out', default='./k3_bank.npz')
            p.add_argument('--render', choices=('pixel', 'lut'), default='pixel')
            p.add_argument('--keep-all', action='store_true',
                           help='候选池模式：不重试、全部入库并记录 le2；训练时用 bank_min_le2 选择是否筛选')
    args = ap.parse_args()
    cfg = dict(model=args.model, lutgen_dir=args.lutgen_dir, size=tuple(args.size), thr=args.threshold,
               retry=args.retry, shrink=args.shrink, dev_scale=args.dev_scale, mean_scale=args.mean_scale,
               nu=args.nu, min_slope=args.min_slope, workers=args.workers, no_fast=args.no_fast,
               also_lut=getattr(args, 'also_lut', False), render=getattr(args, 'render', 'pixel'),
               keep_all=getattr(args, 'keep_all', False))
    try:  # 主进程先试初始化：依赖缺失时直接报错，避免 Pool initializer 失败后无限重启 worker
        _init(cfg)
        import skimage.color  # noqa: F401
    except ImportError as e:
        sys.exit(f'依赖导入失败（需要 lutgen_4code.py 及其依赖 cv2/scipy/PIL，以及 scikit-image）: {e}')
    imgs = list_images(args.content_dir, args.ann_file, args.n_images, args.seed)
    print(f'{args.cmd}: {len(imgs)} 张图 × {args.casts_per_image} 组偏色, workers={args.workers}')
    if imgs:  # 主进程单线程基准：正常应为 渲染 ~50ms、4_code ~1s（若慢 10 倍以上，检查 CPU 核数/线程设置）
        im0 = load_rgb(imgs[0][1], cfg['size'])
        x0, _ = _sample(np.random.default_rng(0))
        tb = time.time()
        g0 = _G['kc'].apply_cast(im0, x0)[0]
        tr = time.time() - tb
        tb = time.time()
        _G['kc'].le2_4code(im0, g0, _G['lg'])
        print(f'单进程基准: 渲染 {tr * 1000:.0f} ms, 4_code {time.time() - tb:.2f} s；'
              f'os.cpu_count()={os.cpu_count()}（workers 建议不超过物理核数）')
    t0 = time.time()
    if args.cmd == 'validate':
        os.makedirs(args.out_dir, exist_ok=True)
        jobs = [(n, p, c, args.seed) for n, p in imgs for c in range(args.casts_per_image)]
        rows, errs = [], []
        with Pool(args.workers, initializer=_init, initargs=(cfg,)) as pool:
            for i, (row, err) in enumerate(pool.imap_unordered(job_validate, jobs, chunksize=2), 1):
                (errs.append(err) if err else rows.append(row))
                if i % 100 == 0 or i == len(jobs):
                    el = time.time() - t0
                    print(f'  {i}/{len(jobs)}  {el:.0f}s  预计剩余 {el / i * (len(jobs) - i):.0f}s')
        keys = sorted({k for r in rows for k in r}, key=lambda k: (k != 'name', k))
        with open(osp.join(args.out_dir, 'results.csv'), 'w', newline='', encoding='utf-8') as f:
            w = csv.DictWriter(f, fieldnames=keys)
            w.writeheader()
            for r in rows:
                w.writerow({k: (f'{v:.6g}' if isinstance(v, float) else v) for k, v in r.items()})
        with open(osp.join(args.out_dir, 'run_args.json'), 'w', encoding='utf-8') as f:
            json.dump(dict(vars(args), n_rows=len(rows), errors=errs[:100]), f, ensure_ascii=False, indent=1)
        summarize_validate(rows, cfg, args.out_dir, time.time() - t0)
    else:
        jobs = [(n, p, args.casts_per_image, args.seed) for n, p in imgs]
        names, params, le2s, atts, errs = [], [], [], [], []

        def save(final):
            np.savez_compressed(args.out, names=np.asarray(names), params=np.asarray(params, dtype=np.float32).reshape(-1, 50),
                                le2=np.asarray(le2s, dtype=np.float32), attempt=np.asarray(atts, dtype=np.int8),
                                meta=json.dumps(dict(vars(args), final=final, n_images=len(imgs)), ensure_ascii=False))
        n_img_hit = 0
        with Pool(args.workers, initializer=_init, initargs=(cfg,)) as pool:
            for i, (name, keep, err) in enumerate(pool.imap_unordered(job_bank, jobs), 1):
                if err:
                    errs.append(err)
                n_img_hit += bool(keep)
                for x, le, r in keep:
                    names.append(name)
                    params.append(x)
                    le2s.append(le)
                    atts.append(r)
                if i % 200 == 0 or i == len(jobs):
                    el = time.time() - t0
                    print(f'  {i}/{len(jobs)} 张  入库 {len(names)} 条  {el:.0f}s  预计剩余 {el / i * (len(jobs) - i):.0f}s')
                    save(False)
        save(True)
        log = (f'参数库 {args.out}: {len(names)} 条 / {len(imgs)} 张图（有库存 {n_img_hit} 张），'
               f'每图平均 {len(names) / max(len(imgs), 1):.1f} 条；首次通过占 {np.mean(np.asarray(atts) == 0) * 100:.1f}%；'
               f'用时 {time.time() - t0:.0f}s；错误 {len(errs)}')
        with open(osp.splitext(args.out)[0] + '_log.txt', 'w', encoding='utf-8') as f:
            f.write(log + '\n' + '\n'.join(errs) + '\n')
        print(log)


if __name__ == '__main__':
    main()
