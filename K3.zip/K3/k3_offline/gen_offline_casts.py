# -*- coding: utf-8 -*-
"""K3（Display P3）离线偏色生成 + 4_code le2 筛选（自包含：本目录 k3_cast.py / k3_color_ops.py / lutgen_4code.py /
lutgen_fast.py / lutgen_p3.py / cast_model_p3.json 即全部依赖；另需 numpy、scipy、opencv-python、scikit-image）。

输入图须为 Display P3 编码。对 content 目录下每张图生成 N 组（默认 10）K3 偏色，保存为 PNG，并用 4_code 口径计算 le2：
  le2 = mean(dE00(偏色图, apply_lut(content, build_lut_hres(content, 偏色图))) <= 2.0)（P3 口径：4_code 内部
  RGB↔XYZ 用 P3 矩阵，dE00 用 P3→XYZ→skimage xyz2lab）
le2 在"实际保存的 8bit 偏色图"上计算（与训练时读到的数据完全一致）。

用法（只需给 content 路径）:
  python gen_offline_casts.py --content-dir /path/to/Venus_Train_256x192
常用可选:
  --out-dir ./k3_offline_out   --n-casts 10   --threshold 0.95   --workers 32
  --ann-file train.txt（只处理列表中的图）  --check-size 256 192（le2 判定分辨率，默认原图）
中断后重跑同一命令会跳过已完成的图（断点续跑）；--overwrite 从头重来。

输出（--out-dir）:
  casts/<content名>_c<k>.png   全部偏色图（k=0..N-1）
  all_list.txt                 全部偏色图文件名（每行一个）
  passed_list.txt              le2 >= threshold 的偏色图文件名
  cast_meta.csv                每张偏色图: 文件名、content 名、k、le2、是否通过、偏色参数摘要
  cast_params.npz              每张偏色图的 50 维偏色参数（可逐位复现）
  results.jsonl                逐图结果（断点续跑用）
  run_log.txt                  运行参数与汇总（通过率、全部失败的 content 数、耗时）
"""
import argparse
import csv
import json
import os
import os.path as osp
import sys
import time
import zlib
from multiprocessing import Pool

# 每个 worker 单线程（必须在 import numpy/cv2 之前），否则多进程 × 多线程严重超订
for _v in ('OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'NUMEXPR_NUM_THREADS',
           'VECLIB_MAXIMUM_THREADS', 'LUTGEN_INTRA_THREADS'):
    os.environ[_v] = '1'

import numpy as np  # noqa: E402

HERE = osp.dirname(osp.abspath(__file__))
IMG_EXTS = ('.png', '.jpg', '.jpeg', '.bmp', '.tif', '.tiff', '.webp')
_G = {}


def _init(cfg):
    sys.path.insert(0, HERE)
    import cv2
    import k3_cast as kc
    import lutgen_4code as lg
    cv2.setNumThreads(1)
    lg.set_intra_threads(1)
    kc.USE_FAST = not cfg['no_fast']
    _G.update(cv2=cv2, kc=kc, lg=lg, model=kc.CastModel(cfg['model']), cfg=cfg)


def _read(path):
    cv2 = _G['cv2']
    img = cv2.imread(path, cv2.IMREAD_UNCHANGED)
    if img is None or img.ndim != 3:
        raise ValueError(f'读图失败或非彩色图: {path}')
    img = cv2.cvtColor(img[..., :3], cv2.COLOR_BGR2RGB)
    scale = 65535.0 if img.dtype == np.uint16 else 255.0
    return np.clip(img.astype(np.float32) / scale, 0.0, 1.0)


def _resize(img, size):
    if not size or (img.shape[1], img.shape[0]) == tuple(size):
        return img
    cv2 = _G['cv2']
    u8 = np.clip(img * 255.0, 0, 255).astype(np.uint8)  # 与 LumaAlignCTdataset._resize_lr 一致
    return cv2.resize(u8, tuple(size), interpolation=cv2.INTER_AREA).astype(np.float32) / 255.0


def job(task):
    stem, path = task
    kc, cv2, cfg = _G['kc'], _G['cv2'], _G['cfg']
    t0 = time.time()
    try:
        content = _read(path)
    except Exception as e:  # noqa: BLE001
        return stem, None, str(e)
    src_chk = _resize(content, cfg['check_size'])
    casts = []
    for k in range(cfg['n_casts']):
        rng = np.random.default_rng([cfg['seed'], zlib.crc32(stem.encode()), k])
        x, pinfo = kc.protect(_G['model'].sample(rng, cfg['dev_scale'], cfg['mean_scale'], cfg['nu']),
                              min_slope=cfg['min_slope'])
        if cfg['render'] == 'lut':
            gt = kc.apply_lut(content, kc.cast_lut(x))
            gfrac = float('nan')
        else:
            gt, ginfo = kc.apply_cast(content, x)
            gfrac = ginfo['gamut_frac']
        u8 = np.clip(np.round(gt * 255.0), 0, 255).astype(np.uint8)
        fname = f'{stem}_c{k}.png'
        cv2.imwrite(osp.join(cfg['cast_dir'], fname), cv2.cvtColor(u8, cv2.COLOR_RGB2BGR),
                    [cv2.IMWRITE_PNG_COMPRESSION, 1])
        le2 = kc.le2_4code(src_chk, _resize(u8.astype(np.float32) / 255.0, cfg['check_size']), _G['lg'])
        casts.append(dict(file=fname, k=k, le2=le2, passed=bool(le2 >= cfg['threshold']),
                          projected=bool(pinfo['projected']), gamut_frac=gfrac,
                          params=[float(v) for v in x], **kc.param_summary(x)))
    return stem, dict(content=stem, casts=casts, sec=time.time() - t0), None


def list_images(cdir, ann):
    files = {}
    for f in sorted(os.listdir(cdir)):
        st, ext = osp.splitext(f)
        if ext.lower() in IMG_EXTS:
            files.setdefault(st, osp.join(cdir, f))
    if not ann:
        return list(files.items())
    with open(ann, 'r', encoding='utf-8') as f:
        want = [ln.strip() for ln in f if ln.strip()]
    miss = [w for w in want if w not in files]
    if miss:
        print(f'ann_file 中 {len(miss)} 个名字在 content 目录找不到（例: {miss[:3]}）')
    return [(w, files[w]) for w in want if w in files]


def finalize(out_dir, records, args, wall):
    recs = sorted(records.values(), key=lambda r: r['content'])
    rows = [dict(content=r['content'], **c) for r in recs for c in r['casts']]
    with open(osp.join(out_dir, 'all_list.txt'), 'w', encoding='utf-8') as f:
        f.write(''.join(r['file'] + '\n' for r in rows))
    with open(osp.join(out_dir, 'passed_list.txt'), 'w', encoding='utf-8') as f:
        f.write(''.join(r['file'] + '\n' for r in rows if r['passed']))
    keys = ['file', 'content', 'k', 'le2', 'passed', 'projected', 'gamut_frac',
            'mean_abs_dH', 'max_abs_dH', 'mean_abs_g', 't_norm']
    with open(osp.join(out_dir, 'cast_meta.csv'), 'w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=keys, extrasaction='ignore')
        w.writeheader()
        for r in rows:
            w.writerow({k: (f'{r[k]:.6g}' if isinstance(r[k], float) else r[k]) for k in keys})
    np.savez_compressed(osp.join(out_dir, 'cast_params.npz'), files=np.array([r['file'] for r in rows]),
                        params=np.array([r['params'] for r in rows], dtype=np.float32).reshape(-1, 50),
                        le2=np.array([r['le2'] for r in rows], dtype=np.float32))
    le2 = np.array([r['le2'] for r in rows])
    n_pass_img = np.array([sum(c['passed'] for c in r['casts']) for r in recs])
    secs = np.array([r['sec'] for r in recs])
    lines = [
        f'参数: {json.dumps(vars(args), ensure_ascii=False)}',
        f'content {len(recs)} 张 × {args.n_casts} = 偏色图 {len(rows)} 张',
        f'通过(le2 >= {args.threshold}): {int((le2 >= args.threshold).sum())} 张 ({np.mean(le2 >= args.threshold) * 100:.2f}%)',
        f'le2 p1/p5/p25/p50 = ' + '/'.join(f'{np.percentile(le2, q):.3f}' for q in (1, 5, 25, 50)),
        f'每张 content 的通过数: 0 个 {int((n_pass_img == 0).sum())} 张, '
        f'全部通过 {int((n_pass_img == args.n_casts).sum())} 张, 平均 {n_pass_img.mean():.2f}',
        f'单张 content 处理耗时中位 {np.median(secs):.1f} s（{args.n_casts} 组）；本次墙钟 {wall:.0f} s',
    ]
    with open(osp.join(out_dir, 'run_log.txt'), 'w', encoding='utf-8') as f:
        f.write('\n'.join(lines) + '\n')
    print('\n'.join(lines))


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--content-dir', required=True)
    ap.add_argument('--out-dir', default='./k3_offline_out')
    ap.add_argument('--n-casts', type=int, default=10)
    ap.add_argument('--threshold', type=float, default=0.95)
    ap.add_argument('--workers', type=int, default=max(1, (os.cpu_count() or 2) - 1))
    ap.add_argument('--ann-file', default='')
    ap.add_argument('--check-size', type=int, nargs=2, default=(0, 0), metavar=('W', 'H'),
                    help='le2 判定分辨率；0 0=原图（Venus_Train_256x192 即训练分辨率）')
    ap.add_argument('--model', default=osp.join(HERE, 'cast_model_p3.json'))
    ap.add_argument('--render', choices=('pixel', 'lut'), default='pixel')
    ap.add_argument('--dev-scale', type=float, default=1.0)
    ap.add_argument('--mean-scale', type=float, default=1.0)
    ap.add_argument('--nu', type=float, default=None)
    ap.add_argument('--min-slope', type=float, default=0.3)
    ap.add_argument('--seed', type=int, default=0)
    ap.add_argument('--no-fast', action='store_true', help='关闭 lutgen_fast 逐位等价加速补丁')
    ap.add_argument('--overwrite', action='store_true')
    args = ap.parse_args()

    out_dir = osp.abspath(args.out_dir)
    cast_dir = osp.join(out_dir, 'casts')
    os.makedirs(cast_dir, exist_ok=True)
    cfg = dict(model=args.model, n_casts=args.n_casts, threshold=args.threshold, seed=args.seed,
               check_size=tuple(args.check_size) if args.check_size[0] > 0 else None, render=args.render,
               dev_scale=args.dev_scale, mean_scale=args.mean_scale, nu=args.nu, min_slope=args.min_slope,
               no_fast=args.no_fast, cast_dir=cast_dir)
    try:
        _init(cfg)
        import skimage.color  # noqa: F401
    except ImportError as e:
        sys.exit(f'依赖缺失（需要 numpy/scipy/opencv-python/scikit-image）: {e}')

    jsonl = osp.join(out_dir, 'results.jsonl')
    records = {}
    if osp.exists(jsonl) and not args.overwrite:
        with open(jsonl, 'r', encoding='utf-8') as f:
            for ln in f:
                if ln.strip():
                    r = json.loads(ln)
                    records[r['content']] = r
    elif osp.exists(jsonl):
        os.remove(jsonl)
    tasks = [t for t in list_images(args.content_dir, args.ann_file) if t[0] not in records]
    print(f'待处理 content {len(tasks)} 张（已完成 {len(records)} 张），每张 {args.n_casts} 组偏色，'
          f'workers={args.workers}, cpu_count={os.cpu_count()}')
    if tasks:  # 单进程基准，便于发现线程/核数问题（正常 4_code ~1 s/次）
        t0 = time.time()
        im = _read(tasks[0][1])
        x, _ = _G['kc'].protect(_G['model'].sample(np.random.default_rng(0)))
        g = _G['kc'].apply_cast(im, x)[0]
        t1 = time.time()
        _G['kc'].le2_4code(_resize(im, cfg['check_size']), _resize(g, cfg['check_size']), _G['lg'])
        print(f'单进程基准: 渲染 {(t1 - t0) * 1000:.0f} ms, 4_code {time.time() - t1:.2f} s')

    t0 = time.time()
    errs = []
    with Pool(args.workers, initializer=_init, initargs=(cfg,)) as pool, open(jsonl, 'a', encoding='utf-8') as fo:
        for i, (stem, rec, err) in enumerate(pool.imap_unordered(job, tasks), 1):
            if err:
                errs.append(f'{stem}: {err}')
            else:
                records[stem] = rec
                fo.write(json.dumps(rec, ensure_ascii=False) + '\n')
                fo.flush()
            if i % 50 == 0 or i == len(tasks):
                el = time.time() - t0
                print(f'  {i}/{len(tasks)}  {el:.0f}s  预计剩余 {el / i * (len(tasks) - i):.0f}s')
    if errs:
        with open(osp.join(out_dir, 'errors.txt'), 'w', encoding='utf-8') as f:
            f.write('\n'.join(errs) + '\n')
        print(f'读图失败 {len(errs)} 张，见 errors.txt')
    if records:
        finalize(out_dir, records, args, time.time() - t0)


if __name__ == '__main__':
    main()
