# -*- coding: utf-8 -*-
"""pair_stats.npz 深入分析（本地运行）。

A. 按采集批次（文件名后缀）分组: 数量、le2、整体偏色差异
B. 真实配对 le2 的影响因素（Spearman 相关 + 分组对比）
C. 各色相档 ΔC~C 分层（加法 / 乘法判别，逐档）
D. 各色相档 dH~C 分层（色相映射是否随 C 变化）
E. 每档图间分布形状（偏度/峰度，是否近似高斯）
F. 缺失数据 EM 估计联合高斯 [dH24, dC24, gray_da, gray_db]，谱、平滑性、折叠概率
G. 真实数据中的色相折叠

用法: python analyze_pairs_deep.py pair_stats/pair_stats.npz
      python analyze_pairs_deep.py pair_stats_noshift/pair_stats.npz pair_stats/pair_stats.npz  # 第二个参数借用 le2
输出: 同目录 deep_report.txt、joint_gauss_em.npz（供后续 dataset 采样使用）
"""
import json
import os.path as osp
import re
import sys

import numpy as np

NB = 24
C_EDGES = np.array([2.5, 4, 6, 8, 10, 12.5, 15, 20, 25, 30, 45])


def spearman(a, b):
    m = np.isfinite(a) & np.isfinite(b)
    if m.sum() < 10:
        return np.nan
    ra = np.argsort(np.argsort(a[m])).astype(float)
    rb = np.argsort(np.argsort(b[m])).astype(float)
    return float(np.corrcoef(ra, rb)[0, 1])


def em_mvn(X, iters=200, ridge=1e-3, tol=1e-6):
    """含缺失值的多元高斯 EM。返回 mu, S, 每样本条件期望补全 Xhat。"""
    N, D = X.shape
    M = np.isfinite(X)
    keep = M.any(1)
    X, M = X[keep], M[keep]
    mu = np.nanmean(X, 0)
    S = np.diag(np.nanvar(X, 0) + ridge)
    ll_prev = -np.inf
    for it in range(iters):
        sx = np.zeros(D)
        sxx = np.zeros((D, D))
        Xh = np.empty_like(X)
        ll = 0.0
        for i in range(len(X)):
            o, m = M[i], ~M[i]
            xo = X[i, o]
            Soo = S[np.ix_(o, o)]
            L = np.linalg.cholesky(Soo)
            r = np.linalg.solve(L, xo - mu[o])
            ll += -0.5 * (r @ r) - np.log(np.diag(L)).sum() - 0.5 * o.sum() * np.log(2 * np.pi)
            x = np.empty(D)
            x[o] = xo
            C = np.zeros((D, D))
            if m.any():
                Smo = S[np.ix_(m, o)]
                K = np.linalg.solve(Soo, Smo.T).T
                x[m] = mu[m] + K @ (xo - mu[o])
                C[np.ix_(m, m)] = S[np.ix_(m, m)] - K @ Smo.T
            Xh[i] = x
            sx += x
            sxx += np.outer(x, x) + C
        mu = sx / len(X)
        S = sxx / len(X) - np.outer(mu, mu) + ridge * np.eye(D)
        if ll - ll_prev < tol * abs(ll):
            break
        ll_prev = ll
    return mu, S, Xh, keep, it + 1, ll


def main(npz, le2_from=None):
    d = dict(np.load(npz, allow_pickle=True))
    out_dir = osp.dirname(osp.abspath(npz))
    names = np.array([str(x) for x in d['names']])
    N = len(names)
    R = []
    P = R.append
    mp = d['min_px'][:, None]
    n_c, n_h = d['n_c'], d['n_h']
    okc, okh = n_c >= mp, n_h >= mp
    with np.errstate(invalid='ignore', divide='ignore'):
        mdH = np.where(okh, d['s_dH'] / n_h, np.nan)
        mdC = np.where(okc, d['s_dC'] / n_c, np.nan)
        mC = np.where(okc, d['s_C'] / n_c, np.nan)
        sdH_in = np.where(okh, np.sqrt(np.maximum(d['s_dH2'] / n_h - (d['s_dH'] / n_h) ** 2, 0)), np.nan)
        sdC_in = np.where(okc, np.sqrt(np.maximum(d['s_dC2'] / n_c - (d['s_dC'] / n_c) ** 2, 0)), np.nan)
        gda = d['s_gray_da'] / d['n_gray']
        gdb = d['s_gray_db'] / d['n_gray']
        r2_dH = 1 - d['sse_dH_interp'] / d['sse_dH_zero']
        r2_dC = 1 - d['sse_dC_add'] / d['sse_dC_zero']
        rmse_dH = np.sqrt(d['sse_dH_interp'] / d['n_dH_model'])
        rmse_dC = np.sqrt(d['sse_dC_add'] / d['n_dC_model'])
    gok = d['n_gray'] >= d['min_px']
    gda, gdb = np.where(gok, gda, np.nan), np.where(gok, gdb, np.nan)
    if 't_ok' in d and d['t_ok'].any():
        # --remove-gray-shift 结果: 灰区残差≈0，联合模型改用整图平移 t（未估出的图记缺失）
        tk = d['t_ok'] > 0
        gda, gdb = np.where(tk, d['t_a'], np.nan), np.where(tk, d['t_b'], np.nan)
    if le2_from and not np.isfinite(d['le2']).any():
        o = np.load(le2_from, allow_pickle=True)
        m = {str(n): v for n, v in zip(o['names'], o['le2'])}
        d['le2'] = np.array([m.get(n, np.nan) for n in names])
    gmag = np.hypot(gda, gdb)
    le2 = d['le2']
    colored_frac = n_c.sum(1) / d['n_valid']
    # 相邻档（都存在）dH 跳变与折叠
    dj = mdH - np.roll(mdH, 1, 1)  # 第 k 档 - 第 k-1 档
    slope = 1 + dj / 15.0
    min_slope = np.nanmin(np.where(np.isfinite(slope), slope, np.nan), 1)
    max_jump = np.nanmax(np.abs(dj), 1)
    w = np.where(okc, n_c, 0)
    str_dH = np.nansum(np.abs(np.nan_to_num(mdH)) * np.where(okh, n_h, 0), 1) / np.maximum(np.where(okh, n_h, 0).sum(1), 1)
    str_dC = np.nansum(np.abs(np.nan_to_num(mdC)) * w, 1) / np.maximum(w.sum(1), 1)
    w_sdH = np.nansum(np.nan_to_num(sdH_in) * np.where(okh, n_h, 0), 1) / np.maximum(np.where(okh, n_h, 0).sum(1), 1)
    w_sdC = np.nansum(np.nan_to_num(sdC_in) * w, 1) / np.maximum(w.sum(1), 1)
    meanC = np.nansum(np.nan_to_num(mC) * w, 1) / np.maximum(w.sum(1), 1)

    P('=' * 100)
    P(f'深入分析  npz={npz}  N={N}')
    P('=' * 100)

    # ---------------- A. 批次
    P('\n[A] 按采集批次（文件名去掉 IMG时间戳_ 前缀）分组')
    grp = np.array([re.sub(r'^IMG\d+_', '', n) for n in names])
    ug, cnt = np.unique(grp, return_counts=True)
    order = np.argsort(-cnt)
    P('    批次                 张数   le2中位  >=0.95   灰区偏移|ab|中位  整体加权|dH|  整体加权|dC|')
    for i in order:
        m = grp == ug[i]
        P(f'    {ug[i]:20s} {cnt[i]:5d}   {np.nanmedian(le2[m]):.3f}   {np.mean(le2[m] >= 0.95):.2f}    '
          f'{np.nanmedian(gmag[m]):6.2f}           {np.nanmedian(str_dH[m]):6.2f}       {np.nanmedian(str_dC[m]):6.2f}')
    big = [ug[i] for i in order if cnt[i] >= 80]
    if len(big) >= 2:
        P('  主要批次各档 dH 均值（图间均值；nan=该批次此档样本<10）:')
        P('    批次                 ' + ' '.join(f'{k * 15:>5d}' for k in range(0, NB, 2)))
        for g in big:
            m = grp == g
            row = [np.nanmean(mdH[m, k]) if okh[m, k].sum() >= 10 else np.nan for k in range(0, NB, 2)]
            P(f'    {g:20s} ' + ' '.join('  nan' if not np.isfinite(v) else f'{v:+5.1f}' for v in row))

    # ---------------- B. le2 因素
    P('\n[B] 真实配对 4_code le2 的影响因素（Spearman，负值=该因素越大 le2 越低）')
    feats = {
        '灰区偏移|ab|': gmag, '档内dH std(加权)': w_sdH, '档内dC std(加权)': w_sdC,
        '24档插值残差 dH RMSE': rmse_dH, '24档插值残差 dC RMSE': rmse_dC,
        '插值 R² dH': r2_dH, '插值 R² dC': r2_dC,
        '偏色力度 |dH|(加权)': str_dH, '偏色力度 |dC|(加权)': str_dC,
        '相邻档最大dH跳变': max_jump, '相邻档最小斜率(<0=折叠)': min_slope,
        '有效档数': okc.sum(1).astype(float), '有彩像素占比': colored_frac,
        '平均C': meanC, '过曝欠曝占比': d['frac_clip'], '|dL|均值': d['mean_abs_dL_raw'],
    }
    rows = sorted(((spearman(v, le2), k) for k, v in feats.items()), key=lambda t: t[0] if np.isfinite(t[0]) else 0)
    for r, k in rows:
        P(f'    {k:24s} rho={r:+.3f}')
    lo, hi = le2 < 0.95, le2 >= 0.95
    P('  le2<0.95 vs >=0.95 两组中位数对比:')
    for k in ('灰区偏移|ab|', '档内dH std(加权)', '档内dC std(加权)', '24档插值残差 dH RMSE', '24档插值残差 dC RMSE',
              '偏色力度 |dH|(加权)', '偏色力度 |dC|(加权)', '相邻档最大dH跳变', '有彩像素占比'):
        v = feats[k]
        P(f'    {k:24s} 低组 {np.nanmedian(v[lo]):7.3f}   高组 {np.nanmedian(v[hi]):7.3f}')

    # ---------------- C. ΔC~C 逐档
    P('\n[C] 逐档 ΔC 按 content C 分层均值（跨图合并像素；行=档，列=C 区间；空=像素<2000）')
    lvl_n, lvl_dc, lvl_r = d['lvl_n_c'], d['lvl_s_dC'], d['lvl_s_r']
    hdr = ' '.join(f'{C_EDGES[i]:>5.1f}' for i in range(8))
    P('    档   ' + hdr + '   | 判定: 若乘法, ΔC 随 C 成比例增大')
    verdict = []
    for k in range(NB):
        vals = [lvl_dc[k, i] / lvl_n[k, i] if lvl_n[k, i] >= 2000 else np.nan for i in range(8)]
        P(f'    {k * 15:3d}° ' + ' '.join('     ' if not np.isfinite(v) else f'{v:+5.2f}' for v in vals))
        v = np.array(vals)
        cm = (C_EDGES[:8] + C_EDGES[1:9]) / 2
        mm = np.isfinite(v)
        if mm.sum() >= 3:
            A = np.stack([np.ones(mm.sum()), cm[mm]], 1)
            coef = np.linalg.lstsq(A, v[mm], rcond=None)[0]
            verdict.append((k, coef[0], coef[1]))
    if verdict:
        ic = np.array([v[1] for v in verdict])
        sl = np.array([v[2] for v in verdict])
        P(f'  逐档拟合 ΔC = a + b·C（档内分层均值）: 截距 a 中位 {np.median(ic):+.2f}（范围 {ic.min():+.2f}~{ic.max():+.2f}），'
          f'斜率 b 中位 {np.median(sl):+.3f}（范围 {sl.min():+.3f}~{sl.max():+.3f}）')

    # ---------------- D. dH~C 逐档
    P('\n[D] 逐档 dH 按 content C 分层均值（C>=2.5 且 C_s>=2.5；空=像素<2000）')
    hn, hs, hs2 = d['lvl_n_h'], d['lvl_s_dH'], d['lvl_s_dH2']
    P('    档   ' + hdr)
    for k in range(NB):
        vals = [hs[k, i] / hn[k, i] if hn[k, i] >= 2000 else np.nan for i in range(8)]
        P(f'    {k * 15:3d}° ' + ' '.join('     ' if not np.isfinite(v) else f'{v:+5.1f}' for v in vals))
    P('    逐档 dH 像素 std 按 C 分层（反映色相噪声随 C 下降）:')
    for k in range(0, NB, 3):
        vals = [np.sqrt(max(hs2[k, i] / hn[k, i] - (hs[k, i] / hn[k, i]) ** 2, 0)) if hn[k, i] >= 2000 else np.nan
                for i in range(8)]
        P(f'    {k * 15:3d}° ' + ' '.join('     ' if not np.isfinite(v) else f'{v:5.1f}' for v in vals))

    # ---------------- E. 分布形状
    P('\n[E] 每档图间分布形状（dH / dC 每图档均值）: 偏度、超额峰度（高斯=0/0）')

    def sk(v):
        v = v[np.isfinite(v)]
        if len(v) < 30:
            return np.nan, np.nan
        z = (v - v.mean()) / v.std()
        return float((z ** 3).mean()), float((z ** 4).mean() - 3)
    P('    档    n    dH偏度 dH峰度 | dC偏度 dC峰度')
    for k in range(NB):
        a, b = sk(mdH[:, k])
        c, e = sk(mdC[:, k])
        P(f'    {k * 15:3d}° {okh[:, k].sum():5d}  {a:+6.2f} {b:+6.2f} | {c:+6.2f} {e:+6.2f}')

    # ---------------- F. EM 联合高斯
    P('\n[F] 缺失数据 EM 估计联合高斯 X=[dH(24), dC(24), gray_da, gray_db]')
    X = np.concatenate([mdH, mdC, gda[:, None], gdb[:, None]], 1)
    mu, S, Xh, keep, nit, ll = em_mvn(X)
    P(f'  EM 迭代 {nit} 次, 样本 {keep.sum()}, loglik {ll:.1f}')
    sd = np.sqrt(np.diag(S))
    Cr = S / np.outer(sd, sd)
    P('  dH 均值: ' + ' '.join(f'{v:+5.1f}' for v in mu[:NB]))
    P('  dH 标准差: ' + ' '.join(f'{v:5.1f}' for v in sd[:NB]))
    P('  dC 均值: ' + ' '.join(f'{v:+5.2f}' for v in mu[NB:2 * NB]))
    P('  dC 标准差: ' + ' '.join(f'{v:5.2f}' for v in sd[NB:2 * NB]))
    P(f'  灰区偏移 (da,db) 均值 ({mu[-2]:+.2f},{mu[-1]:+.2f}) 标准差 ({sd[-2]:.2f},{sd[-1]:.2f})  corr={Cr[-2, -1]:+.2f}')
    lag = lambda B, off=0: [float(np.mean([B[off + k, off + (k + l) % NB] for k in range(NB)])) for l in range(1, 13)]  # noqa: E731
    P('  相隔 l 档平均相关 dH: ' + ' '.join(f'{v:+.2f}' for v in lag(Cr)))
    P('  相隔 l 档平均相关 dC: ' + ' '.join(f'{v:+.2f}' for v in lag(Cr, NB)))
    P('  同档 dH-dC 相关: ' + ' '.join(f'{Cr[k, NB + k]:+.2f}' for k in range(NB)))
    P('  灰区 da 与各档 dC 相关(每3档): ' + ' '.join(f'{Cr[-2, NB + k]:+.2f}' for k in range(0, NB, 3)))
    P('  灰区 db 与各档 dC 相关(每3档): ' + ' '.join(f'{Cr[-1, NB + k]:+.2f}' for k in range(0, NB, 3)))
    for tag, sl in (('dH', slice(0, NB)), ('dC', slice(NB, 2 * NB)), ('全部(标准化)', slice(0, 2 * NB + 2))):
        B = S[sl, sl] if tag != '全部(标准化)' else Cr
        w_, v_ = np.linalg.eigh(B)
        w_ = w_[::-1] / w_.sum()
        cum = np.cumsum(w_)
        k90 = int(np.searchsorted(cum, 0.9)) + 1
        k95 = int(np.searchsorted(cum, 0.95)) + 1
        P(f'  PCA {tag:10s}: 前8解释率 ' + ' '.join(f'{x:.2f}' for x in w_[:8]) + f' | 90%需 {k90} 维, 95%需 {k95} 维')
    w_, v_ = np.linalg.eigh(S[:NB, :NB])
    v_ = v_[:, ::-1]
    for i in range(4):
        P(f'    dH PC{i + 1}: ' + ' '.join(f'{x:+.2f}' for x in v_[:, i]))

    # 从联合高斯采样: 折叠概率 & 与现有 k1 对比
    rng = np.random.default_rng(0)
    Z = rng.multivariate_normal(mu, S, size=20000)
    dHs = Z[:, :NB]
    sl_s = 1 + (dHs - np.roll(dHs, 1, 1)) / 15.0
    for a in (1.0, 1.2):
        P(f'  从 EM 联合高斯采样 2w 次（α_H={a}）: 相邻档斜率<0（色相折叠）概率 '
          f'{np.mean((1 + a * (dHs - np.roll(dHs, 1, 1)) / 15.0).min(1) < 0) * 100:.1f}%, '
          f'|dH|>30 的档占比 {np.mean(np.abs(a * dHs) > 30) * 100:.2f}%')
    P(f'  采样 dC 范围 p1/p99 = {np.percentile(Z[:, NB:2 * NB], 1):+.2f}/{np.percentile(Z[:, NB:2 * NB], 99):+.2f}')
    wH, vH = np.linalg.eigh(S[:NB, :NB])
    wH, vH = wH[::-1], vH[:, ::-1]
    for k in (2, 3, 4, 6, 8):
        Zk = mu[:NB] + rng.standard_normal((20000, k)) @ (vH[:, :k] * np.sqrt(wH[:k])).T
        fk = np.mean((1 + (Zk - np.roll(Zk, 1, 1)) / 15.0).min(1) < 0) * 100
        P(f'  dH 低秩 k={k}: 折叠概率 {fk:5.1f}%  保留方差 {wH[:k].sum() / wH.sum() * 100:5.1f}%  '
          f'|dH|>30 {np.mean(np.abs(Zk) > 30) * 100:.2f}%')

    # ---------------- G. 真实折叠
    P('\n[G] 真实数据中的色相折叠（相邻两档都存在时 1+Δ/15<0）')
    pairs_ok = np.isfinite(slope)
    P(f'  相邻存在档对 {pairs_ok.sum()} 个，其中斜率<0 {np.sum(slope[pairs_ok] < 0)} 个 '
      f'({np.mean(slope[pairs_ok] < 0) * 100:.2f}%); 斜率<0.3 {np.mean(slope[pairs_ok] < 0.3) * 100:.2f}%')
    has_fold = min_slope < 0
    P(f'  有折叠的图 {np.nansum(has_fold)} 张: le2 中位 {np.nanmedian(le2[has_fold]):.3f} vs 无折叠 {np.nanmedian(le2[~has_fold]):.3f}')

    text = '\n'.join(R)
    with open(osp.join(out_dir, 'deep_report.txt'), 'w', encoding='utf-8') as f:
        f.write(text + '\n')
    np.savez(osp.join(out_dir, 'joint_gauss_em.npz'), mu=mu, cov=S,
             layout=json.dumps(dict(dH=[0, NB], dC=[NB, 2 * NB], gray_da=2 * NB, gray_db=2 * NB + 1,
                                    units='dH 度, dC/gray OKLab x100, 24 档中心 k*15°')))
    print(text)


if __name__ == '__main__':
    main(sys.argv[1] if len(sys.argv) > 1 else 'pair_stats/pair_stats.npz',
         sys.argv[2] if len(sys.argv) > 2 else None)
