# -*- coding: utf-8 -*-
"""（K3 / Display P3）从真实配对统计（stat_real_pairs_p3.py --remove-gray-shift 的 pair_stats.npz）导出 K3 偏色模型参数。

参数向量 x (50 维) = [dH(24), g(24), t_a, t_b]
  dH[k]: 第 k 档（中心 k*15°）去平移后的色相残差（度）
  g[k]:  第 k 档乘法饱和度增益，C_new = C*(1+g)（最小二乘 dC = g*C 过原点）
  t:     整图 OKLab ab 平移（×100 口径），作用于全部像素（含灰区）
模型: x = mu + B @ (s * z),  z ~ N(0, I),  s = sqrt((nu-2)/chi2_nu)（t 分布尺度混合，方差不变、带重尾）
  B = P · Lfull：Lfull 为联合协方差（缺失数据 EM 估计）满秩分解，保留 dH/g/t 间相关；
  P 把 dH 块投影到其前 kh 个主成分、g 块投影到前 kg 个（去高阶噪声 → 平滑、不易折叠），
  每块再乘统一系数补回该块总方差。

用法:
  python export_cast_model.py ./pair_stats_p3_noshift/pair_stats.npz      # 默认输出本目录 cast_model_p3.json
  python export_cast_model.py ... --kh 6 --kg 8 --nu 5   # 手动指定
"""
import argparse
import json
import os.path as osp
import time

import numpy as np

NB = 24
D = 2 * NB + 2


def em_mvn(X, iters=300, ridge=1e-4, tol=1e-7):
    """含缺失值多元高斯 EM，返回 (mu, S, n_iter)。"""
    N, Dm = X.shape
    M = np.isfinite(X)
    keep = M.any(1)
    X, M = X[keep], M[keep]
    mu = np.nanmean(X, 0)
    S = np.diag(np.nanvar(X, 0) + ridge)
    ll_prev = -np.inf
    for it in range(iters):
        sx = np.zeros(Dm)
        sxx = np.zeros((Dm, Dm))
        ll = 0.0
        for i in range(len(X)):
            o, m = M[i], ~M[i]
            xo = X[i, o]
            Soo = S[np.ix_(o, o)]
            Lc = np.linalg.cholesky(Soo)
            r = np.linalg.solve(Lc, xo - mu[o])
            ll += -0.5 * (r @ r) - np.log(np.diag(Lc)).sum()
            x = np.empty(Dm)
            x[o] = xo
            C = np.zeros((Dm, Dm))
            if m.any():
                Smo = S[np.ix_(m, o)]
                K = np.linalg.solve(Soo, Smo.T).T
                x[m] = mu[m] + K @ (xo - mu[o])
                C[np.ix_(m, m)] = S[np.ix_(m, m)] - K @ Smo.T
            sx += x
            sxx += np.outer(x, x) + C
        mu = sx / len(X)
        S = sxx / len(X) - np.outer(mu, mu) + ridge * np.eye(Dm)
        if ll - ll_prev < tol * abs(ll):
            break
        ll_prev = ll
    return mu, S, it + 1


BLOCKS = dict(dH=slice(0, NB), g=slice(NB, 2 * NB), t=slice(2 * NB, D))


def build_basis(S, kh, kg, rescale=True):
    """块投影基: x-mu = P · Lfull · z。

    Lfull 为联合协方差的满秩分解（保留 dH/g/t 之间的相关）；P 把 dH 块投影到其自身前 kh 个主成分、
    g 块投影到前 kg 个主成分（去掉高阶噪声分量 → 曲线平滑、不易折叠），t 块不动；
    rescale=True 时每块乘一个统一系数使该块总方差与数据一致（统一系数不破坏平滑性）。
    """
    w, V = np.linalg.eigh(S)
    Lfull = V * np.sqrt(np.clip(w, 0, None))
    P = np.eye(D)
    info = {}
    for name, k in (('dH', kh), ('g', kg)):
        s = BLOCKS[name]
        wb, Vb = np.linalg.eigh(S[s, s])
        Vk = Vb[:, ::-1][:, :k]
        Pb = Vk @ Vk.T
        ret = float(np.trace(Pb @ S[s, s] @ Pb) / np.trace(S[s, s]))
        c = 1.0 / np.sqrt(ret) if rescale else 1.0
        P[s, s] = c * Pb
        info[name] = ret
    return P @ Lfull, info


def sample(mu, B, nu, n, rng):
    z = rng.standard_normal((n, B.shape[1]))
    s = np.sqrt((nu - 2) / rng.chisquare(nu, size=(n, 1))) if nu and nu > 2 else 1.0
    return mu + (s * z) @ B.T


def fold_rate(dH):
    return float(np.mean((1 + (dH - np.roll(dH, 1, 1)) / 15.0).min(1) < 0))


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('npz')
    ap.add_argument('--out', default=osp.join(osp.dirname(osp.abspath(__file__)), 'cast_model_p3.json'))
    ap.add_argument('--kh', type=int, default=6, help='dH 块主成分数（表中 kh=6 保留约 93%% 方差）')
    ap.add_argument('--kg', type=int, default=8, help='g 块主成分数')
    ap.add_argument('--nu', type=float, default=5.0)
    ap.add_argument('--no-rescale', action='store_true')
    args = ap.parse_args()

    d = np.load(args.npz, allow_pickle=True)
    meta = json.loads(str(d['meta']))
    if 'display-p3' not in str(meta.get('color_space', '')):
        raise SystemExit('不是 K3（Display P3）统计结果：请用 stat_real_pairs_p3.py 重新统计')
    if not meta.get('remove_gray_shift'):
        raise SystemExit('需要 --remove-gray-shift 统计结果（pair_stats_noshift）')
    mp = d['min_px'][:, None]
    with np.errstate(invalid='ignore', divide='ignore'):
        dH = np.where(d['n_h'] >= mp, d['s_dH'] / d['n_h'], np.nan)
        g = np.where(d['n_c'] >= mp, d['s_CdC'] / d['s_C2'], np.nan)
    tk = d['t_ok'] > 0
    X = np.concatenate([dH, g, np.where(tk, d['t_a'], np.nan)[:, None],
                        np.where(tk, d['t_b'], np.nan)[:, None]], 1)
    cache = osp.splitext(args.out)[0] + '.em_cache.npz'
    if osp.exists(cache) and str(np.load(cache)['src']) == osp.abspath(args.npz):
        z = np.load(cache)
        mu, S, nit = z['mu'], z['S'], int(z['nit'])
        print(f'EM: 复用缓存 {cache}')
    else:
        t0 = time.time()
        mu, S, nit = em_mvn(X)
        np.savez(cache, mu=mu, S=S, nit=nit, src=osp.abspath(args.npz))
        print(f'EM: {nit} 次迭代, {time.time() - t0:.0f}s, 样本 {len(X)}')

    rng = np.random.default_rng(0)
    rows = []
    print(' kh kg | dH保留 g保留 | 折叠率(nu, 补偿后) | |dH|>30')
    for kh in range(3, 11):
        for kg in (4, 6, 8, 10, 12):
            B, ret = build_basis(S, kh, kg, rescale=not args.no_rescale)
            Z = sample(mu, B, args.nu, 20000, rng)
            fr = fold_rate(Z[:, :NB])
            rows.append((kh, kg, ret, fr))
            if kg in (6, 10):
                print(f' {kh:2d} {kg:2d} |  {ret["dH"]:.2f}  {ret["g"]:.2f}  |  {fr * 100:5.2f}%  |  '
                      f'{np.mean(np.abs(Z[:, :NB]) > 30) * 100:.2f}%')
    kh, kg = args.kh, args.kg
    B, ret = build_basis(S, kh, kg, rescale=not args.no_rescale)
    Z = sample(mu, B, args.nu, 50000, rng)
    sd = np.sqrt(np.diag(S))
    model = dict(
        version='k3-cast-1', color_space='display-p3',
        layout=dict(dH=[0, NB], g=[NB, 2 * NB], t=[2 * NB, D]),
        units='dH: 度; g: C_new=C*(1+g); t: OKLab ab ×100',
        bin_deg=360.0 / NB, n_bins=NB,
        mu=mu.tolist(), basis=B.tolist(), kh=int(kh), kg=int(kg), nu=float(args.nu),
        retained=ret, rescale=not args.no_rescale, data_sd=sd.tolist(),
        check=dict(fold_rate=fold_rate(Z[:, :NB]), sample_sd=Z.std(0).tolist(),
                   dH_abs_gt30=float(np.mean(np.abs(Z[:, :NB]) > 30))),
        source=dict(npz=osp.abspath(args.npz), n_images=int(len(X)), em_iters=int(nit),
                    stat_meta={kk: meta.get(kk) for kk in ('content_dir', 'style_dir', 'size', 'T', 't_hue')}),
    )
    with open(args.out, 'w', encoding='utf-8') as f:
        json.dump(model, f, ensure_ascii=False, indent=1)
    print(f'选用 kh={kh}, kg={kg}, nu={args.nu}: 折叠率 {model["check"]["fold_rate"] * 100:.2f}%, '
          f'样本 sd/数据 sd: dH {Z[:, :NB].std(0).mean() / sd[:NB].mean():.2f} '
          f'g {Z[:, NB:2 * NB].std(0).mean() / sd[NB:2 * NB].mean():.2f} t {Z[:, 2 * NB:].std(0).mean() / sd[2 * NB:].mean():.2f}')
    print(f'写出 {args.out}')


if __name__ == '__main__':
    main()
