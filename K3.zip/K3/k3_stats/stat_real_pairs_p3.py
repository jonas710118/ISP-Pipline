# -*- coding: utf-8 -*-
"""K3（Display P3）版：真实 content / style 配对（已像素级对齐 + 亮度对齐）的 H/C 差异统计。

与 analysis/stat_real_pairs.py 完全相同的统计，只是输入图按 Display P3 编码解释：
OKLab 用 k3_color_ops（P3 原色），可选 4_code le2 用 k3_cast.le2_4code（lutgen_p3 补丁 + P3→XYZ→Lab）。
依赖同目录 k3_color_ops.py / k3_cast.py / lutgen_4code.py / lutgen_fast.py / lutgen_p3.py。
K3 导出偏色模型需要带 --remove-gray-shift 的结果（之后 export_cast_model.py → cast_model_p3.json）。

目的（为 k1 偏色改造提供依据）:
  1. 每张图 24 档（15°/档，按 content 色相 rint 分档，与 hard_bins 一致）的 dH / dC
     → 档间协方差 / 相关 / PCA，判断能否用联合分布采样替代"逐档独立 + 低通 + 补偿 + α"。
  2. ΔC 与 C 的关系：加法 dC=a、乘法 dC=g·C、仿射 dC=a+g·C 三种模型对比。
  3. 辅助: dH 是否随 C 变化、灰区(C<T)是否有偏色、24 档周期线性插值能解释多少逐像素差异、
     style/content 的色域(C 分布)、对齐质量、可选 4_code le2 基线。

所有色度量在 OKLab 下计算，L/C 乘以 100（与 hue_bin_hc_aug 的 C×100 口径一致），
dH = wrap(H_style - H_content) ∈ [-180,180)，dC = C_style - C_content。

自包含单文件，依赖: numpy, scipy; 读图优先 cv2，退回 PIL。
可选 --le2-n 需要 lutgen_4code.py（--lutgen-dir 指定目录）与 scikit-image。

用法:
  python stat_real_pairs_p3.py --content-dir /data/content --style-dir /data/style \
      --out-dir ./pair_stats --workers 16
  # 快速试跑
  python stat_real_pairs_p3.py ... --max-images 200
  # 附带 4_code le2（-1=全部配对；正数=随机抽样）
  python stat_real_pairs_p3.py ... --le2-n -1   (默认 lutgen_dir 即本目录)
  # 只用已有 npz 重新生成汇总（本地分析用）
  python stat_real_pairs_p3.py --summarize-only ./pair_stats/pair_stats.npz

输出（--out-dir，全部回传）:
  pair_stats.npz        逐图逐档充分统计量 + 全局直方图（可离线重算任意模型）
  summary.txt           人读汇总
  summary.json          汇总中的数组（协方差、PCA、分档表等）
  bin_params_between_image.json  按"图间分布"估计的 24 档 (mean, std)，与现有 config 格式一致
  run_log.txt           运行参数 / 跳过的文件
"""
from __future__ import annotations

import argparse
import json
import os
import os.path as osp
import sys
import time
from multiprocessing import Pool

import numpy as np

NB = 24
BIN_DEG = 360.0 / NB
NF = 72
FINE_DEG = 360.0 / NF
C_LEVEL_EDGES = np.array([2.5, 4, 6, 8, 10, 12.5, 15, 20, 25, 30, 45], dtype=np.float64)
NL = len(C_LEVEL_EDGES) - 1
HIST_C_EDGES = np.arange(0.0, 45.01, 0.5)
H2_C_EDGES = np.arange(0.0, 41.0, 1.0)
H2_DC_EDGES = np.arange(-15.0, 15.01, 0.25)
H2_DH_EDGES = np.arange(-45.0, 45.01, 0.5)
IMG_EXTS = ('.png', '.jpg', '.jpeg', '.bmp', '.tif', '.tiff', '.webp')

# 逐图逐档充分统计量（dC 统计用 col 像素，dH 统计用 hue 像素）
BIN_KEYS_C = ('n_c', 's_C', 's_C2', 's_dC', 's_dC2', 's_CdC', 's_r', 's_r2')
BIN_KEYS_H = ('n_h', 's_dH', 's_dH2', 's_CdH', 's_absdH')
FINE_KEYS = ('f_n_c', 'f_s_dC', 'f_n_h', 'f_s_dH')
SCALAR_KEYS = ('n_pix', 'n_valid', 'frac_clip', 'frac_edge', 'frac_dl', 'mean_abs_dL_raw',
               'mean_dL_raw', 'n_gray', 's_gray_da', 's_gray_db', 's_gray_Cs',
               'sse_dH_zero', 'sse_dH_const', 'sse_dH_interp', 'n_dH_model',
               'sse_dC_zero', 'sse_dC_add', 'sse_dC_mul', 'n_dC_model', 'min_px',
               't_a', 't_b', 't_ok', 'n_t_px')
GLOBAL_KEYS = ('hist_C_content', 'hist_C_style', 'lvl_n_c', 'lvl_s_dC', 'lvl_s_dC2', 'lvl_s_r',
               'lvl_s_r2', 'lvl_n_h', 'lvl_s_dH', 'lvl_s_dH2', 'lvl_s_absdH',
               'h2_C_dC', 'h2_C_dH')

HERE = osp.dirname(osp.abspath(__file__))
sys.path.insert(0, HERE)
import k3_color_ops as _co  # noqa: E402


def srgb_to_oklab_x100(rgb):
    """（K3）输入按 Display P3 解释 → OKLab ×100。函数名沿用以减少改动。"""
    return _co.rgb_to_oklab(rgb) * 100.0


def load_rgb(path, size):
    """返回 float32 RGB [0,1]；size=(W,H) 或 None。"""
    try:
        import cv2
        img = cv2.imread(path, cv2.IMREAD_UNCHANGED)
        if img is None:
            raise ValueError(f'cv2 读图失败: {path}')
        if img.ndim != 3 or img.shape[2] < 3:
            raise ValueError(f'非彩色图: {path}')
        img = cv2.cvtColor(img[..., :3], cv2.COLOR_BGR2RGB)
        scale = 65535.0 if img.dtype == np.uint16 else 255.0
        img = img.astype(np.float32) / scale
        if size and (img.shape[1], img.shape[0]) != tuple(size):
            img = cv2.resize(img, tuple(size), interpolation=cv2.INTER_AREA)
        return np.clip(img, 0.0, 1.0)
    except ImportError:
        from PIL import Image
        im = Image.open(path).convert('RGB')
        if size and im.size != tuple(size):
            im = im.resize(tuple(size), Image.BOX)
        return np.asarray(im, dtype=np.float32) / 255.0


def _local_std(x, k=3):
    from scipy.ndimage import uniform_filter
    m = uniform_filter(x, k, mode='reflect')
    m2 = uniform_filter(x * x, k, mode='reflect')
    return np.sqrt(np.maximum(m2 - m * m, 0.0))


def _fill_circ(v, period):
    ok = np.isfinite(v)
    if not ok.any():
        return None
    if ok.all():
        return v
    idx = np.arange(period, dtype=np.float64)
    return np.interp(idx, idx[ok], v[ok], period=period)


def _interp_curve(m, H):
    z = H / BIN_DEG
    k = np.floor(z).astype(np.int64)
    u = z - k
    return (1.0 - u) * m[k % NB] + u * m[(k + 1) % NB]


def _bincount(idx, w, n):
    return np.bincount(idx, weights=w, minlength=n).astype(np.float64)


def process_pair(job):
    name, cpath, spath, cfg = job
    try:
        c = load_rgb(cpath, cfg['size'])
        s = load_rgb(spath, cfg['size'])
    except Exception as e:  # noqa: BLE001
        return name, None, f'读图失败: {e}'
    if c.shape != s.shape:
        return name, None, f'尺寸不一致: {c.shape} vs {s.shape}'

    lab_c = srgb_to_oklab_x100(c)
    lab_s = srgb_to_oklab_x100(s)
    Lc, ac, bc = lab_c[..., 0], lab_c[..., 1], lab_c[..., 2]
    Ls, as_, bs = lab_s[..., 0], lab_s[..., 1], lab_s[..., 2]
    Cc, Cs = np.hypot(ac, bc), np.hypot(as_, bs)
    Hc = np.mod(np.degrees(np.arctan2(bc, ac)), 360.0)
    Hs = np.mod(np.degrees(np.arctan2(bs, as_)), 360.0)
    dL = Ls - Lc
    dC = Cs - Cc
    dH = np.mod(Hs - Hc + 180.0, 360.0) - 180.0

    n_pix = Lc.size
    lo, hi = cfg['clip_lo'], cfg['clip_hi']
    clip = (np.any(c <= lo, -1) | np.any(c >= hi, -1) | np.any(s <= lo, -1) | np.any(s >= hi, -1))
    lrange = (Lc >= cfg['l_min']) & (Lc <= cfg['l_max'])
    edge_m = np.zeros_like(clip)
    if cfg['edge_pct'] > 0:
        st = _local_std(Lc) + _local_std(ac) + _local_std(bc)
        edge_m = st > np.percentile(st, 100.0 - cfg['edge_pct'])
    base = ~clip & lrange & ~edge_m
    dl_m = np.abs(dL) > cfg['dl_thr']
    valid = base & ~dl_m

    out = {k: 0.0 for k in SCALAR_KEYS}
    out['n_pix'] = n_pix
    out['n_valid'] = float(valid.sum())
    out['frac_clip'] = float(clip.mean())
    out['frac_edge'] = float(edge_m.mean())
    out['frac_dl'] = float((dl_m & base).sum() / max(base.sum(), 1))
    out['mean_abs_dL_raw'] = float(np.abs(dL[base]).mean()) if base.any() else np.nan
    out['mean_dL_raw'] = float(dL[base].mean()) if base.any() else np.nan
    min_px = max(int(cfg['min_px_abs']), int(round(cfg['min_frac'] * n_pix)))
    out['min_px'] = min_px

    T, Th = cfg['T'], cfg['t_hue']
    # 可选：去掉整图 ab 平移（白平衡式偏色，用 content 灰区像素的 style-content ab 中位数估计），
    # 之后的 dH/dC 统计即"去平移后的逐色相残差"
    out['t_a'] = out['t_b'] = 0.0
    out['t_ok'] = 0.0
    if cfg.get('remove_gray_shift'):
        g0 = valid & (Cc < T)
        out['n_t_px'] = float(g0.sum())
        if g0.sum() >= min_px:
            ta = float(np.median((as_ - ac)[g0]))
            tb = float(np.median((bs - bc)[g0]))
            out['t_a'], out['t_b'], out['t_ok'] = ta, tb, 1.0
            as_, bs = as_ - ta, bs - tb
            Cs = np.hypot(as_, bs)
            Hs = np.mod(np.degrees(np.arctan2(bs, as_)), 360.0)
            dC = Cs - Cc
            dH = np.mod(Hs - Hc + 180.0, 360.0) - 180.0
    col = valid & (Cc >= T)
    hue = valid & (Cc >= Th) & (Cs >= T)
    gray = valid & (Cc < T)

    bins = (np.rint(Hc / BIN_DEG).astype(np.int64)) % NB
    fbins = (np.rint(Hc / FINE_DEG).astype(np.int64)) % NF
    bc_, bh_ = bins[col], bins[hue]
    C1, dC1 = Cc[col], dC[col]
    r1 = Cs[col] / np.maximum(C1, 1e-6) - 1.0
    C2, dH2 = Cc[hue], dH[hue]
    per_bin = {
        'n_c': _bincount(bc_, None, NB), 's_C': _bincount(bc_, C1, NB),
        's_C2': _bincount(bc_, C1 * C1, NB), 's_dC': _bincount(bc_, dC1, NB),
        's_dC2': _bincount(bc_, dC1 * dC1, NB), 's_CdC': _bincount(bc_, C1 * dC1, NB),
        's_r': _bincount(bc_, r1, NB), 's_r2': _bincount(bc_, r1 * r1, NB),
        'n_h': _bincount(bh_, None, NB), 's_dH': _bincount(bh_, dH2, NB),
        's_dH2': _bincount(bh_, dH2 * dH2, NB), 's_CdH': _bincount(bh_, C2 * dH2, NB),
        's_absdH': _bincount(bh_, np.abs(dH2), NB),
        'f_n_c': _bincount(fbins[col], None, NF), 'f_s_dC': _bincount(fbins[col], dC1, NF),
        'f_n_h': _bincount(fbins[hue], None, NF), 'f_s_dH': _bincount(fbins[hue], dH2, NF),
    }

    out['n_gray'] = float(gray.sum())
    out['s_gray_da'] = float((as_ - ac)[gray].sum())
    out['s_gray_db'] = float((bs - bc)[gray].sum())
    out['s_gray_Cs'] = float(Cs[gray].sum())

    # 逐像素模型残差：dH 零模型 / 档内常数 / 24 档周期线性插值
    nh, nc = per_bin['n_h'], per_bin['n_c']
    with np.errstate(invalid='ignore', divide='ignore'):
        m_dH = np.where(nh >= min_px, per_bin['s_dH'] / nh, np.nan)
        m_dC = np.where(nc >= min_px, per_bin['s_dC'] / nc, np.nan)
        g_dC = np.where(nc >= min_px, per_bin['s_CdC'] / per_bin['s_C2'], np.nan)
    fH = _fill_circ(m_dH, NB)
    if fH is not None:
        okp = np.isin(bh_, np.where(nh >= min_px)[0])
        Hp, dHp, bp = Hc[hue][okp], dH2[okp], bh_[okp]
        out['sse_dH_zero'] = float((dHp ** 2).sum())
        out['sse_dH_const'] = float(((dHp - fH[bp]) ** 2).sum())
        out['sse_dH_interp'] = float(((dHp - _interp_curve(fH, Hp)) ** 2).sum())
        out['n_dH_model'] = float(okp.sum())
    fa, fg = _fill_circ(m_dC, NB), _fill_circ(g_dC, NB)
    if fa is not None:
        okp = np.isin(bc_, np.where(nc >= min_px)[0])
        Hp, Cp, dCp = Hc[col][okp], C1[okp], dC1[okp]
        out['sse_dC_zero'] = float((dCp ** 2).sum())
        out['sse_dC_add'] = float(((dCp - _interp_curve(fa, Hp)) ** 2).sum())
        out['sse_dC_mul'] = float(((dCp - _interp_curve(fg, Hp) * Cp) ** 2).sum())
        out['n_dC_model'] = float(okp.sum())

    # 全局（跨图累加）
    vb = bins[valid]
    sb = (np.rint(Hs / BIN_DEG).astype(np.int64) % NB)[valid]
    nhc = len(HIST_C_EDGES) - 1
    ic = np.clip(np.digitize(Cc[valid], HIST_C_EDGES) - 1, 0, nhc - 1)
    is_ = np.clip(np.digitize(Cs[valid], HIST_C_EDGES) - 1, 0, nhc - 1)
    glob = {
        'hist_C_content': _bincount(vb * nhc + ic, None, NB * nhc).reshape(NB, nhc),
        'hist_C_style': _bincount(sb * nhc + is_, None, NB * nhc).reshape(NB, nhc),
    }
    lv_c = np.clip(np.digitize(C1, C_LEVEL_EDGES) - 1, 0, NL - 1)
    ix = bc_ * NL + lv_c
    glob['lvl_n_c'] = _bincount(ix, None, NB * NL).reshape(NB, NL)
    glob['lvl_s_dC'] = _bincount(ix, dC1, NB * NL).reshape(NB, NL)
    glob['lvl_s_dC2'] = _bincount(ix, dC1 * dC1, NB * NL).reshape(NB, NL)
    glob['lvl_s_r'] = _bincount(ix, r1, NB * NL).reshape(NB, NL)
    glob['lvl_s_r2'] = _bincount(ix, r1 * r1, NB * NL).reshape(NB, NL)
    # dH 的 C 分层用 C>=T 的全部像素（含 T<=C<t_hue），以观察低 C 色相噪声
    hue_all = valid & (Cc >= T) & (Cs >= T)
    Ca, dHa = Cc[hue_all], dH[hue_all]
    ixh = bins[hue_all] * NL + np.clip(np.digitize(Ca, C_LEVEL_EDGES) - 1, 0, NL - 1)
    glob['lvl_n_h'] = _bincount(ixh, None, NB * NL).reshape(NB, NL)
    glob['lvl_s_dH'] = _bincount(ixh, dHa, NB * NL).reshape(NB, NL)
    glob['lvl_s_dH2'] = _bincount(ixh, dHa * dHa, NB * NL).reshape(NB, NL)
    glob['lvl_s_absdH'] = _bincount(ixh, np.abs(dHa), NB * NL).reshape(NB, NL)
    glob['h2_C_dC'] = np.histogram2d(C1, dC1, bins=(H2_C_EDGES, H2_DC_EDGES))[0]
    glob['h2_C_dH'] = np.histogram2d(Ca, dHa, bins=(H2_C_EDGES, H2_DH_EDGES))[0]
    return name, (out, per_bin, glob), None


# ----------------------------------------------------------------------------- le2

_LUTGEN = None


def _le2_init(lutgen_dir):
    global _LUTGEN
    os.environ['LUTGEN_INTRA_THREADS'] = '1'
    sys.path.insert(0, lutgen_dir)
    import lutgen_4code  # noqa: F401
    import lutgen_p3
    lutgen_4code.set_intra_threads(1)
    _LUTGEN = lutgen_p3.patch_p3(lutgen_4code)  # K3: 4_code 内部 RGB↔XYZ 换成 P3 矩阵


def le2_pair(job):
    name, cpath, spath, size = job
    try:
        import k3_cast
        from skimage import color as skc
        c = load_rgb(cpath, size)
        s = load_rgb(spath, size)
        lut = _LUTGEN.build_lut_hres(c, s)
        app = _LUTGEN.apply_lut(c, lut)
        de = skc.deltaE_ciede2000(k3_cast.p3_to_lab_skimage(s), k3_cast.p3_to_lab_skimage(app))
        return name, float((de <= 2.0).mean()), float(de.mean()), None
    except Exception as e:  # noqa: BLE001
        return name, np.nan, np.nan, str(e)


# ----------------------------------------------------------------------------- 汇总分析

def _pw_cov(X, min_n):
    """含 NaN 的成对完整协方差 / 相关 / 有效样本数。"""
    M = np.isfinite(X).astype(np.float64)
    Z = np.where(M > 0, X, 0.0)
    n = M.T @ M
    with np.errstate(invalid='ignore', divide='ignore'):
        sxy = Z.T @ Z
        mi = (Z.T @ M) / n           # mean_i | j 同时存在
        mj = mi.T
        vi = (Z.T ** 2 @ M) / n - mi ** 2
        cov = sxy / n - mi * mj
        corr = cov / np.sqrt(vi * vi.T)
    bad = n < min_n
    cov[bad] = np.nan
    corr[bad] = np.nan
    return cov, corr, n


def _pca(cov):
    c = np.nan_to_num(cov, nan=0.0)
    c = (c + c.T) / 2
    w, v = np.linalg.eigh(c)
    order = np.argsort(w)[::-1]
    w, v = w[order], v[:, order]
    neg = float(-w[w < 0].sum())
    wp = np.clip(w, 0, None)
    return wp / max(wp.sum(), 1e-12), v, neg / max(np.abs(w).sum(), 1e-12)


def _lag_corr(corr):
    D = corr.shape[0]
    return [float(np.nanmean([corr[k, (k + l) % D] for k in range(D)])) for l in range(1, D // 2 + 1)]


def _pct_from_hist(h, edges, q):
    cs = np.cumsum(h)
    if cs[-1] <= 0:
        return np.nan
    i = int(np.searchsorted(cs, q / 100.0 * cs[-1]))
    return float(edges[min(i + 1, len(edges) - 1)])


def _fmt_row(vals, f='{:+6.2f}'):
    return ' '.join('   nan' if not np.isfinite(v) else f.format(v) for v in vals)


def analyze(npz_path, out_dir):
    d = dict(np.load(npz_path, allow_pickle=True))
    meta = json.loads(str(d['meta']))
    names = d['names']
    N = len(names)
    L = []
    J = {}
    P = L.append
    min_px = d['min_px'][:, None]
    n_c, n_h = d['n_c'], d['n_h']
    ok_c, ok_h = n_c >= min_px, n_h >= min_px
    with np.errstate(invalid='ignore', divide='ignore'):
        mC = np.where(ok_c, d['s_C'] / n_c, np.nan)
        mdC = np.where(ok_c, d['s_dC'] / n_c, np.nan)
        mr = np.where(ok_c, d['s_r'] / n_c, np.nan)
        gC = np.where(ok_c, d['s_CdC'] / d['s_C2'], np.nan)
        mdH = np.where(ok_h, d['s_dH'] / n_h, np.nan)
        sd_dH_in = np.sqrt(np.maximum(d['s_dH2'] / n_h - (d['s_dH'] / n_h) ** 2, 0))
        sd_dC_in = np.sqrt(np.maximum(d['s_dC2'] / n_c - (d['s_dC'] / n_c) ** 2, 0))
    sd_dH_in = np.where(ok_h, sd_dH_in, np.nan)
    sd_dC_in = np.where(ok_c, sd_dC_in, np.nan)
    centers = np.arange(NB) * BIN_DEG

    P('=' * 100)
    P('真实 content/style 配对 H/C 差异统计汇总')
    P(f"npz={npz_path}  图像数={N}  分辨率={meta.get('size')}  T={meta.get('T')}  "
      f"t_hue={meta.get('t_hue')}  edge_pct={meta.get('edge_pct')}  dl_thr={meta.get('dl_thr')}")
    P('单位: OKLab ×100（C、L、a、b）；dH 单位 度；dH=wrap(H_style-H_content)，dC=C_style-C_content')
    P('=' * 100)

    # ---- 0. 数据质量
    P('\n[0] 对齐 / 数据质量')
    nv = d['n_valid'] / d['n_pix']
    P(f"  有效像素占比 p5/p50/p95 = {np.percentile(nv, 5):.2f}/{np.median(nv):.2f}/{np.percentile(nv, 95):.2f}"
      f"  (剔除: 过曝欠曝 均值 {d['frac_clip'].mean():.3f}, 边缘 {d['frac_edge'].mean():.3f})")
    P(f"  |dL| 均值(剔除前) p50/p95/max = {np.nanmedian(d['mean_abs_dL_raw']):.2f}/"
      f"{np.nanpercentile(d['mean_abs_dL_raw'], 95):.2f}/{np.nanmax(d['mean_abs_dL_raw']):.2f}"
      f"   dL 均值 p50 = {np.nanmedian(d['mean_dL_raw']):+.2f}")
    P(f"  |dL|>{meta.get('dl_thr')} 像素占比 p50/p95/max = {np.median(d['frac_dl']):.3f}/"
      f"{np.percentile(d['frac_dl'], 95):.3f}/{d['frac_dl'].max():.3f}  (高值=疑似对齐或亮度对齐不佳)")
    worst = np.argsort(-d['frac_dl'])[:20]
    P('  |dL| 超阈占比最高的 20 张: ' + ', '.join(f'{names[i]}({d["frac_dl"][i]:.2f})' for i in worst))
    J['worst_dl'] = [[str(names[i]), float(d['frac_dl'][i])] for i in np.argsort(-d['frac_dl'])[:200]]

    # ---- 1. 分档图间统计
    P('\n[1] 24 档图间统计（每张图每档取像素均值，再跨图统计；档内像素数 >= min_px 才计入）')
    P('    bin  中心   图数 | dH: 图间均值 图间std 档内std | dC: 图间均值 图间std 档内std | '
      'C均值 | g=dC/C(LS): 均值 std | C_s/C_c-1 均值')
    rows = []
    for k in range(NB):
        a = mdH[:, k]
        b = mdC[:, k]
        row = dict(bin=k, center=float(centers[k]), n_img_h=int(ok_h[:, k].sum()), n_img_c=int(ok_c[:, k].sum()),
                   h_mu=float(np.nanmean(a)) if ok_h[:, k].any() else np.nan,
                   h_sigma=float(np.nanstd(a)) if ok_h[:, k].sum() > 1 else np.nan,
                   h_within=float(np.nanmean(sd_dH_in[:, k])) if ok_h[:, k].any() else np.nan,
                   c_mu=float(np.nanmean(b)) if ok_c[:, k].any() else np.nan,
                   c_sigma=float(np.nanstd(b)) if ok_c[:, k].sum() > 1 else np.nan,
                   c_within=float(np.nanmean(sd_dC_in[:, k])) if ok_c[:, k].any() else np.nan,
                   C_mean=float(np.nanmean(mC[:, k])) if ok_c[:, k].any() else np.nan,
                   g_mu=float(np.nanmean(gC[:, k])) if ok_c[:, k].any() else np.nan,
                   g_sigma=float(np.nanstd(gC[:, k])) if ok_c[:, k].sum() > 1 else np.nan,
                   r_mu=float(np.nanmean(mr[:, k])) if ok_c[:, k].any() else np.nan)
        rows.append(row)
        P(f"    {k:3d} {centers[k]:5.0f}° {row['n_img_c']:6d} | {row['h_mu']:+7.2f} {row['h_sigma']:7.2f} "
          f"{row['h_within']:7.2f} | {row['c_mu']:+7.2f} {row['c_sigma']:7.2f} {row['c_within']:7.2f} | "
          f"{row['C_mean']:5.1f} | {row['g_mu']:+6.3f} {row['g_sigma']:6.3f} | {row['r_mu']:+6.3f}")
    J['bins'] = rows
    bp = {k: [r[k2] for r in rows] for k, k2 in
          (('h_mu', 'h_mu'), ('h_sigma', 'h_sigma'), ('c_mu', 'c_mu'), ('c_sigma', 'c_sigma'),
           ('g_mu', 'g_mu'), ('g_sigma', 'g_sigma'))}
    with open(osp.join(out_dir, 'bin_params_between_image.json'), 'w', encoding='utf-8') as f:
        json.dump(bp, f, indent=1, ensure_ascii=False)
    pres = ok_c.sum(1)
    P(f"  每张图有效档数 p5/p50/p95 = {np.percentile(pres, 5):.0f}/{np.median(pres):.0f}/{np.percentile(pres, 95):.0f}")

    # ---- 2. 档间相关 / 协方差 / PCA
    min_n = max(30, int(0.01 * N))
    P(f'\n[2] 档间相关（成对完整，至少 {min_n} 张图同时有两档才计算）')
    covH, corrH, nH = _pw_cov(mdH, min_n)
    covC, corrC, nC = _pw_cov(mdC, min_n)
    covG, corrG, _ = _pw_cov(gC, min_n)
    X = np.concatenate([mdH, mdC], 1)
    covX, corrX, _ = _pw_cov(X, min_n)
    lagH, lagC, lagG = _lag_corr(corrH), _lag_corr(corrC), _lag_corr(corrG)
    P('  相隔 l 档的平均相关 (l=1..12, 15°/档):')
    P('    dH : ' + _fmt_row(lagH, '{:+.2f}'))
    P('    dC : ' + _fmt_row(lagC, '{:+.2f}'))
    P('    g  : ' + _fmt_row(lagG, '{:+.2f}'))
    same = [corrX[k, NB + k] for k in range(NB)]
    P('  同档 dH-dC 相关 (24 档): ' + _fmt_row(same, '{:+.2f}'))
    P(f'    均值 {np.nanmean(same):+.2f}')
    J.update(cov_dH=covH.tolist(), corr_dH=corrH.tolist(), n_pair_dH=nH.tolist(),
             cov_dC=covC.tolist(), corr_dC=corrC.tolist(), cov_g=covG.tolist(), corr_g=corrG.tolist(),
             cov_joint=covX.tolist(), corr_joint=corrX.tolist(), lag_dH=lagH, lag_dC=lagC, lag_g=lagG)

    P('\n  PCA（基于成对协方差；负特征值占比反映缺失造成的非正定程度）')
    for tag, cv in (('dH', covH), ('dC', covC), ('g', covG), ('[dH,dC] 相关阵', corrX)):
        ratio, vec, neg = _pca(cv)
        cum = np.cumsum(ratio)
        P(f"    {tag:14s}: 前8主成分解释率 " + ' '.join(f'{x:.2f}' for x in ratio[:8]) +
          f" | 累计 3/5/8 = {cum[2]:.2f}/{cum[4]:.2f}/{cum[7]:.2f} | 负特征值占比 {neg:.3f}")
        J[f'pca_{tag.split()[0]}'] = dict(ratio=ratio.tolist(), vecs=vec[:, :8].T.tolist(), neg=neg)
    ratio, vec, _ = _pca(covH)
    for i in range(3):
        P(f'    dH PC{i + 1} 载荷(24档): ' + _fmt_row(vec[:, i] * np.sqrt(max(ratio[i], 0)), '{:+.2f}'))

    # 图内：每张图的全局均值偏移占比（若大部分方差来自"整图统一偏移"，说明 per-image 共享分量强）
    with np.errstate(invalid='ignore'):
        img_mean_dH = np.nanmean(mdH, 1)
        resid = mdH - img_mean_dH[:, None]
    tot = np.nanvar(mdH - np.nanmean(mdH, 0, keepdims=True))
    P(f"  dH 方差分解: 整图统一偏移的图间方差 {np.nanvar(img_mean_dH):.2f}, "
      f"去掉整图偏移后档间残差方差 {np.nanvar(resid - np.nanmean(resid, 0, keepdims=True)):.2f}, 总 {tot:.2f}")

    # ---- 3. ΔC 与 C 的关系
    P('\n[3] ΔC 与 C 的关系')
    n = n_c
    with np.errstate(invalid='ignore', divide='ignore'):
        sse0 = d['s_dC2']
        sse_add = d['s_dC2'] - d['s_dC'] ** 2 / n
        sse_mul = d['s_dC2'] - d['s_CdC'] ** 2 / d['s_C2']
        Sxx = d['s_C2'] - d['s_C'] ** 2 / n
        Sxy = d['s_CdC'] - d['s_C'] * d['s_dC'] / n
        sse_aff = sse_add - Sxy ** 2 / Sxx
        slope = Sxy / Sxx
        icpt = (d['s_dC'] - slope * d['s_C']) / n
        crange = np.sqrt(Sxx / n)
    m = ok_c & (crange > 1.0)
    P('  (a) 每图每档内逐像素回归（只取档内 C 标准差>1 的图档，共 %d 个）:' % int(m.sum()))
    S0, Sa, Sm, Sf = (np.nansum(x[m]) for x in (sse0, sse_add, sse_mul, sse_aff))
    P(f"      相对零模型的解释率 R²: 加法 dC=a {1 - Sa / S0:.3f} | 乘法 dC=g·C {1 - Sm / S0:.3f} | "
      f"仿射 dC=a+g·C {1 - Sf / S0:.3f}")
    P(f"      乘法优于加法的图档占比 {np.mean(sse_mul[m] < sse_add[m]):.3f}")
    P(f"      仿射斜率 g p25/p50/p75 = {np.nanpercentile(slope[m], 25):+.3f}/{np.nanmedian(slope[m]):+.3f}/"
      f"{np.nanpercentile(slope[m], 75):+.3f}; 截距 a p25/p50/p75 = {np.nanpercentile(icpt[m], 25):+.2f}/"
      f"{np.nanmedian(icpt[m]):+.2f}/{np.nanpercentile(icpt[m], 75):+.2f}")
    J['dC_model'] = dict(r2_add=float(1 - Sa / S0), r2_mul=float(1 - Sm / S0), r2_aff=float(1 - Sf / S0),
                         frac_mul_better=float(np.mean(sse_mul[m] < sse_add[m])))

    P('  (b) 全体像素按 content C 分层（跨图合并）: 若乘法，|dC| 随 C 线性增大且 C_s/C_c 比值稳定')
    P('      C 区间        像素数   dC均值   dC std  |dC|/C   (C_s/C_c-1)均值  std')
    lc, lsdc, lsdc2, lsr, lsr2 = (d[k].sum(0) for k in ('lvl_n_c', 'lvl_s_dC', 'lvl_s_dC2', 'lvl_s_r', 'lvl_s_r2'))
    lvl = []
    for i in range(NL):
        if lc[i] <= 0:
            continue
        mu = lsdc[i] / lc[i]
        sd = np.sqrt(max(lsdc2[i] / lc[i] - mu ** 2, 0))
        rmu = lsr[i] / lc[i]
        rsd = np.sqrt(max(lsr2[i] / lc[i] - rmu ** 2, 0))
        cmid = (C_LEVEL_EDGES[i] + C_LEVEL_EDGES[i + 1]) / 2
        lvl.append([float(C_LEVEL_EDGES[i]), float(C_LEVEL_EDGES[i + 1]), float(lc[i]), mu, sd, rmu, rsd])
        P(f"      [{C_LEVEL_EDGES[i]:4.1f},{C_LEVEL_EDGES[i + 1]:4.1f})  {lc[i]:10.0f} {mu:+7.2f} {sd:7.2f} "
          f"{sd / cmid:6.3f}   {rmu:+7.3f}        {rsd:6.3f}")
    J['dC_by_C_level'] = lvl
    # 图间：每档 mean dC 与 mean C 的相关（图间维度上是否"C 越高偏得越多"）
    cc = []
    for k in range(NB):
        mm = ok_c[:, k]
        if mm.sum() > 30:
            cc.append(float(np.corrcoef(mC[mm, k], np.abs(mdC[mm, k]))[0, 1]))
    P(f"  (c) 图间: 各档 corr(档均值C, |档均值dC|) 中位 {np.nanmedian(cc):+.2f} (p25 {np.nanpercentile(cc, 25):+.2f},"
      f" p75 {np.nanpercentile(cc, 75):+.2f})")

    # ---- 4. dH 与 C
    P('\n[4] dH 随 content C 分层（跨图合并，C>=T 且 C_s>=T 全部像素）: 低 C 端 std 大=色相噪声')
    lh, lsh, lsh2, lsa = (d[k].sum(0) for k in ('lvl_n_h', 'lvl_s_dH', 'lvl_s_dH2', 'lvl_s_absdH'))
    lvlh = []
    for i in range(NL):
        if lh[i] <= 0:
            continue
        mu = lsh[i] / lh[i]
        sd = np.sqrt(max(lsh2[i] / lh[i] - mu ** 2, 0))
        lvlh.append([float(C_LEVEL_EDGES[i]), float(C_LEVEL_EDGES[i + 1]), float(lh[i]), mu, sd, lsa[i] / lh[i]])
        P(f"      [{C_LEVEL_EDGES[i]:4.1f},{C_LEVEL_EDGES[i + 1]:4.1f})  n={lh[i]:10.0f}  dH均值 {mu:+6.2f}  std {sd:6.2f}"
          f"  |dH|均值 {lsa[i] / lh[i]:6.2f}")
    J['dH_by_C_level'] = lvlh
    P('      （dH 的 C 依赖若明显，则单纯"按色相"的 24 档模型不足，需要 H×C 二维模型）')

    # ---- 5. 逐像素可解释度
    P('\n[5] 24 档模型对逐像素差异的解释度（图内）')
    with np.errstate(invalid='ignore', divide='ignore'):
        r_const = 1 - d['sse_dH_const'] / d['sse_dH_zero']
        r_int = 1 - d['sse_dH_interp'] / d['sse_dH_zero']
        r_add = 1 - d['sse_dC_add'] / d['sse_dC_zero']
        r_mul = 1 - d['sse_dC_mul'] / d['sse_dC_zero']
    t = lambda a, b: np.sqrt(np.nansum(a) / max(np.nansum(b), 1))  # noqa: E731
    P(f"  dH RMSE: 零模型 {t(d['sse_dH_zero'], d['n_dH_model']):.2f}°  档内常数 {t(d['sse_dH_const'], d['n_dH_model']):.2f}°"
      f"  24档插值 {t(d['sse_dH_interp'], d['n_dH_model']):.2f}°  | 单图 R² 中位: 常数 {np.nanmedian(r_const):.2f}"
      f" 插值 {np.nanmedian(r_int):.2f}")
    P(f"  dC RMSE: 零模型 {t(d['sse_dC_zero'], d['n_dC_model']):.2f}  加法插值 {t(d['sse_dC_add'], d['n_dC_model']):.2f}"
      f"  乘法插值 {t(d['sse_dC_mul'], d['n_dC_model']):.2f}  | 单图 R² 中位: 加法 {np.nanmedian(r_add):.2f}"
      f" 乘法 {np.nanmedian(r_mul):.2f}")
    # 72 档细分 vs 24 档: 档内细节是否被 24 档抹掉
    with np.errstate(invalid='ignore', divide='ignore'):
        fm = np.where(d['f_n_h'] >= min_px / 3, d['f_s_dH'] / d['f_n_h'], np.nan)
    rough = np.nanmean(np.abs(fm - np.roll(fm, 1, 1)))
    P(f"  72 档(5°)相邻档 dH 平均跳变 {rough:.2f}°（对比 24 档相邻跳变 "
      f"{np.nanmean(np.abs(mdH - np.roll(mdH, 1, 1))):.2f}°）")
    J['explain'] = dict(r2_dH_const=float(np.nanmedian(r_const)), r2_dH_interp=float(np.nanmedian(r_int)),
                        r2_dC_add=float(np.nanmedian(r_add)), r2_dC_mul=float(np.nanmedian(r_mul)))

    # ---- 6. 灰区
    P(f"\n[6] 灰区（content C<{meta.get('T')}）在 style 中的偏移")
    with np.errstate(invalid='ignore', divide='ignore'):
        gda = d['s_gray_da'] / d['n_gray']
        gdb = d['s_gray_db'] / d['n_gray']
        gcs = d['s_gray_Cs'] / d['n_gray']
    gm = d['n_gray'] >= d['min_px']
    mag = np.hypot(gda, gdb)[gm]
    P(f"  有足够灰像素的图 {int(gm.sum())}/{N}; 灰区平均(a,b)偏移幅度 p50/p90/p99 = "
      f"{np.median(mag):.2f}/{np.percentile(mag, 90):.2f}/{np.percentile(mag, 99):.2f};"
      f" 偏移>1 的图占比 {np.mean(mag > 1):.3f}, >2.5 的 {np.mean(mag > 2.5):.3f}")
    P(f"  灰区像素在 style 中的平均 C p50/p90 = {np.nanmedian(gcs[gm]):.2f}/{np.nanpercentile(gcs[gm], 90):.2f}")
    P(f"  整体灰区偏移方向均值 (da,db) = ({np.nanmean(gda[gm]):+.2f}, {np.nanmean(gdb[gm]):+.2f})")

    # ---- 7. 色域
    P('\n[7] 色域 / C 分布（按各自色相分档）: p99 与 p99.9 的 C')
    hc = d['hist_C_content']
    hs = d['hist_C_style']
    gam = []
    for k in range(NB):
        a = [_pct_from_hist(hc[k], HIST_C_EDGES, q) for q in (99, 99.9)]
        b = [_pct_from_hist(hs[k], HIST_C_EDGES, q) for q in (99, 99.9)]
        gam.append([float(centers[k])] + a + b)
    P('    bin中心  content p99 p99.9 | style p99 p99.9')
    for g in gam:
        P(f"    {g[0]:5.0f}°   {g[1]:6.1f} {g[2]:6.1f}   | {g[3]:6.1f} {g[4]:6.1f}")
    allc, alls = hc.sum(0), hs.sum(0)
    colm = HIST_C_EDGES[:-1] >= 2.5
    P(f"  有彩像素中 C>15 占比: content {allc[colm & (HIST_C_EDGES[:-1] >= 15)].sum() / allc[colm].sum():.3f}"
      f"  style {alls[colm & (HIST_C_EDGES[:-1] >= 15)].sum() / alls[colm].sum():.3f}")
    J['gamut'] = gam

    # ---- 8. le2
    if 'le2' in d and np.isfinite(d['le2']).any():
        le = d['le2'][np.isfinite(d['le2'])]
        P('\n[8] 真实配对的 4_code le2 基线（训练分辨率）')
        P(f"  样本 {len(le)}; le2 p5/p25/p50/p75 = {np.percentile(le, 5):.3f}/{np.percentile(le, 25):.3f}/"
          f"{np.median(le):.3f}/{np.percentile(le, 75):.3f};  >=0.95 占比 {np.mean(le >= 0.95):.3f},"
          f" >=0.85 占比 {np.mean(le >= 0.85):.3f}")
        J['le2'] = dict(p=[float(np.percentile(le, q)) for q in (5, 25, 50, 75, 95)],
                        frac95=float(np.mean(le >= 0.95)))

    J['h2_C_edges'] = H2_C_EDGES.tolist()
    text = '\n'.join(L)
    with open(osp.join(out_dir, 'summary.txt'), 'w', encoding='utf-8') as f:
        f.write(text + '\n')
    with open(osp.join(out_dir, 'summary.json'), 'w', encoding='utf-8') as f:
        json.dump(J, f, ensure_ascii=False, default=lambda o: None if o is None else float(o))
    return text


# ----------------------------------------------------------------------------- 主流程

def find_pairs(cdir, sdir, suffix):
    smap = {}
    for f in os.listdir(sdir):
        st, ext = osp.splitext(f)
        if ext.lower() in IMG_EXTS:
            smap[st] = osp.join(sdir, f)
    pairs, miss = [], []
    for f in sorted(os.listdir(cdir)):
        st, ext = osp.splitext(f)
        if ext.lower() not in IMG_EXTS:
            continue
        sp = smap.get(st + suffix)
        (pairs.append((st, osp.join(cdir, f), sp)) if sp else miss.append(f))
    return pairs, miss


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--content-dir')
    ap.add_argument('--style-dir')
    ap.add_argument('--out-dir', default='./pair_stats')
    ap.add_argument('--style-suffix', default='', help='style 文件名 = content 主名 + 后缀（扩展名任意）')
    ap.add_argument('--size', type=int, nargs=2, default=(256, 192), metavar=('W', 'H'),
                    help='统计分辨率，默认训练分辨率 256x192；0 0=原图')
    ap.add_argument('--workers', type=int, default=max(1, (os.cpu_count() or 2) - 1))
    ap.add_argument('--max-images', type=int, default=0)
    ap.add_argument('--T', type=float, default=2.5, help='灰彩分界 C×100')
    ap.add_argument('--t-hue', type=float, default=5.0, help='dH 统计的 content C 下限（低 C 色相噪声大）')
    ap.add_argument('--l-min', type=float, default=3.0)
    ap.add_argument('--l-max', type=float, default=97.0)
    ap.add_argument('--clip-lo', type=float, default=1.0 / 255)
    ap.add_argument('--clip-hi', type=float, default=254.0 / 255)
    ap.add_argument('--edge-pct', type=float, default=15.0, help='剔除 content 局部 std 最高的百分比像素（对齐误差集中区）')
    ap.add_argument('--dl-thr', type=float, default=3.0, help='|dL|×100 超过此值视为未对齐像素剔除')
    ap.add_argument('--min-frac', type=float, default=0.001, help='档内像素数下限（占全图比例）')
    ap.add_argument('--min-px-abs', type=int, default=30)
    ap.add_argument('--remove-gray-shift', action='store_true',
                    help='先减去整图 ab 平移（content 灰区像素 style-content ab 中位数），再统计逐色相残差 dH/dC')
    ap.add_argument('--le2-n', type=int, default=0,
                    help='随机抽多少对计算 4_code le2（0=不算，-1=全部）；在 H/C 统计落盘之后执行')
    ap.add_argument('--lutgen-dir', default=HERE,
                    help='lutgen_4code.py 所在目录')
    ap.add_argument('--summarize-only', default='', help='只对已有 npz 重新生成汇总')
    args = ap.parse_args()

    if args.summarize_only:
        out_dir = osp.dirname(osp.abspath(args.summarize_only))
        print(analyze(args.summarize_only, out_dir))
        return
    if not (args.content_dir and args.style_dir):
        ap.error('需要 --content-dir 与 --style-dir')
    os.makedirs(args.out_dir, exist_ok=True)
    size = tuple(args.size) if args.size[0] > 0 else None
    pairs, miss = find_pairs(args.content_dir, args.style_dir, args.style_suffix)
    if args.max_images:
        pairs = pairs[:args.max_images]
    print(f'配对 {len(pairs)} 对, content 无对应 style {len(miss)} 张, workers={args.workers}, size={size}')
    if not pairs:
        sys.exit('没有找到配对，检查目录与 --style-suffix')
    cfg = dict(size=size, T=args.T, t_hue=args.t_hue, l_min=args.l_min, l_max=args.l_max,
               clip_lo=args.clip_lo, clip_hi=args.clip_hi, edge_pct=args.edge_pct, dl_thr=args.dl_thr,
               min_frac=args.min_frac, min_px_abs=args.min_px_abs,
               remove_gray_shift=args.remove_gray_shift)

    t0 = time.time()
    names, scal, perb, errs = [], {k: [] for k in SCALAR_KEYS}, {k: [] for k in BIN_KEYS_C + BIN_KEYS_H + FINE_KEYS}, []
    glob = None
    jobs = [(n, c, s, cfg) for n, c, s in pairs]
    with Pool(args.workers) as pool:
        for i, (name, res, err) in enumerate(pool.imap_unordered(process_pair, jobs, chunksize=8), 1):
            if err:
                errs.append(f'{name}: {err}')
            else:
                o, pb, g = res
                names.append(name)
                for k in SCALAR_KEYS:
                    scal[k].append(o[k])
                for k in perb:
                    perb[k].append(pb[k])
                if glob is None:
                    glob = {k: v.copy() for k, v in g.items()}
                else:
                    for k in glob:
                        glob[k] += g[k]
            if i % 500 == 0 or i == len(jobs):
                print(f'  {i}/{len(jobs)}  {time.time() - t0:.0f}s')
    if not names:
        sys.exit('全部失败: ' + '; '.join(errs[:5]))

    le2 = np.full(len(names), np.nan)
    le2_de = np.full(len(names), np.nan)
    npz = osp.join(args.out_dir, 'pair_stats.npz')

    def save(stage):
        meta = dict(vars(args), size=size, n_pairs=len(pairs), n_missing_style=len(miss),
                    n_ok=len(names), n_err=len(errs), seconds=time.time() - t0, stage=stage,
                    n_le2_done=int(np.isfinite(le2).sum()),
                    bins=NB, bin_deg=BIN_DEG, color_space='OKLab x100 / display-p3',
                    c_level_edges=C_LEVEL_EDGES.tolist(), hist_c_edges=HIST_C_EDGES.tolist())
        np.savez_compressed(
            npz, names=np.asarray(names), meta=json.dumps(meta, ensure_ascii=False), le2=le2, le2_de=le2_de,
            **{k: np.asarray(v, dtype=np.float64) for k, v in scal.items()},
            **{k: np.asarray(v, dtype=np.float64) for k, v in perb.items()},
            **glob)
        with open(osp.join(args.out_dir, 'run_log.txt'), 'w', encoding='utf-8') as f:
            f.write(json.dumps(meta, ensure_ascii=False, indent=1) + '\n')
            f.write(f'\n# content 无对应 style ({len(miss)}):\n' + '\n'.join(miss[:2000]) + '\n')
            f.write(f'\n# 错误 ({len(errs)}):\n' + '\n'.join(errs) + '\n')

    # 先落盘统计结果：le2 阶段即使中断/失败，H/C 统计也不会丢
    save('stats_done')
    print(analyze(npz, args.out_dir))

    if args.le2_n != 0:
        n_le2 = len(names) if args.le2_n < 0 else min(args.le2_n, len(names))
        try:  # 主进程先试导入，失败直接报错，避免 Pool initializer 失败后反复重启 worker
            sys.path.insert(0, args.lutgen_dir)
            import lutgen_4code  # noqa: F401
            import skimage  # noqa: F401
        except ImportError as e:
            sys.exit(f'le2 依赖导入失败（H/C 统计已保存）: {e}')
        idx_of = {n: i for i, n in enumerate(names)}
        pmap = {n: (c, s) for n, c, s in pairs}
        pick = np.random.default_rng(0).permutation(names)[:n_le2]
        print(f'\n4_code le2: {len(pick)} 对 (lutgen_dir={args.lutgen_dir})')
        t1 = time.time()
        with Pool(args.workers, initializer=_le2_init, initargs=(args.lutgen_dir,)) as pool:
            jobs2 = [(n, pmap[n][0], pmap[n][1], size) for n in pick]
            for i, (n, v, de, err) in enumerate(pool.imap_unordered(le2_pair, jobs2), 1):
                le2[idx_of[n]], le2_de[idx_of[n]] = v, de
                if err:
                    errs.append(f'le2 {n}: {err}')
                if i % 50 == 0 or i == len(jobs2):
                    el = time.time() - t1
                    print(f'  le2 {i}/{len(jobs2)}  {el:.0f}s  预计剩余 {el / i * (len(jobs2) - i):.0f}s')
                if i % 500 == 0:
                    save('le2_running')
        save('le2_done')
        print(analyze(npz, args.out_dir))
    print(f'\n完成，用时 {time.time() - t0:.0f}s；请回传 {args.out_dir} 整个目录')


if __name__ == '__main__':
    main()
