# -*- coding: utf-8 -*-
"""pair_stats.npz <-> 纯文本 JSON 互转（npz 无法传出时使用）。只依赖 numpy。

服务器端（npz -> json，可按图像数分片，每片一个 json）:
  python stats_convert.py npz2json pair_stats/pair_stats.npz
  python stats_convert.py npz2json pair_stats/pair_stats.npz --images-per-part 500
本地端（json -> npz，再用 stat_real_pairs.py --summarize-only 重算汇总）:
  python stats_convert.py json2npz pair_stats/pair_stats.part*.json --out pair_stats/pair_stats.npz

JSON 结构: {"format", "part", "n_parts", "meta", "names", "arrays": {key: {"shape", "data"}}}
逐图数组（首维=图像数）按图像分片；全局直方图类数组只写在第 0 片。
浮点保留 10 位有效数字（足够还原方差等二阶统计量），NaN 写成 null。
"""
import argparse
import glob
import json
import math
import os.path as osp

import numpy as np

FORMAT = 'pair_stats_json_v1'


def _flat(a):
    return [None if not math.isfinite(v) else (int(v) if float(v).is_integer() and abs(v) < 1e15
                                                 else float(f'{v:.10g}'))
            for v in np.asarray(a, dtype=np.float64).ravel().tolist()]


def npz2json(npz_path, per_part, out_prefix):
    d = np.load(npz_path, allow_pickle=True)
    names = [str(x) for x in d['names']]
    n = len(names)
    per_img = [k for k in d.files if k not in ('names', 'meta') and d[k].ndim >= 1 and d[k].shape[0] == n]
    glob_keys = [k for k in d.files if k not in ('names', 'meta') and k not in per_img]
    per_part = per_part if per_part > 0 else n
    n_parts = max(1, math.ceil(n / per_part))
    out_prefix = out_prefix or osp.splitext(npz_path)[0]
    outs = []
    for p in range(n_parts):
        sl = slice(p * per_part, min(n, (p + 1) * per_part))
        arrays = {k: dict(shape=list(d[k][sl].shape), data=_flat(d[k][sl])) for k in per_img}
        if p == 0:
            arrays.update({k: dict(shape=list(d[k].shape), data=_flat(d[k]), global_=True) for k in glob_keys})
        obj = dict(format=FORMAT, part=p, n_parts=n_parts, meta=str(d['meta']), names=names[sl], arrays=arrays)
        path = f'{out_prefix}.part{p:02d}.json'
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(obj, f, ensure_ascii=False, separators=(',', ':'))
        outs.append(path)
        print(f'写出 {path}  ({sl.stop - sl.start} 张图, {osp.getsize(path) / 1e6:.1f} MB)')
    print(f'共 {n_parts} 片；请回传全部 {osp.basename(out_prefix)}.part*.json')


def json2npz(paths, out):
    files = sorted({p for pat in paths for p in glob.glob(pat)})
    parts = []
    for p in files:
        with open(p, 'r', encoding='utf-8') as f:
            parts.append(json.load(f))
    parts.sort(key=lambda o: o['part'])
    assert parts and all(o['format'] == FORMAT for o in parts), '不是 pair_stats_json 文件'
    n_parts = parts[0]['n_parts']
    got = [o['part'] for o in parts]
    assert got == list(range(n_parts)), f'分片不全: 需要 0..{n_parts - 1}, 实际 {got}'

    def arr(spec):
        return np.array([np.nan if v is None else v for v in spec['data']], dtype=np.float64).reshape(spec['shape'])

    out_d = dict(names=np.asarray(sum((o['names'] for o in parts), [])), meta=parts[0]['meta'])
    for k, spec in parts[0]['arrays'].items():
        if spec.get('global_'):
            out_d[k] = arr(spec)
        else:
            out_d[k] = np.concatenate([arr(o['arrays'][k]) for o in parts], 0)
    np.savez_compressed(out, **out_d)
    print(f'合并 {len(parts)} 片 -> {out}  ({len(out_d["names"])} 张图)')


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest='cmd', required=True)
    a = sub.add_parser('npz2json')
    a.add_argument('npz')
    a.add_argument('--images-per-part', type=int, default=0, help='每片图像数，0=不分片')
    a.add_argument('--out-prefix', default='')
    b = sub.add_parser('json2npz')
    b.add_argument('json', nargs='+')
    b.add_argument('--out', required=True)
    args = ap.parse_args()
    if args.cmd == 'npz2json':
        npz2json(args.npz, args.images_per_part, args.out_prefix)
    else:
        json2npz(args.json, args.out)


if __name__ == '__main__':
    main()
