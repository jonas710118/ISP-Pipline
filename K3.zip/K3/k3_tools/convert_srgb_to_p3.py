# -*- coding: utf-8 -*-
"""把 sRGB 编码的图像批量转换为 Display P3 编码（同一物理颜色，像素值改变；sRGB 色域完全在 P3 内，不会越界）。

转换: sRGB → 线性 sRGB → 线性 P3（3x3 矩阵）→ P3 编码（Display P3 与 sRGB 传输曲线相同）。
默认输出无损 PNG（8bit；--bits 16 输出 16bit PNG 以减少二次量化，需 opencv）。
注意: 不嵌入 ICC 配置文件（训练/统计代码读图时也不读 ICC），请用目录名标记色域，例如 xxx_P3。
      训练 config 的 img_ext 要与输出扩展名一致（默认 .png）。

用法:
  python convert_srgb_to_p3.py --in-dir /data/Venus_Train_256x192 --out-dir /data/Venus_Train_256x192_P3 --workers 16
  python convert_srgb_to_p3.py --in-dir /data/content_lr --out-dir /data/content_lr_P3 --recursive
"""
import argparse
import os
import os.path as osp
import sys
from multiprocessing import Pool

for _v in ('OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'OPENBLAS_NUM_THREADS'):
    os.environ.setdefault(_v, '1')

import numpy as np  # noqa: E402

HERE = osp.dirname(osp.abspath(__file__))
sys.path.insert(0, HERE)
import k3_color_ops as co  # noqa: E402

IMG_EXTS = ('.png', '.jpg', '.jpeg', '.bmp', '.tif', '.tiff', '.webp')


def read(path):
    try:
        import cv2
        img = cv2.imread(path, cv2.IMREAD_UNCHANGED)
        if img is None or img.ndim != 3:
            raise ValueError(f'读图失败或非彩色图: {path}')
        img = cv2.cvtColor(img[..., :3], cv2.COLOR_BGR2RGB)
        return img.astype(np.float64) / (65535.0 if img.dtype == np.uint16 else 255.0)
    except ImportError:
        from PIL import Image
        return np.asarray(Image.open(path).convert('RGB'), dtype=np.float64) / 255.0


def write(path, rgb, bits):
    if bits == 16:
        import cv2
        u16 = np.clip(np.round(rgb * 65535.0), 0, 65535).astype(np.uint16)
        cv2.imwrite(path, cv2.cvtColor(u16, cv2.COLOR_RGB2BGR))
        return
    u8 = np.clip(np.round(rgb * 255.0), 0, 255).astype(np.uint8)
    try:
        import cv2
        cv2.imwrite(path, cv2.cvtColor(u8, cv2.COLOR_RGB2BGR), [cv2.IMWRITE_PNG_COMPRESSION, 1])
    except ImportError:
        from PIL import Image
        Image.fromarray(u8).save(path)


def job(t):
    src, dst, bits = t
    try:
        os.makedirs(osp.dirname(dst), exist_ok=True)
        write(dst, co.srgb_to_p3(read(src)), bits)
        return None
    except Exception as e:  # noqa: BLE001
        return f'{src}: {e}'


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--in-dir', required=True)
    ap.add_argument('--out-dir', required=True)
    ap.add_argument('--bits', type=int, choices=(8, 16), default=8)
    ap.add_argument('--recursive', action='store_true')
    ap.add_argument('--workers', type=int, default=max(1, (os.cpu_count() or 2) - 1))
    ap.add_argument('--overwrite', action='store_true')
    args = ap.parse_args()
    if osp.abspath(args.in_dir) == osp.abspath(args.out_dir):
        sys.exit('输出目录不能与输入目录相同')
    tasks = []
    for root, dirs, files in os.walk(args.in_dir):
        rel = osp.relpath(root, args.in_dir)
        for f in sorted(files):
            if osp.splitext(f)[1].lower() in IMG_EXTS:
                dst = osp.normpath(osp.join(args.out_dir, rel, osp.splitext(f)[0] + '.png'))
                if args.overwrite or not osp.exists(dst):
                    tasks.append((osp.join(root, f), dst, args.bits))
        if not args.recursive:
            break
    print(f'待转换 {len(tasks)} 张 → {args.out_dir}（{args.bits}bit PNG）')
    with Pool(args.workers) as pool:
        errs = [e for e in pool.imap_unordered(job, tasks, chunksize=16) if e]
    print(f'完成；失败 {len(errs)} 张' + ('：\n' + '\n'.join(errs[:20]) if errs else ''))


if __name__ == '__main__':
    main()
