# -*- coding: utf-8 -*-
"""把 K3/core 下的公共模块同步到各子目录（每个子目录自包含，可单独拷到服务器）。

core 是唯一源：修改 k3_color_ops.py / k3_cast.py / lutgen_*.py 后运行
  python sync_core.py           # 同步并报告
  python sync_core.py --check   # 只检查是否一致（不一致时退出码 1）
cast_model_p3.json 由 k3_stats/export_cast_model.py 生成后也放到 core/，再同步到需要它的目录。
"""
import argparse
import filecmp
import os.path as osp
import shutil
import sys

HERE = osp.dirname(osp.abspath(__file__))
CORE = osp.join(HERE, 'core')
TARGETS = {
    'k3_stats': ['k3_color_ops.py', 'k3_cast.py', 'lutgen_4code.py', 'lutgen_fast.py', 'lutgen_p3.py'],
    'k3_offline': ['k3_color_ops.py', 'k3_cast.py', 'lutgen_4code.py', 'lutgen_fast.py', 'lutgen_p3.py',
                   'cast_model_p3.json'],
    'k3_dataset': ['k3_color_ops.py', 'k3_cast.py', 'lutgen_4code.py', 'lutgen_fast.py', 'lutgen_p3.py',
                   'cast_model_p3.json'],
    'k3_eval': ['k3_color_ops.py', 'k3_cast.py', 'cast_model_p3.json'],
    'k3_tools': ['k3_color_ops.py'],
}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--check', action='store_true')
    args = ap.parse_args()
    bad = 0
    for d, files in TARGETS.items():
        for f in files:
            src, dst = osp.join(CORE, f), osp.join(HERE, d, f)
            if not osp.exists(src):
                print(f'  [跳过] core/{f} 不存在' + ('（运行 k3_stats/export_cast_model.py 后放入 core/）'
                                                   if f.endswith('.json') else ''))
                continue
            same = osp.exists(dst) and filecmp.cmp(src, dst, shallow=False)
            if same:
                continue
            bad += 1
            if args.check:
                print(f'  [不一致] {d}/{f}')
            else:
                shutil.copy2(src, dst)
                print(f'  [已同步] {d}/{f}')
    print('全部一致' if not bad else (f'{bad} 个文件不一致' if args.check else f'同步 {bad} 个文件'))
    sys.exit(1 if (bad and args.check) else 0)


if __name__ == '__main__':
    main()
