# -*- coding: utf-8 -*-
"""K3（Display P3）全链路本机自测。本机无 cv2 / skimage / mmedit，用 tests/stubs 替身（基类用真实 lumaAlignCTdataset.py）。

链路: sRGB 合成配对（已知偏色 + 整图平移）→ k3_tools 转 P3 → k3_stats P3 统计（与 sRGB 原图统计做物理一致性对比）
      → export_cast_model（P3 模型；拒绝 sRGB 统计）→ k3_cast 生成（L 保持 / P3 色域内 / 拒绝 k2 模型）
      → 4_code P3 补丁 → k3_offline 离线生成 → k3_dataset 三个 config 端到端 __getitem__
      → k3_eval dry-run → k3_degrade_stats 退化统计 → sync_core 一致性
运行: cd G:/k1/K3 && python tests/selftest_k3_chain.py
"""
import glob
import json
import os
import os.path as osp
import runpy
import shutil
import subprocess
import sys
import tempfile
import types

import numpy as np

K3 = osp.dirname(osp.dirname(osp.abspath(__file__)))
ROOT = osp.dirname(K3)
STUBS = osp.join(K3, 'tests', 'stubs')
SYN = osp.join(ROOT, 'analysis', '_selftest', 'synth_shift')
results = []


def check(name, ok, detail=''):
    results.append(bool(ok))
    print(f"[{'PASS' if ok else 'FAIL'}] {name}  {detail}", flush=True)


def run(args, **kw):
    env = dict(os.environ, PYTHONPATH=STUBS, PYTHONIOENCODING='utf-8')
    return subprocess.run([sys.executable] + args, env=env, capture_output=True, text=True, encoding='utf-8', **kw)


def tail(r, n=3):
    return '\n'.join((r.stdout + r.stderr).strip().splitlines()[-n:])


def per_bin_means(npz):
    d = np.load(npz, allow_pickle=True)
    mp = d['min_px'][:, None]
    with np.errstate(invalid='ignore', divide='ignore'):
        dH = np.where(d['n_h'] >= mp, d['s_dH'] / d['n_h'], np.nan)
        g = np.where(d['n_c'] >= mp, d['s_CdC'] / d['s_C2'], np.nan)
    order = np.argsort(d['names'])
    return dH[order], g[order], d['t_a'][order], d['t_b'][order], d['le2'][order]


def main():
    tmp = tempfile.mkdtemp()
    # 1. sRGB → P3 转换
    p3 = {k: osp.join(tmp, 'p3', k) for k in ('content', 'style')}
    for k in ('content', 'style'):
        r = run([osp.join(K3, 'k3_tools', 'convert_srgb_to_p3.py'), '--in-dir', osp.join(SYN, k), '--out-dir', p3[k],
                 '--workers', '4'])
        assert r.returncode == 0, r.stderr
    sys.path.insert(0, osp.join(K3, 'core'))
    import k3_color_ops as co
    from PIL import Image
    f0 = sorted(glob.glob(osp.join(SYN, 'content', '*.png')))[0]
    a = np.asarray(Image.open(f0).convert('RGB'), dtype=np.float64) / 255
    b = np.asarray(Image.open(osp.join(p3['content'], osp.basename(f0))).convert('RGB'), dtype=np.float64) / 255
    dlab = np.abs(co.rgb_to_cielab(b) - co.rgb_to_cielab_srgb(a)).max() if hasattr(co, 'rgb_to_cielab_srgb') else \
        np.abs(co.rgb_to_cielab(b) - co.xyz_to_cielab(co.srgb_to_linear(a) @ co.SRGB_TO_XYZ.T)).max()
    check('sRGB→P3 转换：同一物理颜色（8bit 量化内）', dlab < 1.0, f'CIELab 最大差 {dlab:.3f}')

    # 2. 统计：P3 统计 vs sRGB 原图统计（物理一致）
    s_srgb, s_p3 = osp.join(tmp, 's_srgb'), osp.join(tmp, 's_p3')
    r1 = run([osp.join(ROOT, 'analysis', 'stat_real_pairs.py'), '--content-dir', osp.join(SYN, 'content'),
              '--style-dir', osp.join(SYN, 'style'), '--out-dir', s_srgb, '--workers', '4', '--remove-gray-shift'])
    r2 = run([osp.join(K3, 'k3_stats', 'stat_real_pairs_p3.py'), '--content-dir', p3['content'],
              '--style-dir', p3['style'], '--out-dir', s_p3, '--workers', '4', '--remove-gray-shift', '--le2-n', '4'])
    check('k3_stats P3 统计运行（含 4_code P3 le2）', r1.returncode == 0 and r2.returncode == 0, tail(r2, 2))
    hs, gs, tas, tbs, _ = per_bin_means(osp.join(s_srgb, 'pair_stats.npz'))
    hp, gp, tap, tbp, le2p = per_bin_means(osp.join(s_p3, 'pair_stats.npz'))
    dh = np.nanmedian(np.abs(hs - hp))
    dt = np.median(np.hypot(tas - tap, tbs - tbp))
    dg = np.nanmedian(np.abs(gs - gp))
    check('P3 统计与 sRGB 统计物理一致', dh < 0.5 and dt < 0.1 and dg < 0.02,
          f'|ΔdH| 中位 {dh:.3f}°, |Δt| 中位 {dt:.3f}, |Δg| 中位 {dg:.4f}')
    check('P3 统计 le2 有值', np.isfinite(le2p).sum() == 4, f'le2={le2p[np.isfinite(le2p)].round(3)}')

    # 3. 导出
    model_p3 = osp.join(tmp, 'cast_model_p3.json')
    r = run([osp.join(K3, 'k3_stats', 'export_cast_model.py'), osp.join(s_p3, 'pair_stats.npz'), '--out', model_p3])
    m = json.load(open(model_p3, encoding='utf-8')) if r.returncode == 0 else {}
    check('导出 P3 偏色模型', m.get('color_space') == 'display-p3', tail(r, 1))
    r = run([osp.join(K3, 'k3_stats', 'export_cast_model.py'), osp.join(s_srgb, 'pair_stats.npz'),
             '--out', osp.join(tmp, 'bad.json')])
    check('导出拒绝 sRGB 统计结果', r.returncode != 0 and 'P3' in (r.stdout + r.stderr))

    # 4. 生成器
    import k3_cast as kc
    try:
        kc.CastModel(osp.join(ROOT, 'k2', 'cast_model.json'))
        rej = False
    except ValueError:
        rej = True
    check('k3_cast 拒绝 k2(sRGB) 模型', rej)
    model = kc.CastModel(model_p3)
    rng = np.random.default_rng(0)
    imgs = [np.asarray(Image.open(f).convert('RGB'), dtype=np.float32) / 255
            for f in sorted(glob.glob(osp.join(p3['content'], '*.png')))[:6]]
    dL, inside, gf = [], True, []
    for i in range(12):
        x, _ = kc.protect(model.sample(rng, dev_scale=1.5))
        o, info = kc.apply_cast(imgs[i % 6], x)
        lab_o = co.rgb_to_oklab(o)
        dL.append(np.abs(lab_o[..., 0] - co.rgb_to_oklab(imgs[i % 6])[..., 0]).max())
        lin = co.oklab_to_linear_unclipped(lab_o)
        inside &= bool(np.all((lin > -1e-3) & (lin < 1 + 1e-3)))
        gf.append(info['gamut_frac'])
    check('P3 偏色：L 保持且结果在 P3 色域内', max(dL) < 3e-3 and inside, f'max|dL|={max(dL):.1e} 出域比例 {np.mean(gf)*100:.2f}%')

    # 5. 4_code P3 补丁
    sys.path.insert(0, STUBS)
    import lutgen_4code as lg
    import lutgen_p3
    lutgen_p3.patch_p3(lg)
    ok = np.allclose(lg.RGB_TO_XYZ, lutgen_p3.P3_TO_XYZ, atol=1e-6) and lg._IDENT_LAB_CACHE['table'] is None
    le_id = kc.le2_4code(imgs[0], imgs[0], lg)
    check('4_code 切换到 P3 矩阵', ok and le_id > 0.9, f'恒等 le2={le_id:.3f}')

    # 6. 离线生成
    cdir = osp.join(tmp, 'train_p3')
    os.makedirs(cdir)
    names = []
    for f in sorted(glob.glob(osp.join(p3['content'], '*.png')))[:4]:
        shutil.copy(f, cdir)
        names.append(osp.splitext(osp.basename(f))[0])
    with open(osp.join(tmp, 'train.txt'), 'w') as f:
        f.write('\n'.join(names) + '\n')
    out = osp.join(tmp, 'k3_offline_out')
    r = run([osp.join(K3, 'k3_offline', 'gen_offline_casts.py'), '--content-dir', cdir, '--out-dir', out,
             '--n-casts', '3', '--workers', '2', '--model', model_p3])
    ok = r.returncode == 0 and len(open(osp.join(out, 'all_list.txt')).read().split()) == 12
    check('k3_offline 离线生成 + P3 4_code 筛选', ok, tail(r, 4).replace('\n', ' | '))
    r = run([osp.join(K3, 'k3_offline', 'cast_4code_tool.py'), 'validate', '--content-dir', cdir,
             '--casts-per-image', '1', '--workers', '2', '--model', model_p3, '--out-dir', osp.join(tmp, 'val')])
    check('k3_offline validate 工具', r.returncode == 0, tail(r, 1))

    # 7. dataset 端到端
    reg = types.ModuleType('mmedit.datasets.registry')
    reg.DATASETS = types.SimpleNamespace(register_module=lambda *a, **k: (lambda c: c))
    base = types.ModuleType('mmedit.datasets.base_dataset')

    class BaseDataset:
        def __init__(self, pipeline, test_mode=False):
            self.pipeline = lambda r: r
            self.test_mode = test_mode
    base.BaseDataset = BaseDataset
    for nm in ('mmedit', 'mmedit.datasets'):
        sys.modules[nm] = types.ModuleType(nm)
    sys.modules['mmedit.datasets.registry'] = reg
    sys.modules['mmedit.datasets.base_dataset'] = base
    pkg = types.ModuleType('k3pkg')
    pkg.__path__ = [osp.join(K3, 'k3_dataset'), ROOT]
    sys.modules['k3pkg'] = pkg
    for nm, attrs in (('gt_degrade', dict(merge_cfg=lambda c: dict(c or {}))),
                      ('lut_io', dict(load_lut_array=lambda *a, **k: None)),
                      ('p0_augmentations_v0826', dict(ResidualLumaAug=object, LocalSpatialAug=object,
                                                       mean_linear_luma=lambda x: 0.0))):
        mm = types.ModuleType(f'k3pkg.{nm}')
        mm.__dict__.update(attrs)
        sys.modules[f'k3pkg.{nm}'] = mm
    mod = __import__('k3pkg.LumaAlignK3CastCTdataset', fromlist=['x'])
    passed = open(osp.join(out, 'passed_list.txt')).read().split()
    for cfg_name in ('config_k3_A_online_nocheck.py', 'config_k3_B1_offline_all.py', 'config_k3_B2_offline_passed.py'):
        cfg = runpy.run_path(osp.join(K3, 'k3_dataset', cfg_name))
        tr = dict(cfg['data']['train'][0])
        tr.pop('type')
        tr.update(content_dir=cdir, gt_dir=cdir, content_source_dir=cdir, img_ext='.png',
                  ann_file=osp.join(tmp, 'train.txt'), pipeline=[])
        if tr['cast_source'] == 'online':
            tr['cast_model'] = model_p3
        else:
            tr['offline_cast_dir'] = osp.join(out, 'casts')
            tr['offline_list'] = osp.join(out, osp.basename(tr['offline_list']))
        ds = mod.LumaAlignK3CastCTdataset(**tr)
        ok = len(ds.data_infos) > 0
        for i in range(len(ds.data_infos)):
            res = ds[i]
            ok &= np.array_equal(res['style_img'], res['content_gt']) and res['style_img'].shape == res['content_img'].shape
            ok &= not np.allclose(res['content_gt'], res['content_img'], atol=1e-3)
        exp = len({f.rsplit('_c', 1)[0] for f in passed}) if 'passed' in cfg_name else len(names)
        check(f'k3_dataset {cfg_name}', ok and len(ds.data_infos) == exp, f'样本 {len(ds.data_infos)} 统计 {ds._stat}')

    # 8. eval
    r = run([osp.join(K3, 'k3_eval', 'eval_synth_real.py'), '--content-dir', p3['content'], '--gt-dir', p3['style'],
             '--n-casts', '1', '--out-dir', osp.join(tmp, 'eval'), '--dry-run', '--cast-model', model_p3])
    check('k3_eval eval_synth_real --dry-run', r.returncode == 0 and 'P3 口径' in r.stdout, tail(r, 2).replace('\n', ' | '))
    r = run([osp.join(K3, 'k3_degrade_stats', 'stat_style_residual.py'), '--content-dir', p3['content'],
             '--style-dir', p3['style'], '--gt-dir', p3['content'], '--max-images', '3', '--workers', '2',
             '--out-dir', osp.join(tmp, 'resid')])
    check('k3_degrade_stats stat_style_residual', r.returncode == 0, tail(r, 1))
    r = run([osp.join(K3, 'sync_core.py'), '--check'])
    check('sync_core 一致性', r.returncode == 0)

    shutil.rmtree(tmp, ignore_errors=True)
    print(f'\n共 {len(results)} 项，失败 {results.count(False)} 项')
    sys.exit(0 if all(results) else 1)


if __name__ == '__main__':
    main()
