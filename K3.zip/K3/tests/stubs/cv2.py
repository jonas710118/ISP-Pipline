# -*- coding: utf-8 -*-
"""仅供本机自测的 cv2 近似替身（本机无 opencv）。用 PIL/scipy 实现脚本用到的函数，数值与 cv2 不完全一致，
只用于验证脚本流程，不能用于任何 le2 判定。服务器上请使用真 opencv-python。"""
import numpy as np
from PIL import Image
from scipy import ndimage

IMREAD_UNCHANGED = -1
COLOR_RGB2BGR = 4
COLOR_BGR2RGB = 4
CV_32F = 5
BORDER_REFLECT = 2
INTER_AREA = 3
IMWRITE_PNG_COMPRESSION = 16


def setNumThreads(n):
    pass


def imread(path, flags=None):
    try:
        return np.asarray(Image.open(path).convert('RGB'))[..., ::-1].copy()
    except Exception:  # noqa: BLE001
        return None


def imwrite(path, img, params=None):
    Image.fromarray(np.ascontiguousarray(img[..., ::-1])).save(path)
    return True


def cvtColor(img, code):
    return np.ascontiguousarray(img[..., ::-1])


def resize(img, size, interpolation=None):
    return np.asarray(Image.fromarray(img).resize(tuple(size), Image.BOX))


def boxFilter(img, ddepth, ksize, borderType=None):
    return ndimage.uniform_filter(img, size=(ksize[1], ksize[0]) + ((1,) if img.ndim == 3 else ()), mode='reflect')


def Sobel(img, ddepth, dx, dy, ksize=3):
    return ndimage.sobel(img, axis=1 if dx else 0, mode='reflect').astype(np.float32)


def GaussianBlur(img, ksize, sigma):
    return ndimage.gaussian_filter(img, sigma, mode='reflect')
