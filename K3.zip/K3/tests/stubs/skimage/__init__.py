# 仅供本机自测的 skimage 替身
