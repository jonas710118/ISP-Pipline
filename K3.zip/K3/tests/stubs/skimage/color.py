# -*- coding: utf-8 -*-
"""仅供本机自测：用同公式实现替代 skimage.color（本机未装 scikit-image）。
rgb2lab 按 sRGB（与 skimage 一致），xyz2lab 与 deltaE_ciede2000 与 skimage 同公式。"""
import os.path as osp
import sys

import numpy as np

_CORE = osp.join(osp.dirname(osp.dirname(osp.dirname(osp.dirname(osp.abspath(__file__))))), 'core')
sys.path.insert(0, _CORE)
import k3_color_ops as co  # noqa: E402


def xyz2lab(xyz):
    return co.xyz_to_cielab(np.asarray(xyz, dtype=np.float64))


def rgb2lab(rgb):
    return co.xyz_to_cielab(co.srgb_to_linear(rgb) @ co.SRGB_TO_XYZ.T)


def deltaE_ciede2000(lab1, lab2):
    return co.ciede2000(lab1, lab2)
